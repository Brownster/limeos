"""Run current A1 once; diagnostics run synchronously outside production RPCs."""
import json
import subprocess

import p04_approved_guest as approved
import p04_mounts_guest as mounts
from namespace_census import snapshot

witness = {}
original_pre = mounts.pre_effect_refusals
original_after = mounts._after_refusal_facts

def pre_effect(*args):
    witness['before'] = snapshot()
    try:
        return original_pre(*args)
    finally:
        witness['after'] = snapshot()

def diagnostics(service):
    facts = original_after(service)
    facts['namespace_census'] = snapshot()
    facts['pre_effect_task_witness'] = witness
    return facts

mounts.pre_effect_refusals = pre_effect
mounts._after_refusal_facts = diagnostics
try:
    approved.main(package_version='0.4.6+taskdiff.1', qualify_upgrade=False)
except Exception:
    result = subprocess.run(['journalctl', '-u', mounts.UNIT, '--no-pager', '-n', '80', '-o', 'cat'], text=True, capture_output=True, timeout=5)
    count = 0
    for line in result.stdout[-65536:].splitlines():
        if len(line.encode()) >= 2048:
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if value.get('event') == 'storage_mount_consumer_tasks_changed':
            print('A1_TASK_DIFFERENCE ' + json.dumps(value), flush=True)
            count += 1
            if count == 8:
                break
    print('A1_TASK_DIFFERENCE_RECORDS=' + str(count), flush=True)
    raise
