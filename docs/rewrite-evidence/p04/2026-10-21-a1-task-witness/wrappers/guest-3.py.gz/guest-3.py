"""Run current A1 once; diagnostics run synchronously outside production RPCs."""
import json
import subprocess
import time

import p04_approved_guest as approved
import p04_mounts_guest as mounts
import guest as foundation
import p04_planning_guest as planning
from namespace_census import snapshot

witness = {}
original_pre = mounts.pre_effect_refusals
original_after = mounts._after_refusal_facts
original_run = planning.run

def with_reader_readiness(*args, **kwargs):
    result = original_run(*args, **kwargs)
    if args == ('systemctl', 'start', 'limeos-storage-reader'):
        started = time.monotonic()
        observations = []
        while True:
            reply = original_run('runuser', '-u', 'limeos-core', '-g', 'limeos-host-access', '--', 'python3', '-c', foundation.executor_probe_code(), '/run/limeos-storage-reader/executor.sock', json.dumps({'operation': 'storage_inventory', 'version': 1}))
            value = json.loads(reply.stdout)
            observations.append({'ready': value.get('ready'), 'error': value.get('error'), 'inventory_present': value.get('storage') is not None})
            if value.get('version') == 1 and value.get('ready') is True and value.get('storage') is not None:
                break
            assert value == {'version': 1, 'ready': False, 'error': 'overloaded'}, value
            assert len(observations) < 64 and time.monotonic() - started < 6
            time.sleep(0.05)
        print('A1_READER_STARTUP ' + json.dumps({'scope': 'bounded read-only fixture readiness; effect and planning assertions unchanged', 'elapsed_seconds': time.monotonic() - started, 'observations': observations}), flush=True)
    return result

planning.run = with_reader_readiness

def pre_effect(*args):
    witness['before'] = snapshot()
    try:
        return original_pre(*args)
    finally:
        witness['after'] = snapshot()

def diagnostics(service):
    facts = original_after(service)
    facts['namespace_census'] = snapshot()
    facts['pre_effect_task_witness'] = witness
    return facts

mounts.pre_effect_refusals = pre_effect
mounts._after_refusal_facts = diagnostics
try:
    approved.main(package_version='0.4.6+taskdiff.1', qualify_upgrade=False)
except Exception:
    for name, command in [
        ('inventory_cli', ['/usr/lib/limeos/limeos-executor', 'storage-inventory']),
        ('inventory_rpc', ['runuser', '-u', 'limeos-core', '-g', 'limeos-host-access', '--', 'python3', '-c', foundation.executor_probe_code(), '/run/limeos-storage-reader/executor.sock', json.dumps({'operation': 'storage_inventory', 'version': 1})]),
        ('reader_unit', ['systemctl', 'show', 'limeos-storage-reader', '-p', 'ActiveState', '-p', 'SubState', '-p', 'MainPID', '-p', 'ControlGroup', '-p', 'TasksCurrent', '-p', 'MemoryCurrent', '-p', 'MemoryPeak', '-p', 'Result']),
        ('reader_journal', ['journalctl', '-u', 'limeos-storage-reader', '--no-pager', '-n', '80', '-o', 'cat']),
    ]:
        try:
            observed = subprocess.run(command, text=True, capture_output=True, timeout=10)
            print('A1_EARLY_DIAGNOSTIC ' + json.dumps({'name': name, 'scope': 'later post-failure read only; no acceptance or original-response equivalence', 'exit_code': observed.returncode, 'stdout': observed.stdout[-24000:], 'stderr': observed.stderr[-2000:]}), flush=True)
        except Exception as error:
            print('A1_EARLY_DIAGNOSTIC ' + json.dumps({'name': name, 'error': str(error)[:1000]}), flush=True)
    result = subprocess.run(['journalctl', '-u', mounts.UNIT, '--no-pager', '-n', '80', '-o', 'cat'], text=True, capture_output=True, timeout=5)
    count = 0
    for line in result.stdout[-65536:].splitlines():
        if len(line.encode()) >= 2048:
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if value.get('event') == 'storage_mount_consumer_tasks_changed':
            print('A1_TASK_DIFFERENCE ' + json.dumps(value), flush=True)
            count += 1
            if count == 8:
                break
    print('A1_TASK_DIFFERENCE_RECORDS=' + str(count), flush=True)
    raise
