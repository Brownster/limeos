# /// script
# dependencies = []
# ///
"""Join exact failed-comparison identities with the independent task witness."""
import json
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-task-difference'
log = ROOT / '.cache/main-consolidation/attempts/a1-task-difference-vm-4/output.log'
lines = log.read_text().splitlines()
failure = [json.loads(line.removeprefix('A1_FAILURE ')) for line in lines if line.startswith('A1_FAILURE ')]
assert len(failure) == 1
failure = failure[0]
(STATE / 'vm-4-a1-failure.json').write_text(json.dumps(failure, indent=2) + '\n')
changes = [json.loads(line.removeprefix('A1_TASK_DIFFERENCE ')) for line in lines if line.startswith('A1_TASK_DIFFERENCE ')]
assert len(changes) == 1
change = changes[0]
witness = failure['after_refusal_facts']['pre_effect_task_witness']

def key(row):
    return row['pid'], row['tid'], row['start'], tuple(row['namespace'])

before = {key(row): row for row in witness['before']['user_tasks']}
after = {key(row): row for row in witness['after']['user_tasks']}
removed = [row for row in change['removed'] if row is not None]
assert change['removed_count'] == len(removed) == 2 and change['added_count'] == 0
joined = []
for row in removed:
    original = before[key(row)]
    assert key(row) not in after
    assert original['cgroup'] == '/system.slice/systemd-udevd.service/udev'
    joined.append(original)
result = {'source': 'c6932b291d2583114b3d4b122e75d94b4db9be93',
          'stage': failure['stage'], 'error': failure['error'],
          'actual_comparison': change, 'independent_before_witness': joined,
          'both_external_samples_complete': all(witness[name]['complete_without_observed_read_or_membership_errors'] for name in ('before', 'after')),
          'conclusion': 'This reproduction refused two disappearing systemd-udevd worker identities. Original earlier-run identities remain unproven.',
          'next': 'Quiesce fixture disk-setup udev work and wait for owned guest daemon workers to exit naturally before the first planning RPC; retain every runtime comparison.'}
(STATE / 'vm-4-analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
