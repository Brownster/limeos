# /// script
# dependencies = []
# ///
"""Publish the exact diagnostic attempts, excluding private fixture key material."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-task-difference'
BUILDS = ROOT / '.cache/stack-installed-qualification'
ATTEMPTS = ROOT / '.cache/main-consolidation/attempts'
OUT = ROOT / 'docs/rewrite-evidence/p04/2026-10-21-a1-task-witness'
SOURCE = 'c6932b291d2583114b3d4b122e75d94b4db9be93'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def archive(source, relative):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    if target.exists():
        assert gzip.decompress(target.read_bytes()) == data, relative
        return
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data

labels = ['a1-task-difference-focused-1', 'a1-task-difference-clippy-1',
          'a1-task-difference-format-1', 'a1-task-difference-packages-1',
          *[f'a1-task-difference-vm-{index}' for index in range(1, 6)]]
summaries = []
tracked = set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0'))
matches = []
for label in labels:
    directory = ATTEMPTS / label
    record = json.loads((directory / 'record.json').read_text())
    assert 'exit_code' in record and record['inputs_unchanged']
    for name in ('record.json', 'output.log'):
        archive(directory / name, f'checks/{label}-{name}.gz')
    summaries.append({key: record[key] for key in ('command', 'exit_code', 'guard_triggered', 'minimum_available_bytes', 'inputs_unchanged')})
    if label in ('a1-task-difference-focused-1', 'a1-task-difference-clippy-1', 'a1-task-difference-format-1'):
        assert record['exit_code'] == 0 and not record['guard_triggered']
        count = 0
        for name, expected in record['before'].items():
            if name in tracked:
                assert digest((ROOT / name).read_bytes()) == expected
                committed = subprocess.check_output(['git', 'show', f'{SOURCE}:{name}'], cwd=ROOT)
                assert digest(committed) == expected, name
                count += 1
        matches.append({'attempt': label, 'tracked_inputs_matching_source': count})
build = BUILDS / 'build-5'
record = json.loads((build / 'record.json').read_text())
assert record['source'] == SOURCE and record['exit_code'] == 0
assert record['inputs_unchanged'] and record['container_removed'] and record['stop_reason'] is None
for name in ('record.json', 'output.log', 'inputs.sha256', 'source-before.log', 'source-after.log', 'binaries.json', 'container-before.json', 'container-after.json'):
    archive(build / name, f'build/{name}.gz')
for name in ('build_candidate_5.py', 'build_inside.py', 'run_384.py', 'run_512.py'):
    archive(BUILDS / name, f'helpers/{name}.gz')
archive(ROOT / 'tests/privileged_vm/run.py', 'helpers/original-vm-runner.py.gz')
archive(ROOT / '.cache/main-consolidation/guard.py', 'helpers/guard.py.gz')
for name in ('prepare_candidate.py', 'prepare_guest.py', 'prepare_guest_2.py', 'prepare_guest_3.py', 'prepare_guest_4.py', 'analyze_failure.py', 'publish.py', 'vm-4-a1-failure.json', 'vm-4-analysis.json', 'vm-4-inputs.json'):
    archive(STATE / name, f'diagnostics/{name}.gz')
for folder, manifest in [('guest', 'guest-inputs.json'), ('guest-2', 'guest-2-inputs.json'), ('guest-3', 'guest-3-inputs.json'), ('guest-4', 'guest-4-inputs.json')]:
    inputs = json.loads((STATE / manifest).read_text())
    assert inputs['source'] == SOURCE
    (OUT / manifest).write_bytes((STATE / manifest).read_bytes())
    for name, expected in inputs['guest'].items():
        source = STATE / folder / name
        assert digest(source.read_bytes()) == expected
        if name == 'task_difference_guest.py':
            archive(source, f'wrappers/{folder}.py.gz')
        elif not (OUT / 'fixture-objects' / f'{expected}.gz').exists():
            archive(source, f'fixture-objects/{expected}.gz')
for source in sorted(STATE.glob('result-*-*.txt')):
    archive(source, f'guest-failures/{source.name}.gz')
candidate = BUILDS / 'candidate-5'
archive(candidate / 'inputs.json', 'package-inputs.json.gz')
for relative in ('limeos-archive-keyring.gpg', 'dists/stable/Release', 'dists/stable/InRelease', 'dists/stable/Release.gpg'):
    archive(candidate / 'repository' / relative, f'public-repository/{Path(relative).name}.gz')
for name in ('vm-4-analysis.json',):
    (OUT / name).write_bytes((STATE / name).read_bytes())
processes = subprocess.check_output(['ps', '-eo', 'pid,comm'], text=True).splitlines()[1:]
owned = []
compilers = []
for line in processes:
    pid, name = line.split(maxsplit=1)
    if name in ('cargo', 'rustc', 'rustdoc'):
        compilers.append(int(pid))
    if name.startswith('qemu-system'):
        try:
            command = (Path('/proc') / pid / 'cmdline').read_bytes()
        except FileNotFoundError:
            continue
        if str(ROOT / '.cache/main-consolidation/tmp/limeos-p01-vm-').encode() in command:
            owned.append(int(pid))
assert not owned and not compilers
result = {'source': SOURCE, 'validation_source_matches': matches, 'attempts': summaries,
          'owned_vm_pids_after_all_attempts': owned, 'compiler_pids_after_all_attempts': compilers,
          'build_container_removed': True, 'private_keys_excluded': True,
          'a1_accepted': False, 'push_performed': False, 'production_access': False}
(OUT / 'manifest.json').write_text(json.dumps(result, indent=2) + '\n')
rows = []
for source in sorted(OUT.rglob('*')):
    if source.is_file() and source.name != 'SHA256SUMS':
        rows.append(f'{digest(source.read_bytes())}  {source.relative_to(OUT)}')
(OUT / 'SHA256SUMS').write_text('\n'.join(rows) + '\n')
print(json.dumps({'packet': str(OUT.relative_to(ROOT)), 'files': len(rows), 'source_matches': matches, 'owned_vms_remaining': len(owned)}))
