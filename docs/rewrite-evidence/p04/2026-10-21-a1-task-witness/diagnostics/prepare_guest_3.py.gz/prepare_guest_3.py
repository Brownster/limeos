# /// script
# dependencies = []
# ///
"""Freeze current installed fixtures with synchronous diagnostic witnesses."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-task-difference'
guest = STATE / 'guest-3'
guest.mkdir()
for source in sorted((ROOT / 'tests/privileged_vm').glob('*.py')):
    shutil.copyfile(source, guest / source.name)
shutil.copyfile(ROOT / '.cache/a1-namespace-review/proc-witness-v3-guest/namespace_census.py', guest / 'namespace_census.py')
shutil.copyfile(STATE / 'task_difference_guest.py', guest / 'task_difference_guest.py')
manifest = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'package_version': '0.4.6+taskdiff.1', 'guest_memory_mib': 512,
            'qualification': 'current installed A1 fixture and predecessor setup; prior-version upgrade explicitly excluded',
            'comparison_or_assertions_relaxed': False,
            'guest': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(guest.glob('*.py'))}}
(STATE / 'guest-3-inputs.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(manifest['guest']), 'source': manifest['source']}))
