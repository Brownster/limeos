# /// script
# dependencies = []
# ///
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tarfile
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
out=root/'docs/rewrite-evidence/p04/2026-11-05-b1-status-panels'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert not (out/'SHA256SUMS').exists()
frozen=[json.loads((state/f'inputs-{n}.json').read_text()) for n in (1,2)]
current=frozen[1]['fixture_inputs']
assert all(sha(root/name)==expected for name,expected in current.items())
assert {name for name,value in current.items() if frozen[0]['fixture_inputs'][name]!=value}=={'tests/privileged_vm/p04_automation_browser_guest.py','tests/reference/test_p04_automation_browser_guest.py'}
joins=[]
for folder in (out,out/'full-panel-followup'):
 result=json.loads((folder/'installed-result.json').read_text())
 assert result['summary']=='pass' and result['stage']=='complete' and result['availability_copy_verified']
 assert result['before_restart']==result['after_restart'] and result['immutable_before']==result['immutable_after']
 assert result['oom_before']==result['oom_after']=={'oom_kill':0}
 opening,recovery=result['opening'],result['recovery']
 assert opening['event']['generation']==recovery['event']['generation']==1
 assert opening['event']['event']=='incident' and recovery['event']['event']=='recovery'
 assert opening['event']['key']==recovery['event']['key']=='container:'+result['container_id']
 assert all(row['attempts']==1 and row['channel']=='in_app' and row['delivery']['state']=='delivered' for row in (opening,recovery))
 for path,expected in {
  '/api/v1/auth/login':[200,200],'/api/v1/auth/capabilities/observe-health/enable':[200],'/api/v1/automation/health-policy':[200],
  '/api/v1/automation/schedules':[403,201],'/api/v1/automation/notifications/'+opening['id']+'/acknowledgment':[200],
  '/api/v1/automation/schedules/'+result['schedule_id']+'/pause':[200]}.items():
  assert [row['status'] for row in result['http'] if row['path']==path and row['method']=='POST']==expected
 assert all(set(row)=={'method','path','status'} for row in result['http'])
 history=result['final_history']
 assert {key:len(value) for key,value in history.items()}=={'schedules':1,'occurrences':2,'jobs':2,'results':2,'alerts':1,'notifications':2}
 assert history['schedules'][0][0]==result['schedule_id'] and history['schedules'][0][1:3]==[2,1]
 assert len({tuple(row[:3]) for row in history['occurrences']})==2 and history['occurrences'][1][2]-history['occurrences'][0][2]==60
 assert {row[3] for row in history['occurrences']}=={row[0] for row in history['jobs']}=={row[0] for row in history['results']}
 assert all(row[1]=='succeeded' for row in history['jobs'])
 assert all(row[1:3]==['succeeded','observed'] and row[4]==0 for row in history['results'])
 assert any(json.loads(row[2])['id']==opening['id'] and json.loads(row[2])['acknowledged_at'] is not None for row in history['notifications'])
 assert len(result['restarts'])==2
 pids=[result['restarts'][0]['before_pid'],int(result['restarts'][0]['after']['MainPID']),int(result['restarts'][1]['after']['MainPID'])]
 assert len(set(pids))==3 and result['restarts'][1]['before_pid']==pids[1]
 for value in result['screenshots'].values():
  path=folder/value['file'];data=path.read_bytes()
  assert sha(path)==value['sha256'] and struct.unpack('!II',data[16:24])==(value['width'],value['height'])
  geometry=value['geometry'];assert geometry['page_width']<=geometry['viewport_width']+1
  if folder!=out:assert abs(value['width']-geometry['target_width'])<=1 and abs(value['height']-geometry['target_height'])<=1
 joins.append(dict(result=str(folder.relative_to(out)),schedule=result['schedule_id'],core_pids=pids,counts={key:len(value) for key,value in history.items()}))
for n,folder in [(1,out),(2,out/'full-panel-followup')]:
 with tarfile.open(folder/'reproduction-sources.tar.gz','r:gz') as archive:
  names=archive.getnames()
  assert len([name for name in names if name.startswith('guest/')])==34
  assert all(not name.startswith('/') and '..' not in Path(name).parts for name in names)
  for name,expected in frozen[n-1]['guest'].items():assert hashlib.sha256(archive.extractfile('guest/'+name).read()).hexdigest()==expected
checks=[]
for command in ([sys.executable,'scripts/check_repository.py'],['git','diff','--check']):
 value=subprocess.run(command,cwd=root,text=True,capture_output=True)
 checks.append(dict(command=command,exit_code=value.returncode,stdout=value.stdout,stderr=value.stderr));assert value.returncode==0
links=[]
for document in (out/'README.md',root/'docs/p04-b1-observation-supervisor-handoff.md',root/'docs/rewrite-evidence/p04/2026-10-05-execution-tracker.md'):
 for target in re.findall(r'\]\(([^)]+)\)',document.read_text()):
  if '://' in target or target.startswith('#'):continue
  assert (document.parent/target.partition('#')[0]).exists(),(document,target)
  links.append(dict(document=str(document.relative_to(root)),target=target))
for path in out.rglob('*.gz'):gzip.decompress(path.read_bytes())
verification=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),fixture_inputs=749,commands=checks,relative_links_checked=len(links),links=links,gzip_files_readable=True,original_and_followup_joins=joins,full_target_png_dimensions_verified=True,sealer_sha256=sha(Path(__file__)))
(out/'final-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(out/'seal-source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
files=sorted(path for path in out.rglob('*') if path.is_file())
(out/'SHA256SUMS').write_text(''.join(sha(path)+'  '+str(path.relative_to(out))+'\n' for path in files))
for line in (out/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1);assert sha(out/name)==expected
print(json.dumps(dict(verified_files=len(files),current_inputs=749,relative_links=len(links),installed_status_geometry_and_full_target_captures_verified=True)))
