# /// script
# dependencies = []
# ///
"""Run the project's frontend tests with one worker, then its checked build."""
import datetime,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/marc/Documents/github/lime-os')
STATE=ROOT/'.cache/b1-status-panel-qualification'
def snapshot():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','frontend','contracts/generated'],cwd=ROOT,text=True).splitlines()
 return {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in sorted(set(names)) if (ROOT/name).is_file()}
package=json.loads((ROOT/'frontend/package.json').read_text())
assert package['scripts']['test']=='node --experimental-strip-types --test tests/*.mjs'
tests=sorted(str(p.relative_to(ROOT/'frontend')) for p in (ROOT/'frontend/tests').glob('*.mjs'))
commands=[['node','--experimental-strip-types','--test','--test-concurrency=1',*tests],['npm','run','build'],['uv','run','--offline','--no-project','--cache-dir',str(ROOT/'.cache/uv'),'--python','/usr/bin/python3',str(STATE/'diagnostic_3.py')]]
record={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':snapshot(),'checks':[]}
status=0
for number,command in enumerate(commands,1):
 log=STATE/f'frontend-step-{number}.log'
 with log.open('xb') as stream:
  result=subprocess.run(command,cwd=ROOT/'frontend',stdout=stream,stderr=subprocess.STDOUT)
 record['checks'].append({'command':command,'exit_code':result.returncode,'log':str(log.relative_to(ROOT))})
 print(json.dumps(record['checks'][-1]),flush=True)
 print(log.read_text()[-4500:],flush=True)
 if result.returncode: status=result.returncode; break
record.update(ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=status,inputs_unchanged=record['inputs']==snapshot())
if status==0 and record['inputs_unchanged']:
 record['ui']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'frontend/dist').rglob('*')) if p.is_file()}
(STATE/'frontend-build.json').write_text(json.dumps(record,indent=2)+'\n')
if not record['inputs_unchanged']: raise SystemExit(1)
raise SystemExit(status)
