# /// script
# dependencies = []
# ///
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
builders=root/'.cache/stack-installed-qualification'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
packages=json.loads((builders/'candidate-14/inputs.json').read_text())
build=json.loads((builders/'build-12/record.json').read_text())
assert head==packages['source']==packages['ui_source']
assert build['source']==packages['binary_source'] and build['exit_code']==0 and build['inputs_unchanged'] and build['container_removed']
for phase in ('frontend','reference','package'):
 record=json.loads((root/'.cache/main-consolidation/attempts'/f'b1-status-panel-{phase}-1/record.json').read_text())
 assert record['exit_code']==0 and record['inputs_unchanged'] and not record['guard_triggered'] and record['ended']
 assert record['head']==head and record['before']==record['after']==packages['package_inputs']
for name,expected in packages['package_inputs'].items():
 assert sha(root/name)==expected
 assert hashlib.sha256(subprocess.check_output(['git','show',f'{head}:{name}'],cwd=root)).hexdigest()==expected
for name,expected in build['before'].items():
 change=packages['changes_since_binary_build'].get(name)
 assert packages['package_inputs'][name]==(change['after'] if change else expected)
 if change:assert change['before']==expected
assert len(packages['changes_since_binary_build'])==7
assert len(packages['production_changes_since_binary_build'])==5
assert len(packages['test_changes_since_binary_build'])==2
for name,expected in packages['repository'].items():assert sha(builders/'candidate-14/repository'/name)==expected
guest=state/'guest-1';guest.mkdir(exist_ok=False)
for path in sorted((root/'tests/privileged_vm').glob('*.py')):shutil.copyfile(path,guest/path.name)
(guest/'installed_guest.py').write_text('import p04_automation_browser_guest as guest\nguest.main(package_version='+repr(packages['version'])+')\n')
for name,original in [('run_1024.py','run.py'),('current_authority_schema.py','current_authority_schema.py')]:shutil.copyfile(root/'tests/privileged_vm'/original,state/name)
manifest=dict(fixture_source=head,package_source=packages['source'],binary_source=packages['binary_source'],ui_source=packages['ui_source'],fixture_inputs=packages['package_inputs'],
 package_inputs_sha256=sha(builders/'candidate-14/inputs.json'),build_record_sha256=sha(builders/'build-12/record.json'),
 test_only_changes_between_package_and_fixture={},test_only_additions_since_binary_build={name:expected for name,expected in packages['package_inputs'].items() if name not in build['before']},
 production_changes_since_binary_build=packages['production_changes_since_binary_build'],test_changes_since_binary_build=packages['test_changes_since_binary_build'],
 guest_memory_mib=1024,runner_sha256=sha(state/'run_1024.py'),runner_support={'current_authority_schema.py':sha(state/'current_authority_schema.py')},schema_source_sha256=sha(root/'crates/persistence/src/lib.rs'),
 guest={path.name:sha(path) for path in sorted(guest.glob('*.py'))},scope='Installed AMD64 B1 updated status copy, target captures and page geometry with real UI/API/runtime; full B1/P04/cutover remains open')
with (state/'inputs-1.json').open('x') as stream:stream.write(json.dumps(manifest,indent=2)+'\n')
old=root/'.cache/b1-installed-browser-qualification'
for source,target in [('launch_vm.py','launch_vm.py'),('observe_vm.py','observe_vm.py')]:
 value=(old/source).read_text().replace('b1-installed-browser','b1-status-panel').replace('candidate-13','candidate-14')
 with (state/target).open('x') as stream:stream.write(value)
print(json.dumps(dict(source=head,binary_source=build['source'],ui_source=packages['ui_source'],inputs=len(packages['package_inputs']),guest_modules=len(manifest['guest']))))
