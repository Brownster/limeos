# /// script
# dependencies = []
# ///
from pathlib import Path
state=Path(__file__).parent
value=(state/'check_reference.py').read_text().replace('reference-step-','reference-2-step-').replace('reference-checks.json','reference-2-checks.json')
(state/'check_reference_2.py').write_text(value)
value=(state/'launch.py').read_text().replace("'reference-1':", "'reference-2':").replace("state/'check_reference.py'", "state/'check_reference_2.py'")
(state/'launch_reference_2.py').write_text(value)
