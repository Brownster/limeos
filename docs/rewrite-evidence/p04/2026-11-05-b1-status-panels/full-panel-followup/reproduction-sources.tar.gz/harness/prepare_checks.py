# /// script
# dependencies = []
# ///
from pathlib import Path
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
value=(state/'diagnostic_2.py').read_text().replace('layout-diagnostic-2.json','layout-diagnostic-3.json')
value=value.replace('offenders:[', "tables:[...document.querySelectorAll('.table-wrap')].map(e=>({width:e.clientWidth,scroll_width:e.scrollWidth})),offenders:[")
value=value.replace("value=dict(scope=", "assert all(row['scroll'] == row['width'] and not row['offenders'] for row in results.values())\nassert results['table']['tables'][0]['scroll_width'] > results['table']['tables'][0]['width']\nvalue=dict(scope=")
(state/'diagnostic_3.py').write_text(value)
value=(root/'.cache/b1-observation-supervisor-qualification/check_frontend.py').read_text().replace('b1-observation-supervisor-qualification','b1-status-panel-qualification')
value=value.replace("['npm','run','build']]", "['npm','run','build'],['uv','run','--offline','--no-project','--cache-dir',str(ROOT/'.cache/uv'),'--python','/usr/bin/python3',str(STATE/'diagnostic_3.py')]]")
value=value.replace("record={'started':", "record={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'started':")
value=value.replace("log.open('wb')", "log.open('xb')")
(state/'check_frontend.py').write_text(value)
value=(root/'.cache/b1-installed-browser-qualification/check_reference_5.py').read_text().replace('b1-installed-browser-qualification','b1-status-panel-qualification').replace('reference-5-step-', 'reference-step-').replace('reference-5-checks.json','reference-checks.json')
(state/'check_reference.py').write_text(value)
