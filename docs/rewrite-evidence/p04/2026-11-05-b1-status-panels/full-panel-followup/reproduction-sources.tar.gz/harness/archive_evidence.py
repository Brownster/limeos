# /// script
# dependencies = []
# ///
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import tarfile
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
builders=root/'.cache/stack-installed-qualification'
attempts=root/'.cache/main-consolidation/attempts'
out=root/'docs/rewrite-evidence/p04/2026-11-05-b1-status-panels'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
manifest=read(state/'inputs-1.json');packages=read(builders/'candidate-14/inputs.json')
result=read(state/'result-1.json');cleanup=read(state/'cleanup.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head==manifest['fixture_source']==manifest['package_source']==manifest['ui_source']==packages['source']==packages['ui_source']
assert manifest['binary_source']==packages['binary_source']=='e417751ba57a3945fb47e60d513c087f75d5da7b'
assert sha(builders/'candidate-14/inputs.json')==manifest['package_inputs_sha256']
phases=('diagnostic-1','diagnostic-2','frontend-1','reference-1','package-1','vm-1')
records={phase:read(attempts/('b1-status-panel-'+phase)/'record.json') for phase in phases}
assert all(row['exit_code']==0 and row['ended'] and row['inputs_unchanged'] and not row['guard_triggered'] for row in records.values())
for phase in ('frontend-1','reference-1','package-1','vm-1'):
 assert records[phase]['before']==records[phase]['after']==manifest['fixture_inputs']==packages['package_inputs']
assert len(manifest['fixture_inputs'])==749
for name,expected in manifest['fixture_inputs'].items():
 assert sha(root/name)==expected
 assert hashlib.sha256(subprocess.check_output(['git','show',f'{head}:{name}'],cwd=root)).hexdigest()==expected
assert result['summary']=='pass' and result['stage']=='complete' and result['availability_copy_verified']
assert result['package_version']==packages['version']=='0.4.14+healthui.1'
assert result['package_sha256']==packages['packages'] and result['authority_schema']==14
assert result['fixture_sha256']==manifest['guest']['p04_automation_browser_guest.py']
assert result['binary_sha256']=={name:facts['sha256'] for name,facts in packages['binaries'].items()}
assert {'frontend/dist/'+name:value for name,value in result['ui_sha256'].items()}==packages['ui']
assert result['immutable_before']==result['immutable_after'] and result['before_restart']==result['after_restart']
assert result['oom_before']==result['oom_after']=={'oom_kill':0}
history=result['final_history']
assert {key:len(value) for key,value in history.items()}=={'schedules':1,'occurrences':2,'jobs':2,'results':2,'alerts':1,'notifications':2}
assert history['schedules'][0][0]==result['schedule_id'] and history['schedules'][0][1:3]==[2,1]
assert history['occurrences'][1][2]-history['occurrences'][0][2]==60
assert len({tuple(row[:3]) for row in history['occurrences']})==2
assert {row[3] for row in history['occurrences']}=={row[0] for row in history['jobs']}=={row[0] for row in history['results']}
assert all(row[1]=='succeeded' for row in history['jobs'])
assert all(row[1:3]==['succeeded','observed'] and row[4]==0 for row in history['results'])
assert any(json.loads(row[2])['id']==result['opening']['id'] and json.loads(row[2])['acknowledged_at'] is not None for row in history['notifications'])
assert cleanup['all_recorded_original_processes_absent'] and cleanup['unique_pids']==13 and all(row['absent'] for row in cleanup['vm_scratch'])
for name,expected in manifest['guest'].items():assert sha(state/'guest-1'/name)==expected
assert sha(state/'run_1024.py')==manifest['runner_sha256']==sha(root/'tests/privileged_vm/run.py')
for name,expected in packages['repository'].items():assert sha(builders/'candidate-14/repository'/name)==expected
assert len(result['screenshots'])==5
out.mkdir(exist_ok=False)
def archive(name,path):
 target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for phase in phases:
 for name in ('record.json','output.log'):archive('checks/b1-status-panel-'+phase+'-'+name,attempts/('b1-status-panel-'+phase)/name)
for path in sorted(state.iterdir()):
 if path.is_file() and path.suffix in ('.json','.log','.txt'):archive('observations/'+path.name,path)
archive('package-inputs.json',builders/'candidate-14/inputs.json')
archive('original-build-record.json',builders/'build-12/record.json')
for name in ('dists/stable/InRelease','dists/stable/Release','dists/stable/Release.gpg','dists/stable/main/binary-amd64/Packages','limeos-archive-keyring.gpg'):archive('repository/'+name,builders/'candidate-14/repository'/name)
sources={'guest/'+path.name:path for path in sorted((state/'guest-1').glob('*.py'))}
sources.update({'harness/'+path.name:path for path in sorted(state.glob('*.py'))})
sources['harness/guard.py']=root/'.cache/main-consolidation/guard.py'
sources['harness/detached_guard.py']=builders/'detached_guard.py'
sources['harness/prepare_packages_14.py']=builders/'prepare_packages_14.py'
sources['reference/test_p04_automation_browser_guest.py']=root/'tests/reference/test_p04_automation_browser_guest.py'
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
 for name,path in sorted(sources.items()):
  data=path.read_bytes();item=tarfile.TarInfo(name);item.size,item.mode,item.mtime=len(data),0o644,0
  tar.addfile(item,io.BytesIO(data))
(out/'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
(out/'screenshots').mkdir();shots={}
for name,value in result['screenshots'].items():
 data=base64.b64decode(value['png_base64'],validate=True)
 assert data[:8]==b'\x89PNG\r\n\x1a\n' and hashlib.sha256(data).hexdigest()==value['sha256']
 width,height=struct.unpack('!II',data[16:24]);geometry=value['geometry']
 assert geometry['page_width']<=geometry['viewport_width']+1
 (out/'screenshots'/f'{name}.png').write_bytes(data)
 shots[name]={key:value[key] for key in ('selector','geometry','sha256')}
 shots[name].update(width=width,height=height,file=f'screenshots/{name}.png')
(out/'installed-result.json').write_text(json.dumps({**result,'screenshots':shots},indent=2)+'\n')
summary=dict(fixture_source=head,package_source=head,ui_source=head,binary_source=packages['binary_source'],package_and_fixture_inputs=749,original_binary_inputs=740,
 production_changes_since_binary_build=packages['production_changes_since_binary_build'],test_changes_since_binary_build=packages['test_changes_since_binary_build'],test_only_additions_since_binary_build=manifest['test_only_additions_since_binary_build'],
 native_reference_cases=19,frontend_cases=244,canonical_runner_unchanged=True,guest_modules=34,covered_browser_status_and_geometry_flow_passed=True,full_b1_p04_cutover_qualified=False,
 checks={phase:{key:row[key] for key in ('started','ended','exit_code','minimum_available_bytes','guard_triggered','inputs_unchanged')} for phase,row in records.items()},
 original_native_pids_absent=13,owned_vm_scratch_removed=True)
(out/'source-match.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(source=head,screenshots=shots,counts={key:len(value) for key,value in history.items()})))
