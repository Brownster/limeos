# /// script
# dependencies = []
# ///
from pathlib import Path
root=Path('/home/marc/Documents/github/lime-os')
builders=root/'.cache/stack-installed-qualification'
value=(builders/'prepare_packages_13.py').read_text().replace('candidate-13','candidate-14').replace('signing-13','signing-14').replace('0.4.13+coreopen.1','0.4.14+healthui.1').replace('b1-core-reader-fix-reference-1','b1-status-panel-reference-1')
value=value.replace("assert set(production_changes) == {'packaging/systemd/limeos-core.service'}", "assert set(production_changes) == {'packaging/systemd/limeos-core.service','frontend/src/HealthHistory.tsx','frontend/src/HealthPolicy.tsx','frontend/src/health-policy-controller.ts','frontend/src/style.css','frontend/tests/health-history.test.mjs','frontend/tests/health-policy.test.mjs'}")
value=value.replace('assert len(extras) == 7','assert len(extras) == 9')
value=value.replace('a1-installed-recovery-frontend-1','b1-status-panel-frontend-1')
value=value.replace("assert ui_record['head'] == record['source']", "assert ui_record['head'] == package_source")
value=value.replace("assert ui_record['before'] == record['before']", "assert ui_record['before'] == ui_record['after'] == current_inputs")
value=value.replace("if name not in production_changes: assert digest(ROOT / name) == expected, name", "assert digest(ROOT / name) == expected, name")
value=value.replace("'ui_source': record['source'], 'production_changes_since_binary_build': production_changes", "'ui_source': package_source, 'changes_since_binary_build': production_changes, 'production_changes_since_binary_build': {name:facts for name,facts in production_changes.items() if not name.startswith('frontend/tests/')}, 'test_changes_since_binary_build': {name:facts for name,facts in production_changes.items() if name.startswith('frontend/tests/')}")
value=value.replace('LimeOS disposable Core lookup fixture','LimeOS disposable B1 status UI fixture')
needle="inputs['core_unit_payloads'] = unit_facts"
extra='''        for name,expected in ui.items():
            relative = name.removeprefix('frontend/dist/')
            member = next(member for member in members if member.name.removeprefix('./') == 'usr/lib/' + profile + '/ui/' + relative)
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected
'''
assert value.count(needle)==1
value=value.replace(needle,extra+needle+"\ninputs['ui_payloads_verified_in_both_profiles'] = True\ninputs['frontend_result_sha256'] = digest(ROOT / '.cache/b1-status-panel-qualification/frontend-build.json')")
with (builders/'prepare_packages_14.py').open('x') as stream:stream.write(value)
