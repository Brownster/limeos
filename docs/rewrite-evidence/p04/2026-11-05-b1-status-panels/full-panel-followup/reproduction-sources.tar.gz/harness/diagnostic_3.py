# /// script
# requires-python = ">=3.11"
# dependencies = ["playwright==1.62.0"]
# ///
import hashlib
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
css=(root/'frontend/src/style.css').read_text()
account='<div class="account"><span>'+'8c2a4c27e5aa8d9bbc74e5f6097c692ca8da06ac531c5b490188568f4064e53e'+' · administrator</span><button>Sign out</button></div>'
schedule='<form><label>Missed observations</label><select><option>Use the most recent due occurrence</option></select></form>'
table='<div class="table-wrap"><table class="schedules-table"><tr><td>Fixture</td></tr></table></div>'
results={}
with sync_playwright() as playwright:
 browser=playwright.chromium.launch(executable_path='/usr/bin/google-chrome',headless=True,args=['--disable-dev-shm-usage'])
 try:
  page=browser.new_page(viewport=dict(width=390,height=844))
  for name,markup in [('account',account),('schedule',schedule),('table',table),('combined',account+schedule+table)]:
   page.set_content('<!doctype html><style>'+css+'</style><main class="signed-in">'+markup+'</main>')
   results[name]=page.evaluate('''() => ({width:innerWidth,scroll:document.documentElement.scrollWidth,tables:[...document.querySelectorAll('.table-wrap')].map(e=>({width:e.clientWidth,scroll_width:e.scrollWidth})),offenders:[...document.querySelectorAll('main *')].filter(e=>e.getBoundingClientRect().right>innerWidth && !e.closest('.table-wrap')).map(e=>({tag:e.tagName,class:e.className,right:e.getBoundingClientRect().right,width:e.getBoundingClientRect().width}))})''')
 finally:browser.close()
assert all(row['scroll'] == row['width'] and not row['offenders'] for row in results.values())
assert results['table']['tables'][0]['scroll_width'] > results['table']['tables'][0]['width']
value=dict(scope='Minimal read-only layout reproduction using exact current stylesheet; no installed/API acceptance',css_sha256=hashlib.sha256(css.encode()).hexdigest(),results=results)
with (state/'layout-diagnostic-3.json').open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
