# /// script
# dependencies = []
# ///
import datetime
import json
from pathlib import Path
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
phases=('diagnostic-1','diagnostic-2','frontend-1','reference-1','package-1','vm-1')
records=[json.loads((root/'.cache/main-consolidation/attempts'/('b1-status-panel-'+phase)/'record.json').read_text()) for phase in phases]
assert all(row.get('ended') and row['inputs_unchanged'] and not row['guard_triggered'] for row in records)
launches=[json.loads((state/(phase+'-launch.json' if phase!='vm-1' else 'guard-launch-1.json')).read_text()) for phase in phases]
observation=json.loads((state/'vm-process-observation-1.json').read_text())
assert len(observation['qemu'])==1
qemu=observation['qemu'][0]
pids=sorted({row['pid'] for row in records+launches+[qemu,observation['runner']]})
processes=[dict(pid=pid,absent=not (Path('/proc')/str(pid)).exists()) for pid in pids]
assert all(row['absent'] for row in processes)
arg=next(arg for arg in qemu['command'] if arg.startswith('file=') and '/disk.qcow2,format=' in arg)
scratch=Path(arg.removeprefix('file=').split(',',1)[0]).parent
assert scratch.parent==root/'.cache/main-consolidation/tmp' and scratch.name.startswith('limeos-p01-vm-')
assert not scratch.exists()
value=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=processes,unique_pids=len(pids),all_recorded_original_processes_absent=True,vm_scratch=[dict(path=str(scratch),absent=True)],unrelated_processes_stopped=False)
with (state/'cleanup.json').open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
