# /// script
# dependencies = []
# ///
from pathlib import Path
state=Path(__file__).parent
value=(state/'diagnostic.py').read_text().replace("('f'*64)", "'8c2a4c27e5aa8d9bbc74e5f6097c692ca8da06ac531c5b490188568f4064e53e'").replace('layout-diagnostic-1.json','layout-diagnostic-2.json')
(state/'diagnostic_2.py').write_text(value)
value=(state/'launch.py').read_text().replace("'diagnostic-1':", "'diagnostic-2':").replace("state/'diagnostic.py'", "state/'diagnostic_2.py'")
(state/'launch_diagnostic_2.py').write_text(value)
