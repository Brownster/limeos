# /// script
# dependencies = []
# ///
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
builders=root/'.cache/stack-installed-qualification'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
# The only untracked work is the preserved first-run evidence packet. No source
# changes or other untracked paths are admitted by this explicit exception.
status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).splitlines()
assert status==['?? docs/rewrite-evidence/p04/2026-11-05-b1-status-panels/'],status
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
packages=json.loads((builders/'candidate-14/inputs.json').read_text())
native=json.loads((root/'.cache/main-consolidation/attempts/b1-status-panel-reference-2/record.json').read_text())
assert native['exit_code']==0 and native['inputs_unchanged'] and not native['guard_triggered'] and native['ended']
assert native['head']==head and native['before']==native['after']
current=native['before'];original=packages['package_inputs']
assert set(current)==set(original)
changes={name:dict(before=original[name],after=value) for name,value in current.items() if value!=original[name]}
assert set(changes)=={'tests/privileged_vm/p04_automation_browser_guest.py','tests/reference/test_p04_automation_browser_guest.py'}
for name,expected in current.items():
 assert sha(root/name)==expected
 assert hashlib.sha256(subprocess.check_output(['git','show',f'{head}:{name}'],cwd=root)).hexdigest()==expected
for name,expected in packages['repository'].items():assert sha(builders/'candidate-14/repository'/name)==expected
guest=state/'guest-2';guest.mkdir(exist_ok=False)
for path in sorted((root/'tests/privileged_vm').glob('*.py')):shutil.copyfile(path,guest/path.name)
(guest/'installed_guest.py').write_text('import p04_automation_browser_guest as guest\nguest.main(package_version='+repr(packages['version'])+')\n')
assert sha(state/'run_1024.py')==sha(root/'tests/privileged_vm/run.py')
manifest=dict(fixture_source=head,package_source=packages['source'],ui_source=packages['ui_source'],binary_source=packages['binary_source'],fixture_inputs=current,
 package_inputs_sha256=sha(builders/'candidate-14/inputs.json'),build_record_sha256=sha(builders/'build-12/record.json'),native_record_sha256=sha(root/'.cache/main-consolidation/attempts/b1-status-panel-reference-2/record.json'),schema_source_sha256=sha(root/'crates/persistence/src/lib.rs'),
 test_only_changes_between_package_and_fixture=changes,guest_memory_mib=1024,runner_sha256=sha(state/'run_1024.py'),runner_support={'current_authority_schema.py':sha(state/'current_authority_schema.py')},
 guest={path.name:sha(path) for path in sorted(guest.glob('*.py'))},scope='Same installed UI package, corrected full-target screenshot fixture; real ordinary B1 controls/restarts/geometry with no changed application authority')
with (state/'inputs-2.json').open('x') as stream:stream.write(json.dumps(manifest,indent=2)+'\n')
for source,destination in [('launch_vm.py','launch_vm_2.py'),('observe_vm.py','observe_vm_2.py')]:
 value=(state/source).read_text()
 for before,after in [('vm-1','vm-2'),('guest-1','guest-2'),('inputs-1.json','inputs-2.json'),('result-1','result-2'),('admission-1','admission-2'),('guard-console-1','guard-console-2'),('guard-launch-1','guard-launch-2')]:value=value.replace(before,after)
 # Permit only the same documented untracked evidence directory; no source edits.
 value=value.replace("assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)","assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).splitlines()==['?? docs/rewrite-evidence/p04/2026-11-05-b1-status-panels/']")
 with (state/destination).open('x') as stream:stream.write(value)
print(json.dumps(dict(fixture=head,package=packages['source'],ui=packages['ui_source'],inputs=len(current),test_changes=changes)))
