# /// script
# dependencies = []
# ///
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import tarfile
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
out=root/'docs/rewrite-evidence/p04/2026-11-05-b1-status-panels'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=read(state/'inputs-2.json');result=read(state/'result-2.json')
packages=read(root/'.cache/stack-installed-qualification/candidate-14/inputs.json')
cleanup=read(state/'cleanup-2.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==manifest['fixture_source']
assert result['summary']=='pass' and result['stage']=='complete' and result['availability_copy_verified']
assert result['package_version']=='0.4.14+healthui.1' and result['package_sha256']==packages['packages']
assert result['fixture_sha256']==manifest['guest']['p04_automation_browser_guest.py']
assert result['binary_sha256']=={name:facts['sha256'] for name,facts in packages['binaries'].items()}
assert {'frontend/dist/'+name:value for name,value in result['ui_sha256'].items()}==packages['ui']
assert result['immutable_before']==result['immutable_after'] and result['before_restart']==result['after_restart']
assert result['oom_before']==result['oom_after']=={'oom_kill':0}
records={phase:read(root/'.cache/main-consolidation/attempts'/('b1-status-panel-'+phase)/'record.json') for phase in ('reference-2','vm-2')}
for record in records.values():
 assert record['exit_code']==0 and record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
 assert record['before']==record['after']==manifest['fixture_inputs']
for name,expected in manifest['fixture_inputs'].items():assert sha(root/name)==expected
assert {name for name,expected in manifest['fixture_inputs'].items() if packages['package_inputs'][name]!=expected}==set(manifest['test_only_changes_between_package_and_fixture'])
assert cleanup['unique_pids']==18 and cleanup['all_recorded_original_processes_absent'] and all(row['absent'] for row in cleanup['vm_scratch'])
assert len(result['screenshots'])==6
for phase in records:
 for name in ('record.json','output.log'):
  target=out/'checks'/('b1-status-panel-'+phase+'-'+name+'.gz')
  assert not target.exists();target.write_bytes(gzip.compress((root/'.cache/main-consolidation/attempts'/('b1-status-panel-'+phase)/name).read_bytes(),mtime=0))
for path in sorted(state.iterdir()):
 if path.is_file() and path.suffix in ('.json','.log','.txt'):
  target=out/'observations'/(path.name+'.gz')
  if target.exists():assert gzip.decompress(target.read_bytes())==path.read_bytes()
  else:target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
follow=out/'full-panel-followup';follow.mkdir(exist_ok=False);(follow/'screenshots').mkdir()
shots={}
for name,value in result['screenshots'].items():
 data=base64.b64decode(value['png_base64'],validate=True);geometry=value['geometry']
 width,height=struct.unpack('!II',data[16:24])
 assert data[:8]==b'\x89PNG\r\n\x1a\n' and hashlib.sha256(data).hexdigest()==value['sha256']
 assert abs(width-geometry['target_width'])<=1 and abs(height-geometry['target_height'])<=1
 assert geometry['page_width']<=geometry['viewport_width']+1
 (follow/'screenshots'/f'{name}.png').write_bytes(data)
 shots[name]={key:value[key] for key in ('selector','geometry','sha256')}
 shots[name].update(width=width,height=height,file=f'screenshots/{name}.png')
right=result['screenshots']['acknowledged-mobile-right']['geometry']['tables']
assert any(row['label']=='Recorded notification delivery' and row['scroll_left']>0 and row['scroll_width']>row['width'] for row in right)
(follow/'installed-result.json').write_text(json.dumps({**result,'screenshots':shots},indent=2)+'\n')
sources={'guest/'+path.name:path for path in sorted((state/'guest-2').glob('*.py'))}
sources.update({'harness/'+path.name:path for path in sorted(state.glob('*.py'))})
sources['harness/guard.py']=root/'.cache/main-consolidation/guard.py'
sources['harness/detached_guard.py']=root/'.cache/stack-installed-qualification/detached_guard.py'
sources['reference/test_p04_automation_browser_guest.py']=root/'tests/reference/test_p04_automation_browser_guest.py'
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
 for name,path in sorted(sources.items()):
  data=path.read_bytes();item=tarfile.TarInfo(name);item.size,item.mode,item.mtime=len(data),0o644,0
  tar.addfile(item,io.BytesIO(data))
(follow/'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
summary=dict(fixture_source=manifest['fixture_source'],package_source=manifest['package_source'],ui_source=manifest['ui_source'],binary_source=manifest['binary_source'],fixture_inputs=749,package_inputs=749,
 test_only_changes_between_package_and_fixture=manifest['test_only_changes_between_package_and_fixture'],native_reference_cases=19,frontend_cases_reused_on_unchanged_ui=244,canonical_runner_unchanged=True,
 checks={phase:{key:row[key] for key in ('started','ended','exit_code','minimum_available_bytes','guard_triggered','inputs_unchanged')} for phase,row in records.items()},original_native_pids_absent=18,owned_vm_scratch_removed=2,
 full_target_dimensions_verified=True,narrow_page_overflow_absent=True,full_b1_p04_cutover_qualified=False)
(follow/'source-match.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(source=manifest['fixture_source'],screenshots=shots)))
