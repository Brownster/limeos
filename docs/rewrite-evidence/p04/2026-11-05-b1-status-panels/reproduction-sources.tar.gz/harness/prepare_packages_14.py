# /// script
# dependencies = []
# ///
"""Package one current source and sign a disposable, offline VM repository."""
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/stack-installed-qualification'
BUILD = STATE / 'build-12'
OUT = STATE / 'candidate-14'
KEYS = STATE / 'signing-14'
VERSION = '0.4.14+healthui.1'
IMAGE = 'sha256:e0df67a00f0f3080a0d01274c4c492c1173c6e39853913864d2cf596ad726fab'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

record = json.loads((BUILD / 'record.json').read_text())
assert record['exit_code'] == 0 and record['stop_reason'] is None
assert not record['oom_killed'] and record['inputs_unchanged'] and record['container_removed']
package_source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
native_path = ROOT / '.cache/main-consolidation/attempts/b1-status-panel-reference-1/record.json'
native = json.loads(native_path.read_text())
assert native['exit_code'] == 0 and native['inputs_unchanged'] and not native['guard_triggered']
current_inputs = {name: digest(ROOT / name) for name in native['before']}
assert current_inputs == native['before'] == native['after']
production_changes = {name: {'before': expected, 'after': digest(ROOT / name)} for name, expected in record['before'].items() if digest(ROOT / name) != expected}
assert set(production_changes) == {'packaging/systemd/limeos-core.service','frontend/src/HealthHistory.tsx','frontend/src/HealthPolicy.tsx','frontend/src/health-policy-controller.ts','frontend/src/style.css','frontend/tests/health-history.test.mjs','frontend/tests/health-policy.test.mjs'}
extras = set(current_inputs) - set(record['before'])
assert len(extras) == 9 and all(name.startswith('tests/') for name in extras)
for name, expected in current_inputs.items():
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{package_source}:{name}'], cwd=ROOT)).hexdigest() == expected

binaries = json.loads((BUILD / 'binaries.json').read_text())
assert set(binaries) == {'limeos-core', 'limeos-password-worker', 'limeos-executor', 'limeos-stack-read-worker', 'limeosctl'}
for name, facts in binaries.items():
    assert digest(BUILD / 'binaries' / name) == facts['sha256'], name
ui_record_path = ROOT / '.cache/main-consolidation/attempts/b1-status-panel-frontend-1/record.json'
ui_record = json.loads(ui_record_path.read_text())
assert ui_record['exit_code'] == 0 and not ui_record['guard_triggered'] and ui_record['inputs_unchanged']
assert ui_record['head'] == package_source
assert ui_record['before'] == ui_record['after'] == current_inputs
for name, expected in ui_record['before'].items():
    assert digest(ROOT / name) == expected, name
ui = {str(path.relative_to(ROOT)): digest(path) for path in sorted((ROOT / 'frontend/dist').rglob('*')) if path.is_file()}
assert 'frontend/dist/index.html' in ui and len(ui) == 3
OUT.mkdir(exist_ok=False)
KEYS.mkdir(mode=0o700, exist_ok=False)
packages = OUT / 'packages'
packages.mkdir()
environment = os.environ.copy()
environment['TMPDIR'] = str(STATE / 'tmp')
for profile in ('standard', 'shadow'):
    subprocess.run([sys.executable, 'packaging/build.py', '--arch', 'amd64', '--version', VERSION,
                    '--profile', profile, '--binaries', str(BUILD / 'binaries'), '--output', str(packages)],
                   cwd=ROOT, env=environment, check=True)

def inside(path):
    return '/build/' + str(path.relative_to(ROOT))

command = ['docker', 'run', '--rm', '--network=none', '--read-only', '--memory=128m', '--memory-swap=128m',
           '--pids-limit=32', '--cpus=1', '--cap-drop=ALL', '--security-opt=no-new-privileges',
           '--security-opt=label=disable', '--user', '1000:1000',
           '--env', 'GNUPGHOME=' + inside(KEYS), '--env', 'TMPDIR=' + inside(STATE / 'tmp'),
           '--volume', str(ROOT) + ':/build:ro', '--volume', str(STATE) + ':' + inside(STATE),
           '--workdir', '/build', IMAGE]
subprocess.run([*command, 'gpg', '--batch', '--pinentry-mode', 'loopback', '--passphrase', '',
                '--quick-generate-key', 'LimeOS disposable B1 status UI fixture 2026-11-05', 'ed25519', 'sign', '7d'],
               check=True, cwd=ROOT)
public = subprocess.check_output([*command, 'gpg', '--batch', '--with-colons', '--list-keys'], text=True)
fingerprints = [line.split(':')[9] for line in public.splitlines() if line.startswith('fpr:')]
assert len(fingerprints) == 1 and re.fullmatch('[A-F0-9]{40}', fingerprints[0])
fingerprint = fingerprints[0]
expiry = int(next(line.split(':')[6] for line in public.splitlines() if line.startswith('pub:')))
files = sorted(packages.glob('*.deb'))
assert len(files) == 2
observed = subprocess.check_output([*command, 'sha256sum', *map(inside, files)], text=True).splitlines()
assert [line.split()[0] for line in observed] == [digest(path) for path in files]
repository = OUT / 'repository'
subprocess.run([*command, 'packaging/repository.sh', inside(repository), fingerprint, *map(inside, files)],
               check=True, cwd=ROOT)
subprocess.run([*command, 'gpgv', '--keyring', inside(repository / 'limeos-archive-keyring.gpg'),
                inside(repository / 'dists/stable/InRelease')], check=True, cwd=ROOT)
assert ui == {str(path.relative_to(ROOT)): digest(path) for path in sorted((ROOT / 'frontend/dist').rglob('*')) if path.is_file()}
inputs = {'source': package_source, 'binary_source': record['source'], 'ui_source': package_source, 'changes_since_binary_build': production_changes, 'production_changes_since_binary_build': {name:facts for name,facts in production_changes.items() if not name.startswith('frontend/tests/')}, 'test_changes_since_binary_build': {name:facts for name,facts in production_changes.items() if name.startswith('frontend/tests/')}, 'package_inputs': current_inputs, 'native_record_sha256': digest(native_path), 'version': VERSION, 'scope': 'Current AMD64 standard/shadow VM fixtures; not a published release',
          'packages': {path.name: digest(path) for path in files}, 'binaries': binaries, 'ui': ui,
          'ui_build_record_sha256': digest(ui_record_path), 'packaging_sha256': digest(ROOT / 'packaging/build.py'),
          'producer_sha256': digest(Path(__file__)),
          'repository_tool_image': IMAGE, 'package_handoff': observed,
          'signing_fingerprint': fingerprint, 'signing_key_expires': expiry,
          'repository': {str(path.relative_to(repository)): digest(path) for path in sorted(repository.rglob('*')) if path.is_file()}}
import tarfile
unit_facts = {}
for file in files:
    profile = 'limeos-shadow' if file.name.startswith('limeos-shadow_') else 'limeos'
    expected_unit = ROOT / 'packaging/systemd/limeos-core.service'
    tar_bytes = subprocess.check_output(['dpkg-deb', '--fsys-tarfile', str(file)])
    import io
    with tarfile.open(fileobj=io.BytesIO(tar_bytes)) as archive:
        members = archive.getmembers()
        assert all(member.uid == member.gid == 0 for member in members)
        member = next(member for member in members if member.name.removeprefix('./') == 'lib/systemd/system/' + profile + '-core.service')
        text = archive.extractfile(member).read().decode()
        assert 'RestrictSUIDSGID=no\n' in text and 'SystemCallFilter=@system-service openat2\n' in text
        for line in ('NoNewPrivileges=yes','CapabilityBoundingSet=','AmbientCapabilities=','MemoryMax=128M','TasksMax=32','LimitNOFILE=1024'):
            assert line + '\n' in text
        if profile == 'limeos': assert text == expected_unit.read_text()
        assert 'User=' + profile + '-core\n' in text and 'ReadWritePaths=/var/lib/' + profile + '/core\n' in text
        unit_facts[profile] = {'sha256': hashlib.sha256(text.encode()).hexdigest(), 'text': text, 'root_archive_ownership_verified': True}
        for name, facts in binaries.items():
            member = next(member for member in members if member.name.removeprefix('./') == 'usr/lib/' + profile + '/' + name)
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == facts['sha256']
        for name,expected in ui.items():
            relative = name.removeprefix('frontend/dist/')
            member = next(member for member in members if member.name.removeprefix('./') == 'usr/lib/' + profile + '/ui/' + relative)
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected
inputs['core_unit_payloads'] = unit_facts
inputs['ui_payloads_verified_in_both_profiles'] = True
inputs['frontend_result_sha256'] = digest(ROOT / '.cache/b1-status-panel-qualification/frontend-build.json')
assert current_inputs == {name: digest(ROOT / name) for name in current_inputs}
(OUT / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
print(json.dumps({'source': inputs['source'], 'version': VERSION, 'packages': inputs['packages'],
                  'signing_fingerprint': fingerprint, 'signing_key_expires': expiry,
                  'private_key_exported': False, 'repository_signature_verified': True}), flush=True)
