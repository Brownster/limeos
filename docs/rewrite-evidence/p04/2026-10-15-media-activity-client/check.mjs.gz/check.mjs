import { execFileSync, spawnSync } from "node:child_process";
import { readFileSync, writeFileSync, realpathSync } from "node:fs";
import { dirname } from "node:path";
import { createHash } from "node:crypto";

const root = process.cwd();
const out = `${root}/.cache/media-activity-client`;
const git = (...args) => execFileSync("git", args, { encoding: "utf8" }).trim();
const source = git("rev-parse", "HEAD");
const paths = git("ls-files", "frontend", "contracts/generated/types.ts", "tests/fixtures/deployment/activity/wire.json", "crates/domain/src/deployment/activity.rs", "crates/domain/src/deployment/activity/tests.rs", "crates/domain/src/operations.rs").split("\n");
const inputHashes = paths.map(path => `${createHash("sha256").update(readFileSync(path)).digest("hex")}  ${path}\n`).join("");
const resume = process.argv.includes("--metadata-only");
const previous = resume ? JSON.parse(readFileSync(`${out}/checks.json`, "utf8")) : null;
if (resume && (previous.source !== source || readFileSync(`${out}/inputs.sha256`, "utf8") !== inputHashes || previous.results.slice(0, 7).some(r => r.status !== 0))) throw new Error("Cannot resume: tested input or checks differ");
writeFileSync(`${out}/inputs.sha256`, inputHashes);
const dependencyRoot = dirname(realpathSync(`${root}/frontend/node_modules`));
for (const file of ["package.json", "package-lock.json"]) {
  if (!readFileSync(`${dependencyRoot}/${file}`).equals(readFileSync(`${root}/frontend/${file}`))) throw new Error(`Dependency source differs: ${file}`);
}
const checks = [
  ["typescript-final.log", "./frontend/node_modules/.bin/tsc", ["--noEmit", "-p", "frontend/tsconfig.json"]],
  ["client-qualified.log", "node", ["frontend/tests/media-activity-client.test.mjs"]],
  ["view-qualified.log", "node", ["frontend/tests/media-activity.test.mjs"]],
  ["whitespace.log", "git", ["diff", "--check"]],
  ["node-version.log", "node", ["--version"]],
  ["npm-version.log", "npm", ["--version"]],
  ["typescript-version.log", "./frontend/node_modules/.bin/tsc", ["--version"]],
  ["npm-tree-real.json", "npm", ["ls", "--all", "--json"], dependencyRoot],
];
const results = resume ? previous.results : [];
for (const [log, command, args, cwd = root] of resume ? checks.slice(7) : checks) {
  const started = new Date().toISOString();
  const result = spawnSync(command, args, { cwd, encoding: "utf8", maxBuffer: 4 * 1024 * 1024 });
  writeFileSync(`${out}/${log}`, `${result.stdout ?? ""}${result.stderr ?? ""}`);
  results.push({ command, args, cwd, log, status: result.status, signal: result.signal, started, ended: new Date().toISOString() });
  if (result.status !== 0) {
    writeFileSync(`${out}/checks.json`, JSON.stringify({ source, results }, null, 2) + "\n");
    throw new Error(`Check failed: ${log}; status=${result.status}`);
  }
}
if (git("rev-parse", "HEAD") !== source) throw new Error("Source changed during checks");
for (const row of readFileSync(`${out}/inputs.sha256`, "utf8").trimEnd().split("\n")) {
  const [hash, path] = row.split("  ");
  if (createHash("sha256").update(readFileSync(path)).digest("hex") !== hash) throw new Error(`Input changed: ${path}`);
}
writeFileSync(`${out}/checks.json`, JSON.stringify({ source, inputCount: paths.length, dependencyRoot, dependencyManifestsMatch: true, results }, null, 2) + "\n");
console.log(JSON.stringify({ source, inputCount: paths.length, checks: results.length, clientCases: 29, viewCases: 10 }));
