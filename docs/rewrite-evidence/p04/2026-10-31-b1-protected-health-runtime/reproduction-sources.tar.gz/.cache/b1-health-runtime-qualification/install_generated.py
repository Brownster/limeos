# /// script
# dependencies = []
# ///
"""Copy only changed outputs from the actual schema emitter."""
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/marc/Documents/github/lime-os')
STATE=ROOT/'.cache/b1-health-runtime-qualification'
changes=[]
for path in sorted((STATE/'generated').rglob('*')):
    if not path.is_file():
        continue
    target=ROOT/'contracts/generated'/path.relative_to(STATE/'generated')
    data=path.read_bytes()
    if not target.exists() or target.read_bytes()!=data:
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        changes.append({'path':str(target.relative_to(ROOT)),'sha256':hashlib.sha256(data).hexdigest()})
(STATE/'generated-delta.json').write_text(json.dumps(changes,indent=2)+'\n')
print(json.dumps(changes,indent=2))
