# /// script
# dependencies = []
# ///
"""Bind final guarded inputs, original process absence and post-run build bytes."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/b1-health-runtime-qualification'
labels = json.loads((STATE / 'final-checks.json').read_text())
records = {label: json.loads((ROOT / '.cache/main-consolidation/attempts' / label / 'record.json').read_text()) for label in labels}
expected = records[labels[0]]['before']
for label, record in records.items():
    assert record['ended'] and record['exit_code'] == 0, label
    assert record['inputs_unchanged'] and record['before'] == record['after'] == expected, label
    assert not record['guard_triggered'] and not record['observed_external_compilers'], label
    assert record['minimum_available_bytes'] >= 3 * 1024**3
for name, sha in expected.items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, name
pids = set()
for path in STATE.glob('*-launch.json'):
    launch = json.loads(path.read_text())
    pids.add(launch['pid'])
    record = json.loads((ROOT / '.cache/main-consolidation/attempts' / launch['label'] / 'record.json').read_text())
    assert record['ended']
    pids.add(record['pid'])
command = ['ps', '-p', ','.join(str(pid) for pid in sorted(pids)), '-o', 'pid,ppid,sid,stat,comm']
result = subprocess.run(command, text=True, capture_output=True, check=False)
processes = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
(STATE / 'original-process-absence.json').write_text(json.dumps(processes, indent=2) + '\n')
assert result.returncode == 1 and len(result.stdout.splitlines()) == 1, processes


def sha_file(path):
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(block)
    return sha.hexdigest()


target = ROOT / '.cache/rewrite-pool-dependencies/target/debug'
artifacts = {}
for name in ['limeos-core', 'limeos-executor', 'limeos-stack-read-worker', 'limeos-read-worker-probe', 'limeos-schema']:
    path = target / name
    if path.is_file():
        artifacts[str(path.relative_to(ROOT))] = {'bytes': path.stat().st_size, 'sha256': sha_file(path)}
summary = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'identical_guard_maps': labels, 'guarded_input_count': len(expected), 'current_inputs_match': True, 'original_processes_absent': True, 'post_run_local_debug_artifacts': artifacts, 'artifact_scope': 'Post-run build bytes only; no installed package or ARM64 candidate qualification'}
(STATE / 'final-source-observation.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'inputs': len(expected), 'final_guards': len(labels), 'original_pids_absent': len(pids)}))
