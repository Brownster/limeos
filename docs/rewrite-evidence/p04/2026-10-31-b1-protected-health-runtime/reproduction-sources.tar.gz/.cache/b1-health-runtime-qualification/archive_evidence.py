# /// script
# dependencies = []
# ///
"""Bind local protected-health qualification to committed source and keep failures."""
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/b1-health-runtime-qualification'
DEST = ROOT / 'docs/rewrite-evidence/p04/2026-10-31-b1-protected-health-runtime'
COMMIT = (STATE / 'feature-commit.txt').read_text().strip()
STORAGE = subprocess.check_output(['git', 'rev-parse', '245d53d'], cwd=ROOT, text=True).strip()
FINAL = json.loads((STATE / 'final-checks.json').read_text())
assert len(COMMIT) == 40 and not DEST.exists()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def committed(name):
    return subprocess.check_output(['git', 'show', f'{COMMIT}:{name}'], cwd=ROOT)


def put(name, data):
    path = DEST / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


records = {}
for directory in sorted((ROOT / '.cache/main-consolidation/attempts').glob('b1-health-runtime-*')):
    record = json.loads((directory / 'record.json').read_text())
    assert record.get('ended'), directory.name
    records[directory.name] = record

expected = records[FINAL[0]]['before']
for label in FINAL:
    record = records[label]
    assert record['exit_code'] == 0 and record['inputs_unchanged']
    assert record['before'] == record['after'] == expected
    assert not record['guard_triggered'] and not record['observed_external_compilers']
    assert record['minimum_available_bytes'] >= record['memory_floor_bytes'] == 3 * 1024**3
for name, sha in expected.items():
    assert digest(committed(name)) == digest((ROOT / name).read_bytes()) == sha, name

for label, record in records.items():
    directory = ROOT / '.cache/main-consolidation/attempts' / label
    for name in ['record.json', 'output.log']:
        put(f'checks/{label}/{name}.gz', gzip.compress((directory / name).read_bytes(), mtime=0))
for path in sorted(STATE.iterdir()):
    if path.is_file() and path.suffix in ['.json', '.log']:
        put(f'launch-and-local/{path.name}.gz', gzip.compress(path.read_bytes(), mtime=0))

changed = set()
for commit in [STORAGE, COMMIT]:
    changed.update(subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit], cwd=ROOT, text=True).splitlines())
changed.update([
    'docs/plans/2026-10-31-source-btrfs-device-design.md',
    'docs/plans/2026-10-31-b1-protected-health-runtime-design.md',
])
sources = {name: committed(name) for name in sorted(changed)}
for path in [*STATE.glob('*.py'), ROOT / '.cache/main-consolidation/guard.py', ROOT / '.cache/stack-installed-qualification/detached_guard.py']:
    sources[str(path.relative_to(ROOT))] = path.read_bytes()
sources['external-skills/std-bash/scripts/run_shellck.sh'] = Path('/home/marc/.codex/skills/std-bash/scripts/run_shellck.sh').read_bytes()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, data in sorted(sources.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o755 if (ROOT / name).is_file() and (ROOT / name).stat().st_mode & 0o111 else 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
put('reproduction-sources.tar.gz', gzip.compress(buffer.getvalue(), mtime=0))
for name, commit in [('storage-fix', STORAGE), ('feature', COMMIT)]:
    put(f'{name}.patch.gz', gzip.compress(subprocess.check_output(['git', 'show', '--format=fuller', '--binary', commit], cwd=ROOT), mtime=0))

groups = {}
group = 'start'
for line in (ROOT / '.cache/main-consolidation/attempts' / FINAL[0] / 'output.log').read_text().splitlines():
    if re.match(r'\s*(?:Running |Doc-tests )', line):
        group = line.strip()
    match = re.search(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', line)
    if match:
        groups[group] = {'passed': int(match[2]), 'failed': int(match[3]), 'ignored': int(match[4]), 'doctest': group.startswith('Doc-tests ')}
assert groups and not any(g['failed'] for g in groups.values())
summary = {
    'qualified_commit': COMMIT,
    'storage_fix_commit': STORAGE,
    'parent_commit': subprocess.check_output(['git', 'rev-parse', f'{COMMIT}^'], cwd=ROOT, text=True).strip(),
    'final_identical_guard_input_maps': FINAL,
    'committed_input_count': len(expected),
    'committed_inputs_match': True,
    'worktree_inputs_match': True,
    'runtime_tests_passed': sum(g['passed'] for g in groups.values() if not g['doctest']),
    'doctests_passed': sum(g['passed'] for g in groups.values() if g['doctest']),
    'cargo_test_groups': groups,
    'checks': {label: {key: record[key] for key in ['started', 'ended', 'exit_code', 'inputs_unchanged', 'guard_triggered', 'minimum_available_bytes', 'memory_floor_bytes', 'observed_external_compilers']} for label, record in records.items()},
    'draft_input_differences_from_final': {label: sorted(name for name in set(expected) | set(record['before']) if expected.get(name) != record['before'].get(name)) for label, record in records.items() if label not in FINAL},
    'reproduction_source_hashes': {name: digest(data) for name, data in sorted(sources.items())},
    'scope': 'Native local workspace and opt-in real sealed worker bootstrap/nonroot refusal; private-unit Unix credentials/clocks and real Store queue/lock tests. No installed root-positive Engine, API/UI browser journey, service resource/footprint, package/upgrade/return, ARM64/Pi or cutover qualification.',
}
put('source-match.json', (json.dumps(summary, indent=2) + '\n').encode())
print(json.dumps({'commit': COMMIT, 'inputs': len(expected), 'guards': len(records), 'runtime': summary['runtime_tests_passed'], 'doctests': summary['doctests_passed']}))
