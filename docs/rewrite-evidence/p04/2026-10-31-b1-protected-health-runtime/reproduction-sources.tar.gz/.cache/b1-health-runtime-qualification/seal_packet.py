# /// script
# dependencies = []
# ///
"""Write and verify checksums for the completed local evidence packet."""
import hashlib
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os/docs/rewrite-evidence/p04/2026-10-31-b1-protected-health-runtime')
assert (root / 'README.md').is_file() and (root / 'source-match.json').is_file()
manifest = root / 'SHA256SUMS'
assert not manifest.exists()
files = sorted(p for p in root.rglob('*') if p.is_file())
rows = [(str(p.relative_to(root)), hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
manifest.write_text(''.join(f'{sha}  {name}\n' for name, sha in rows))
for name, sha in rows:
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha
assert len(rows) == len([p for p in root.rglob('*') if p.is_file() and p != manifest])
print(f'Verified {len(rows)} packet file hashes')
