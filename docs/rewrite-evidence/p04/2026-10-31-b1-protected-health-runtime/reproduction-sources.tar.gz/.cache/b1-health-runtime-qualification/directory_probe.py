# /// script
# dependencies = []
# ///
"""Observe only owned directory descriptors on the qualification filesystem."""
import json
import os
import subprocess
import tempfile
from pathlib import Path

root=Path('/home/marc/Documents/github/lime-os/.cache/main-consolidation/tmp')
with tempfile.TemporaryDirectory(dir=root) as temporary:
    path=Path(temporary)/'subject'
    path.mkdir()
    descriptor=os.open(path,os.O_PATH|os.O_DIRECTORY|os.O_CLOEXEC)
    try:
        fs=subprocess.check_output(['stat','-f','-c','%T',str(path)],text=True).strip()
        before=os.fstat(descriptor).st_nlink
        info=dict(line.split(':',1) for line in Path(f'/proc/self/fdinfo/{descriptor}').read_text().splitlines())
        mount_id=int(info['mnt_id'])
        mount=next(line for line in Path('/proc/self/mountinfo').read_text().splitlines() if int(line.split()[0])==mount_id)
        entry=mount.split()
        device=os.fstat(descriptor).st_dev
        identity={'fd_mount_id':mount_id,'fd_device':f'{os.major(device)}:{os.minor(device)}','table_device':entry[2],'mount_root':entry[3],'mountpoint':entry[4],'resolved_path':os.readlink(f'/proc/self/fd/{descriptor}')}
        (path/'child').mkdir()
        after=os.fstat(descriptor).st_nlink
        (path/'child').rmdir()
        path.rmdir()
        detached=os.fstat(descriptor).st_nlink
    finally:
        os.close(descriptor)
result={'filesystem':fs,'live_before':before,'live_with_child':after,'detached':detached,'identity':identity,'scope':'owned qualification-disk directory only; parent/process limits unchanged'}
Path('/home/marc/Documents/github/lime-os/.cache/b1-health-runtime-qualification/directory-probe-identity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
