# /// script
# dependencies = []
# ///
"""Print compact terminal state and Cargo group totals without child double counts."""
import json
import re
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
for directory in sorted((ROOT / '.cache/main-consolidation/attempts').glob('b1-health-runtime-*')):
    record = json.loads((directory / 'record.json').read_text())
    summary = {key: record.get(key) for key in ['pid', 'started', 'ended', 'exit_code', 'inputs_unchanged', 'minimum_available_bytes', 'guard_triggered']}
    output = (directory / 'output.log').read_text()
    group = 'start'
    groups = {}
    doctest = False
    for line in output.splitlines():
        if re.match(r'\s*(?:Running |Doc-tests )', line):
            group = line.strip()
            doctest = group.startswith('Doc-tests ')
        match = re.search(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', line)
        if match:
            groups[group] = {'doctest': doctest, 'passed': int(match[2]), 'failed': int(match[3]), 'ignored': int(match[4])}
    summary['runtime'] = sum(g['passed'] for g in groups.values() if not g['doctest'])
    summary['doctests'] = sum(g['passed'] for g in groups.values() if g['doctest'])
    summary['ignored'] = sum(g['ignored'] for g in groups.values())
    summary['tail'] = output.splitlines()[-3:]
    print(json.dumps({'label': directory.name, **summary}))
