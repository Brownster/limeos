# /// script
# dependencies = []
# ///
"""Record the pinned local linter's observed bytes and official download source."""
import hashlib
import json
import subprocess
from pathlib import Path

state = Path('/home/marc/Documents/github/lime-os/.cache/b1-health-runtime-qualification')
archive = state / 'shellcheck-v0.10.0.linux.x86_64.tar.xz'
binary = state / 'shellcheck-v0.10.0/shellcheck'
wrapper = Path('/home/marc/.codex/skills/std-bash/scripts/run_shellck.sh')
result = subprocess.run([str(binary), '--version'], text=True, capture_output=True, check=True)
assert 'version: 0.10.0' in result.stdout
metadata = {'release_metadata': 'https://api.github.com/repos/koalaman/shellcheck/releases/tags/v0.10.0', 'download': 'https://github.com/koalaman/shellcheck/releases/download/v0.10.0/shellcheck-v0.10.0.linux.x86_64.tar.xz', 'version': result.stdout, 'observed_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [archive, binary, wrapper]}, 'upstream_digest': None, 'scope': 'Official pinned HTTPS release; hashes are local observations, not an upstream signature. Extracted executable only in repository cache; no host package installation.'}
(state / 'shellcheck-provenance.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({'version': '0.10.0', 'archive_sha256': metadata['observed_sha256'][str(archive)]}))
