# /// script
# dependencies = []
# ///
"""Serial source, shell and changed Python checks; no package installation."""
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/b1-health-runtime-qualification'
ruff = ROOT / '.cache/uv/archive-v0/8yVR9P26Hvq37q2-/bin/ruff'
commands = [
    ['cargo', 'fmt', '--all', '--', '--check'],
    ['uv', 'run', '--offline', '--no-project', '--python', '/usr/bin/python3', 'scripts/check_repository.py'],
    ['bash', '/home/marc/.codex/skills/std-bash/scripts/run_shellck.sh', 'packaging/debian/postinst'],
    # The skill wrapper's extensionless shebang discovery skips postinst.
    # Check the actual file explicitly as well; a skipped target is not a pass.
    [str(STATE / 'shellcheck-v0.10.0/shellcheck'), '-x', 'packaging/debian/postinst'],
    [str(ruff), 'check', 'tests/reference/test_stack_reader_profile.py'],
    [str(ruff), 'format', '--check', 'tests/reference/test_stack_reader_profile.py'],
    ['git', 'diff', '--check'],
]
results = []
environment = os.environ.copy()
environment['PATH'] = str(STATE / 'shellcheck-v0.10.0') + os.pathsep + environment['PATH']
for command in commands:
    print(json.dumps({'command': command}), flush=True)
    result = subprocess.run(command, cwd=ROOT, env=environment, check=False)
    results.append({'command': command, 'exit_code': result.returncode})
    (STATE / 'sanity-checks.json').write_text(json.dumps(results, indent=2) + '\n')
    if result.returncode:
        raise SystemExit(result.returncode)
