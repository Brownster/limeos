# /// script
# dependencies = []
# ///
"""Archive original B1 history checks after verifying their committed inputs."""
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/b1-history-qualification'
DEST = ROOT / 'docs/rewrite-evidence/p04/2026-10-30-b1-in-app-history'
COMMIT = subprocess.check_output(['git', 'rev-parse', 'f7d5946'], cwd=ROOT, text=True).strip()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def put(name, data):
    path = DEST / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def compressed(name, source):
    put(name, gzip.compress(source.read_bytes(), mtime=0))


def committed(name):
    return subprocess.check_output(['git', 'show', f'{COMMIT}:{name}'], cwd=ROOT)


assert not DEST.exists()
records = {}
for path in sorted((ROOT / '.cache/main-consolidation/attempts').glob('b1-history-*')):
    record = json.loads((path / 'record.json').read_text())
    assert record['inputs_unchanged'] and record['before'] == record['after']
    assert not record['guard_triggered']
    assert record['minimum_available_bytes'] >= record['memory_floor_bytes'] == 3 * 1024**3
    records[path.name] = record
    for name in ['record.json', 'output.log']:
        compressed(f'checks/{path.name}/{name}.gz', path / name)

final = ['b1-history-rust-1', 'b1-history-clippy-1', 'b1-history-contracts-1', 'b1-history-browser-2']
expected = records[final[0]]['before']
assert len(expected) == 699
for label in final:
    record = records[label]
    assert record['exit_code'] == 0 and record['before'] == expected
    assert not record['observed_external_compilers']
for name, sha in expected.items():
    assert digest(committed(name)) == sha, name
    assert digest((ROOT / name).read_bytes()) == sha, name

frontend = records['b1-history-frontend-2']
delta = sorted(name for name in expected if expected[name] != frontend['before'].get(name))
assert delta == ['tests/frontend/health_history.py']
build = json.loads((STATE / 'frontend-build.json').read_text())
assert build['exit_code'] == 0 and build['inputs_unchanged']
for name, sha in build['inputs'].items():
    assert digest(committed(name)) == sha, name
browser = json.loads((STATE / 'browser-2/result.json').read_text())
assert build['ui'] == browser['ui'] == browser['served_ui']
assert len(build['ui']) == 3
for name, sha in build['ui'].items():
    assert digest((ROOT / name).read_bytes()) == sha, name

for path in sorted(STATE.glob('*')):
    if path.is_file() and path.suffix in ('.json', '.log'):
        compressed(f'launch-and-local/{path.name}.gz', path)
for dirname in ['frontend-initial-render', 'browser-1', 'browser-2']:
    for path in sorted((STATE / dirname).rglob('*')):
        if not path.is_file():
            continue
        relative = str(path.relative_to(STATE))
        if path.suffix == '.png':
            put(relative, path.read_bytes())
        else:
            compressed(relative + '.gz', path)

changed = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', COMMIT], cwd=ROOT, text=True).splitlines()
sources = {name: committed(name) for name in changed}
for path in [*sorted(STATE.glob('*.py')), ROOT / '.cache/main-consolidation/guard.py', ROOT / '.cache/stack-installed-qualification/detached_guard.py']:
    sources[str(path.relative_to(ROOT))] = path.read_bytes()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, data in sorted(sources.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
put('reproduction-sources.tar.gz', gzip.compress(buffer.getvalue(), mtime=0))
patch = subprocess.check_output(['git', 'show', '--format=fuller', '--binary', COMMIT], cwd=ROOT)
put('source.patch.gz', gzip.compress(patch, mtime=0))
match = {
    'qualified_commit': COMMIT,
    'guard_head_before_feature_commit': records[final[0]]['head'],
    'final_identical_guard_input_maps': final,
    'committed_input_count': len(expected),
    'committed_inputs_match': True,
    'worktree_inputs_match': True,
    'frontend_guard_only_delta_from_committed_inputs': delta,
    'frontend_build_committed_input_count': len(build['inputs']),
    'frontend_build_inputs_match_commit': True,
    'frontend_ui_matches_browser_served_ui': True,
    'ui': build['ui'],
    'runtime_tests': 617,
    'compile_fail_doctests': 7,
    'frontend_tests': 235,
    'checks': {label: {key: record[key] for key in ['started', 'ended', 'exit_code', 'inputs_unchanged', 'guard_triggered', 'minimum_available_bytes', 'memory_floor_bytes', 'observed_external_compilers']} for label, record in records.items()},
    'reproduction_source_hashes': {name: digest(data) for name, data in sorted(sources.items())},
    'scope': 'Local Core/Store/API and closed-browser qualification only; no installed package, ARM64, protected collector, scheduler, external delivery or cutover acceptance',
}
put('source-match.json', (json.dumps(match, indent=2) + '\n').encode())
print(json.dumps({'commit': COMMIT, 'inputs': len(expected), 'frontend_inputs': len(build['inputs']), 'files': len(list(DEST.rglob('*'))), 'bytes': sum(path.stat().st_size for path in DEST.rglob('*') if path.is_file())}))
