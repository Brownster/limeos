# /// script
# dependencies = []
# ///
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/marc/Documents/github/lime-os')
STATE=ROOT/'.cache/b1-history-qualification'
label='b1-history-draft-rust-3'
assert not (ROOT/'.cache/main-consolidation/attempts'/label).exists()
available=next(int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
assert available>=4*1024**3
wrapper=ROOT/'.cache/stack-installed-qualification/detached_guard.py'
command=[sys.executable,str(wrapper),label,'cargo','test','--offline','--locked','-p','limeos-api','-p','limeos-core']
with (STATE/'draft-rust-3-console.log').open('xb') as log:
 child=subprocess.Popen(command,cwd=ROOT,start_new_session=True,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
raw=(Path('/proc')/str(child.pid)/'stat').read_text()
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':child.pid,'start_ticks':int(raw[raw.rindex(')')+1:].split()[19]),'session':os.getsid(child.pid),'process_group':os.getpgid(child.pid),'command':command,'launcher_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'guard_sha256':hashlib.sha256((ROOT/'.cache/main-consolidation/guard.py').read_bytes()).hexdigest()}
assert record['session']==record['process_group']==child.pid
(STATE/'draft-rust-3-launch.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'guard_pid':child.pid,'session':record['session'],'available_bytes':available}),flush=True)
