# /// script
# dependencies = []
# ///
"""Recover the tested fixture revision and verify its original frozen hash."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
source = (ROOT / 'tests/frontend/schedules.py').read_text()
source = source.replace('from playwright.sync_api import Error, sync_playwright', 'from playwright.sync_api import sync_playwright')
source = source.replace('    hold_enablement = False\n    held = []\n    late_delivery = None\n', '')
source = source.replace('                    if hold_enablement:\n                        held.append(route)\n                        return\n                    needs_sign_in = not enabled\n', '')
source = source.replace('"reauthenticate": needs_sign_in', '"reauthenticate": True')
confirmed = source.index('"Scheduling permission confirmed."')
start = source.rfind('            page.get_by_label("Current password"', 0, confirmed)
finish = source.index('            page.screenshot(', confirmed)
assert start != -1
source = source[:start] + source[finish:]
source = source.replace('len(mutations) == 8', 'len(mutations) == 6')
source = source.replace('                        "late_disposed_response": late_delivery,\n', '')
source = source.replace('                            "already-enabled response retains the current session",\n', '')
source = source.replace('                            "close/reopen disposes a pending credential request",\n', '')
target = ROOT / '.cache/schedules-ui/browser-2-fixture.py'
assert not target.exists()
target.write_text(source)
record = json.loads((ROOT / '.cache/main-consolidation/attempts/schedules-ui-browser-2/record.json').read_text())
expected = record['before']['tests/frontend/schedules.py']
actual = hashlib.sha256(target.read_bytes()).hexdigest()
print(json.dumps({'expected': expected, 'actual': actual, 'matches': expected == actual}))
