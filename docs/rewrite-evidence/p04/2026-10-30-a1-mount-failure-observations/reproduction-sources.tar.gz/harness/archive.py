# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Seal qualified read-only observations without claiming installed coverage."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-mount-failure-qualification'
BUILDERS = ROOT / '.cache/stack-installed-qualification'
ATTEMPTS = ROOT / '.cache/main-consolidation/attempts'
OUT = ROOT / 'docs/rewrite-evidence/p04/2026-10-30-a1-mount-failure-observations'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def archive(name, path):
    target = OUT / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
fixture = json.loads((STATE / 'inputs-1.json').read_text())
packages = json.loads((BUILDERS / 'candidate-11/inputs.json').read_text())
build = json.loads((BUILDERS / 'build-11/record.json').read_text())
assert head == fixture['fixture_source']
assert fixture['product_source'] == packages['source'] == build['source']
assert sha(BUILDERS / 'candidate-11/inputs.json') == fixture['package_inputs_sha256']
current = {name: sha(ROOT / name) for name in build['before']}
assert {n for n in current if current[n] != build['before'][n]} == set(fixture['test_only_changes_since_package_build'])
for name, expected in current.items():
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=ROOT)).hexdigest() == expected, name
for name, expected in fixture['guest'].items():
    assert sha(STATE / 'guest-1' / name) == expected, name
assert sha(STATE / 'run_1024.py') == fixture['runner_sha256'] == sha(ROOT / 'tests/privileged_vm/run.py')
for name, expected in json.loads((STATE / 'preserved-attempt-1.json').read_text())['files'].items():
    assert sha(ROOT / name) == expected, name
second = json.loads((STATE / 'inputs-2.json').read_text())
assert second['guest'] == fixture['guest'] and second['parent_inputs_sha256'] == sha(STATE / 'inputs-1.json')
assert second['preserved_parent_sha256'] == sha(STATE / 'preserved-attempt-1.json')
native = json.loads((ATTEMPTS / 'a1-mount-failure-reference-1/record.json').read_text())
assert native['before'] == native['after'] == current and native['exit_code'] == 0 and native['inputs_unchanged'] and not native['guard_triggered']
assert 'Ran 97 tests' in (ATTEMPTS / 'a1-mount-failure-reference-1/output.log').read_text()
red = json.loads((STATE / 'sqlite-lifetime-red.json').read_text())
assert red['expected_red'] and red['failures'] == 1 and red['errors'] == 0
assert red['regression_source_sha256'] == sha(ROOT / 'tests/reference/test_p04_mounts_guest.py')
runs = []
for number in (1, 2):
    attempt = ATTEMPTS / f'a1-mount-failure-vm-{number}'
    record = json.loads((attempt / 'record.json').read_text())
    assert record['head'] == head and record['before'] == record['after'] == current
    assert record['exit_code'] == 1 and record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
    log = (attempt / 'output.log').read_text()
    f = next(json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith('A1_FAILURE '))
    assert 'action' not in f and 'job' not in f and 'execution_after_failure' not in f
    assert f['fixture_sha256'] == fixture['guest']['p04_mounts_guest.py']
    assert f['authority_schema'] == 12 and f['schema_source_sha256'] == fixture['schema_source_sha256']
    assert f['package_version'] == packages['version']
    for name, expected in f['binary_sha256'].items():
        assert expected == packages['binaries'][name]['sha256'], name
    if number == 1:
        assert f['stage'] == 'pre_effect_api_refusals'
        event = next(json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith('A1_ADMISSION_DIAGNOSTIC '))
        assert event['phase'] == 'scan.process_ids_changed' and event['detail']['added'][0] == 7697
        assert event['detail']['added_count'] == 1 and event['detail']['removed_count'] == 0
    else:
        assert f['stage'] == 'fixture_docker_startup' and f['error'] == 'Fixture Docker startup attempt limit exceeded'
    scratch = set(re.findall(r'/home/marc/Documents/github/lime-os/\.cache/main-consolidation/tmp/limeos-p01-vm-[a-z0-9_]+', log))
    assert len(scratch) == 1 and all(not Path(p).exists() for p in scratch)
    runs.append({k:record[k] for k in ('started','ended','exit_code','minimum_available_bytes','inputs_unchanged','guard_triggered')}
                | {'stage': f['stage'], 'error': f['error'], 'positive_job_created': False, 'vm_scratch_removed': True})
OUT.mkdir(exist_ok=False)
for label in ('a1-mount-failure-reference-1', 'a1-sqlite-lifetime-red-1', 'a1-mount-failure-vm-1', 'a1-mount-failure-vm-2'):
    for name in ('record.json', 'output.log'):
        archive('checks/' + label + '-' + name, ATTEMPTS / label / name)
for number in (1, 2):
    for name in (f'inputs-{number}.json', f'admission-{number}.json', f'guard-launch-{number}.json', f'guard-console-{number}.log',
                 f'result-{number}-vm-failure.txt', f'result-{number}-startup-console.txt'):
        archive(name, STATE / name)
for name in ('preserved-attempt-1.json','sqlite-lifetime-red.json','local-checks.json',*[f'local-check-{i}.log' for i in range(1,5)]):
    archive(name, STATE / name)
archive('package-inputs.json', BUILDERS / 'candidate-11/inputs.json')
archive('build-record.json', BUILDERS / 'build-11/record.json')
files = {'guest/' + p.name:p for p in sorted((STATE / 'guest-1').glob('*.py'))}
files.update({'runner/' + n:STATE / n for n in ('run_1024.py','current_authority_schema.py')})
files.update({'harness/' + n:BUILDERS / n for n in ('prepare_mount_failure_guest.py','launch_mount_failure_vm.py','launch_mount_failure_vm_2.py','detached_guard.py')})
files.update({'harness/guard.py': ROOT / '.cache/main-consolidation/guard.py','harness/archive.py': Path(__file__),
              'harness/sqlite_lifetime_red.py': STATE / 'sqlite_lifetime_red.py',
              'reference/test_p04_mounts_guest.py':ROOT / 'tests/reference/test_p04_mounts_guest.py'})
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for name,path in sorted(files.items()):
        data=path.read_bytes(); info=tarfile.TarInfo(name)
        info.size,info.mode,info.mtime=len(data),0o644,0
        tar.addfile(info,io.BytesIO(data))
(OUT/'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
summary={'fixture_source':head,'product_source':build['source'],'recorded_inputs_match_commit':len(current),
         'native_reference_tests':97,'native_precommit_record_head':native['head'],
         'sqlite_descriptor_regression':red,'runs':runs,'installed_execution_capture_exercised':False,
         'a1_accepted':False,'earlier_process_or_fd_causes_identified':False,'production_pi_accessed':False}
(OUT/'source-match.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'fixture_source':head,'native_tests':97,'expected_red_proven':True,'runs':runs,'a1_accepted':False}))
