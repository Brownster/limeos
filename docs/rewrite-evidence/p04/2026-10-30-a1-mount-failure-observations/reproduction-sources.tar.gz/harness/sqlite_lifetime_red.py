# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Exercise the new descriptor regression against the original query helper."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import unittest
import warnings

ROOT = Path('/home/marc/Documents/github/lime-os')
sys.path.insert(0, str(ROOT))
from tests.reference import test_p04_mounts_guest as regression

BASELINE = '7796359'
source = subprocess.check_output(
    ['git', 'show', BASELINE + ':tests/privileged_vm/p04_mounts_guest.py'], cwd=ROOT, text=True
)
node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'query')
original = ast.get_source_segment(source, node)
assert 'with sqlite3.connect' in original and 'closing' not in original
# Only replace the in-memory helper in this disposable test process. No source,
# real service, authority database or process limit changes.
exec(compile(original, '<original-query-helper>', 'exec'), regression.guest.__dict__)
warnings.simplefilter('ignore', ResourceWarning)
suite = unittest.TestSuite([regression.FailureObservations(
    'test_read_connections_close_without_waiting_for_garbage_collection'
)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
record = {
    'baseline_source': subprocess.check_output(['git', 'rev-parse', BASELINE], cwd=ROOT, text=True).strip(),
    'original_query_sha256': hashlib.sha256(original.encode()).hexdigest(),
    'regression_source_sha256': hashlib.sha256(Path(regression.__file__).read_bytes()).hexdigest(),
    'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'expected_red': result.testsRun == 1 and len(result.failures) == 1 and not result.errors,
}
assert record['expected_red'], record
(Path(__file__).with_name('sqlite-lifetime-red.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
