# /// script
# dependencies = []
# ///
"""Seal the completed packet, including its final README."""
import hashlib
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os/docs/rewrite-evidence/p04/2026-10-31-b1-container-admission-recovery')
assert (root / 'README.md').is_file()
manifest = root / 'SHA256SUMS'
assert not manifest.exists()
rows = [(str(p.relative_to(root)), hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file()]
manifest.write_text(''.join(f'{sha}  {name}\n' for name, sha in rows))
for name, sha in rows:
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha
print(f'Verified {len(rows)} packet hashes')
