# /// script
# dependencies = []
# ///
"""Freeze committed helpers and verify unchanged product/package inputs."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-fixture-readiness'
BUILD = ROOT / '.cache/stack-installed-qualification/build-5'
PACKAGES = ROOT / '.cache/stack-installed-qualification/candidate-5'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
record = json.loads((BUILD / 'record.json').read_text())
assert record['exit_code'] == 0 and record['inputs_unchanged'] and record['container_removed']
verified = 0
for name, expected in record['before'].items():
    if not name.startswith('tests/'):
        assert digest(ROOT / name) == expected, name
        verified += 1
inputs = json.loads((PACKAGES / 'inputs.json').read_text())
for name, expected in inputs['packages'].items():
    assert digest(PACKAGES / 'repository/pool/main' / name) == expected
for name, expected in inputs['binaries'].items():
    assert digest(BUILD / 'binaries' / name) == expected['sha256']
guest = STATE / 'guest-3'
guest.mkdir()
for source in sorted((ROOT / 'tests/privileged_vm').glob('*.py')):
    shutil.copyfile(source, guest / source.name)
shutil.copyfile(ROOT / '.cache/a1-task-difference/guest/namespace_census.py', guest / 'namespace_census.py')
shutil.copyfile(STATE / 'installed_guest.py', guest / 'installed_guest.py')
runner = ROOT / '.cache/stack-installed-qualification/run_384.py'
original = ROOT / 'tests/privileged_vm/run.py'
assert runner.read_text() == original.read_text().replace('"2048" if args.build_bundle else "1024"', '"2048" if args.build_bundle else "384"')
manifest = {'fixture_source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'product_source': record['source'], 'unchanged_non_test_product_inputs': verified,
            'packages': inputs['packages'], 'binaries': inputs['binaries'],
            'package_inputs_sha256': digest(PACKAGES / 'inputs.json'),
            'guest_memory_mib': 384, 'runner_sha256': digest(runner),
            'only_runner_change': 'non-build guest memory 1024 to 384 MiB; service ceilings and assertions unchanged',
            'upgrade_qualification': False,
            'guest': {p.name: digest(p) for p in sorted(guest.glob('*.py'))}}
(STATE / 'inputs-3.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'fixture_source': manifest['fixture_source'], 'product_source': record['source'], 'non_test_inputs_matched': verified, 'files': len(manifest['guest'])}))
