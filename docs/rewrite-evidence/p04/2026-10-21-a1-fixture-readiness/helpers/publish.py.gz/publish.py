# /// script
# dependencies = []
# ///
"""Archive source-bound A1 setup and native schedule UI evidence separately."""
import ast
import datetime
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
ATTEMPTS = ROOT / '.cache/main-consolidation/attempts'
BASE = ROOT / 'docs/rewrite-evidence/p04'
UI = BASE / '2026-10-21-health-schedule-ui'
A1 = BASE / '2026-10-21-a1-fixture-readiness'
SOURCE = '3e494a0'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def archive(packet, source, relative):
    destination = packet / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    if destination.exists():
        assert gzip.decompress(destination.read_bytes()) == data, relative
    else:
        destination.write_bytes(gzip.compress(data, mtime=0))

def checks(packet, labels):
    rows = []
    for label in labels:
        record = json.loads((ATTEMPTS / label / 'record.json').read_text())
        assert 'exit_code' in record and record['inputs_unchanged']
        for name in ('record.json', 'output.log'):
            archive(packet, ATTEMPTS / label / name, f'checks/{label}-{name}.gz')
        rows.append({'label': label, **{key: record[key] for key in ('exit_code', 'guard_triggered', 'minimum_available_bytes', 'inputs_unchanged')}})
    return rows

ui_labels = ['schedules-ui-types-1', 'schedules-ui-focused-1', 'schedules-ui-all-1', 'schedules-ui-build-1', 'schedules-ui-build-2', 'schedules-ui-browser-lint-1', 'schedules-ui-browser-lint-2', 'schedules-ui-browser-1', 'schedules-ui-browser-2', 'schedules-ui-browser-3', 'schedules-ui-reference-final']
a1_labels = ['a1-fixture-readiness-focused-1', 'a1-fixture-readiness-lint-1', 'a1-fixture-readiness-reference-1', 'a1-fixture-readiness-lint-2', 'a1-fixture-readiness-reference-2', 'a1-fixture-readiness-deadline-red-1', 'a1-fixture-readiness-lint-3', 'a1-fixture-readiness-reference-3', 'a1-fixture-readiness-lint-4', 'a1-fixture-readiness-vm-1', 'schedules-ui-reference-final']
ui_checks, a1_checks = checks(UI, ui_labels), checks(A1, a1_labels)
matches = []
for label in ('schedules-ui-all-1', 'schedules-ui-build-2', 'schedules-ui-browser-2'):
    record = json.loads((ATTEMPTS / label / 'record.json').read_text())
    count = 0
    for name, expected in record['before'].items():
        if name.startswith('frontend/'):
            assert sha((ROOT / name).read_bytes()) == expected, (label, name)
            committed = subprocess.check_output(['git', 'show', f'{SOURCE}:{name}'], cwd=ROOT)
            assert sha(committed) == expected
            count += 1
    matches.append({'label': label, 'frontend_inputs_matching_committed_source': count})
(UI / 'source-match.json').write_text(json.dumps({'source': subprocess.check_output(['git', 'rev-parse', SOURCE], cwd=ROOT, text=True).strip(), 'checks': matches}, indent=2) + '\n')
fixture = ROOT / '.cache/schedules-ui/browser-2-fixture.py'
expected = json.loads((ATTEMPTS / 'schedules-ui-browser-2/record.json').read_text())['before']['tests/frontend/schedules.py']
assert sha(fixture.read_bytes()) == expected
archive(UI, fixture, 'browser-2-fixture.py.gz')
archive(UI, ROOT / 'tests/frontend/schedules.py', 'current-expanded-fixture.py.gz')
archive(UI, ROOT / '.cache/schedules-ui/preserve_browser_2.py', 'preserve-tested-fixture.py.gz')
for attempt in (1, 2, 3):
    for path in sorted((ROOT / f'.cache/schedules-ui/browser-{attempt}').glob('*')):
        archive(UI, path, f'browser-{attempt}/{path.name}.gz')
assets = {}
for path in sorted((ROOT / 'frontend/dist').rglob('*')):
    if path.is_file():
        assets[str(path.relative_to(ROOT))] = sha(path.read_bytes())
        archive(UI, path, f'preview/{path.name}.gz')

setup = ROOT / '.cache/a1-fixture-readiness'
inputs = json.loads((setup / 'inputs-3.json').read_text())
(A1 / 'inputs-3.json').write_bytes((setup / 'inputs-3.json').read_bytes())
(A1 / 'admission-1.json').write_bytes((setup / 'admission-1.json').read_bytes())
for name, expected in inputs['guest'].items():
    source = setup / 'guest-3' / name
    assert sha(source.read_bytes()) == expected
    archive(A1, source, f'guest/{name}.gz')
for name in ('prepare.py', 'prepare_3.py', 'run_once.py'):
    archive(A1, setup / name, f'helpers/{name}.gz')
archive(A1, ROOT / '.cache/stack-installed-qualification/run_384.py', 'helpers/run_384.py.gz')
sys.path.insert(0, str(ROOT / 'tests/privileged_vm'))
from guest import executor_probe_code
client = executor_probe_code()
ast.parse(client)
(A1 / 'client-import-proof.json').write_text(json.dumps({'module': 'tests/privileged_vm/guest.py', 'module_sha256': sha((ROOT / 'tests/privileged_vm/guest.py').read_bytes()), 'function': 'executor_probe_code', 'client_sha256': sha(client.encode()), 'import_and_parse_passed': True, 'client_executed': False}, indent=2) + '\n')
owned = []
for line in subprocess.check_output(['ps', '-eo', 'pid,comm'], text=True).splitlines()[1:]:
    pid, name = line.split(maxsplit=1)
    if not (name.startswith('chrome') or name.startswith('qemu-system')):
        continue
    try:
        command = (Path('/proc') / pid / 'cmdline').read_bytes()
    except FileNotFoundError:
        continue
    if str(ROOT / '.cache/main-consolidation/tmp').encode() in command:
        owned.append(int(pid))
assert not owned
audit = {'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'owned_test_chrome_or_qemu_pids': owned, 'production_access': False, 'push_performed': False}
for packet, results in ((UI, ui_checks), (A1, a1_checks)):
    (packet / 'post-run-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    (packet / 'checks-summary.json').write_text(json.dumps(results, indent=2) + '\n')
    archive(packet, ROOT / '.cache/main-consolidation/guard.py', 'helpers/guard.py.gz')
    archive(packet, Path(__file__), 'helpers/publish.py.gz')
    if packet == UI:
        (packet / 'production-ui.json').write_text(json.dumps(assets, indent=2) + '\n')
    rows = [f'{sha(path.read_bytes())}  {path.relative_to(packet)}' for path in sorted(packet.rglob('*')) if path.is_file() and path.name != 'SHA256SUMS']
    (packet / 'SHA256SUMS').write_text('\n'.join(rows) + '\n')
    print(json.dumps({'packet': str(packet.relative_to(ROOT)), 'checksummed_files': len(rows)}))
