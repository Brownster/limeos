# /// script
# dependencies = []
# ///
"""Start only with a guest margin; retain the unchanged 3-GiB stop guard."""
import datetime
import json
import os
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
threshold = 3 * 1024**3 + 512 * 1024**2
admission = {'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'available_bytes': available,
             'guest_start_threshold_bytes': threshold, 'runtime_stop_floor_bytes': 3 * 1024**3,
             'admitted': available >= threshold, 'guest_memory_mib': 384}
(ROOT / '.cache/a1-fixture-readiness/admission-1.json').write_text(json.dumps(admission, indent=2) + '\n')
print(json.dumps(admission), flush=True)
if not admission['admitted']:
    raise SystemExit(75)
os.execvp('uv', ['uv', 'run', '--offline', '--no-project', '--no-managed-python',
                 '.cache/main-consolidation/guard.py', 'a1-fixture-readiness-vm-1',
                 'uv', 'run', '--offline', '--no-project', '--no-managed-python',
                 '.cache/stack-installed-qualification/run_384.py',
                 '--image', '.cache/a1-namespace-review/debian-12-genericcloud-amd64.qcow2',
                 '--checksums', '.cache/a1-namespace-review/SHA512SUMS',
                 '--repository', '.cache/stack-installed-qualification/candidate-5/repository',
                 '--guest-script', '.cache/a1-fixture-readiness/guest-3/installed_guest.py',
                 '--storage-disks', '--output', '.cache/a1-fixture-readiness/result-1.json'])
