# /// script
# dependencies = []
# ///
"""Run the remaining lightweight repository checks against the frozen map."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/b1-poll-qualification'
FINAL = ['b1-poll-rust-4','b1-poll-clippy-2','b1-poll-contracts-1','b1-poll-frontend-1','b1-poll-idle-1']
records = {label: json.loads((ROOT / '.cache/main-consolidation/attempts' / label / 'record.json').read_text()) for label in FINAL}
expected = records[FINAL[0]]['before']
for label, record in records.items():
    assert record.get('ended') and record['exit_code'] == 0 and record['inputs_unchanged'], label
    assert record['before'] == record['after'] == expected, label
    assert not record['guard_triggered'] and not record['observed_external_compilers'], label


def matches():
    return all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha for name,sha in expected.items())


assert matches()
result = {'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'guard_reference':FINAL[0],'input_count':len(expected),'inputs_match_before':True,'checks':[]}
for number, command in enumerate([['cargo','fmt','--all','--','--check'],['python3','scripts/check_repository.py'],['git','diff','--check']],1):
    log = STATE / f'local-check-{number}.log'
    with log.open('wb') as stream:
        check = subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
    result['checks'].append({'command':command,'exit_code':check.returncode,'log':log.name})
    print(json.dumps(result['checks'][-1]),flush=True)
    assert check.returncode == 0, log.read_text()[-4000:]
result['inputs_match_after'] = matches()
(STATE / 'local-checks.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['inputs_match_after']
(STATE / 'final-checks.json').write_text(json.dumps(FINAL,indent=2)+'\n')
print(json.dumps({'final_guards':len(FINAL),'identical_input_count':len(expected)}))
