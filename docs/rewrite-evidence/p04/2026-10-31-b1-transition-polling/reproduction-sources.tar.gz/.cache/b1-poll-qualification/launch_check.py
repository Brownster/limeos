# /// script
# dependencies = []
# ///
"""Launch one closed local validation phase under the detached memory guard."""
import argparse,datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/marc/Documents/github/lime-os')
STATE=ROOT/'.cache/b1-poll-qualification'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase',choices=['baseline','idle','schema','rust','clippy','contracts','frontend'])
parser.add_argument('attempt',type=int)
args=parser.parse_args()
assert 1<=args.attempt<=100
commands={
 'idle':['cargo','test','--offline','--locked','-p','limeos-persistence','--lib','automation::completion::polling::tests::simulated_day_of_unchanged_polls_has_zero_database_and_process_writes','--','--exact','--nocapture'],
 'baseline':['cargo','test','--offline','--locked','-p','limeos-persistence','--lib','automation::completion::tests::unchanged_queued_health_samples_write_only_bookkeeping','--','--exact','--nocapture'],
 'schema':['cargo','run','--offline','--locked','-p','limeos-schema','--',str(STATE/'generated')],
 'rust':['cargo','test','--offline','--locked','-p','limeos-api','-p','limeos-core','-p','limeos-domain','-p','limeos-persistence'],
 'clippy':['cargo','clippy','--offline','--locked','-p','limeos-domain','-p','limeos-api','-p','limeos-core','-p','limeos-schema','-p','limeos-persistence','--all-targets','--','-D','warnings'],
 'contracts':[sys.executable,'scripts/check_contracts.py'],
 'frontend':[sys.executable,str(STATE/'check_frontend.py')],
}
command=commands[args.phase]
label=f'b1-poll-{args.phase}-{args.attempt}'
assert not (ROOT/'.cache/main-consolidation/attempts'/label).exists()
assert not (STATE/f'{args.phase}-{args.attempt}-launch.json').exists()
available=next(int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
threshold=4*1024**3
busy=[v.strip() for v in subprocess.check_output(['ps','-eo','comm'],text=True).splitlines() if v.strip() in ('cargo','rustc','rustdoc')]
admission={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'available_bytes':available,'start_threshold_bytes':threshold,'runtime_stop_floor_bytes':3*1024**3,'external_compilers':busy,'admitted':available>=threshold and not busy}
with (STATE/f'{args.phase}-{args.attempt}-admission.json').open('x') as stream: stream.write(json.dumps(admission,indent=2)+'\n')
print(json.dumps(admission),flush=True)
if not admission['admitted']: raise SystemExit(75)
wrapper=ROOT/'.cache/stack-installed-qualification/detached_guard.py'
with (STATE/f'{args.phase}-{args.attempt}-console.log').open('xb') as log:
 child=subprocess.Popen([sys.executable,str(wrapper),label,*command],cwd=ROOT,start_new_session=True,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
raw=(Path('/proc')/str(child.pid)/'stat').read_text()
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':child.pid,'start_ticks':int(raw[raw.rindex(')')+1:].split()[19]),'session':os.getsid(child.pid),'process_group':os.getpgid(child.pid),'phase':args.phase,'label':label,'command':command,'launcher_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'guard_sha256':hashlib.sha256((ROOT/'.cache/main-consolidation/guard.py').read_bytes()).hexdigest()}
assert record['session']==record['process_group']==child.pid
(STATE/f'{args.phase}-{args.attempt}-launch.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'guard_pid':child.pid,'session':record['session'],'label':label}),flush=True)
