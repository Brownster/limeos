# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Package the profile fix with an explicit identity bridge to unchanged binaries."""
import hashlib
import importlib.util
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STATE = Path(__file__).resolve().parent
BUILD = STATE / "build-2"
OUT = STATE / "candidate-3"
VERSION = "0.4.5+stack.3"
IMAGE = "sha256:e0df67a00f0f3080a0d01274c4c492c1173c6e39853913864d2cf596ad726fab"
spec = importlib.util.spec_from_file_location("guard_inputs", ROOT / ".cache/main-consolidation/guard.py")
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
spec = importlib.util.spec_from_file_location("package_builder", ROOT / "packaging/build.py")
package = importlib.util.module_from_spec(spec)
spec.loader.exec_module(package)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

old = json.loads((BUILD / "record.json").read_text())
assert old["exit_code"] == 0 and old["stop_reason"] is None and old["inputs_unchanged"] and old["container_removed"]
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT)
source = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
prefixes = ("Cargo.", "rust-toolchain", ".cargo/", "bins/", "crates/", "contracts/generated/", "frontend/")
previous_inputs = {name: value for name, value in old["before"].items() if name.startswith(prefixes)}
current_inputs = {name: value for name, value in guard.snapshot().items() if name.startswith(prefixes)}
assert previous_inputs == current_inputs, "Application source differs: a new release build is required"
binaries = json.loads((BUILD / "binaries.json").read_text())
for name, expected in binaries.items():
    assert digest(BUILD / "binaries" / name) == expected["sha256"]
ui = json.loads((ROOT / "docs/rewrite-evidence/p04/2026-10-20-stack-inventory-runtime/manifest.json").read_text())["production_ui"]
for name, expected in ui.items():
    assert digest(ROOT / name) == expected
OUT.mkdir(exist_ok=False)
packages = OUT / "packages"
packages.mkdir()
payloads = {}
for shadow in (False, True):
    profile = "shadow" if shadow else "standard"
    subprocess.run(["uv", "run", "--offline", "--no-project", "--no-managed-python", "packaging/build.py", "--arch", "amd64", "--version", VERSION, "--profile", profile, "--binaries", str(BUILD / "binaries"), "--output", str(packages)], cwd=ROOT, check=True, timeout=120)
    name = "limeos-shadow" if shadow else "limeos"
    deb = packages / f"{name}_{VERSION}_amd64.deb"
    unit_path = f"lib/systemd/system/{name}-storage-reader.service"
    binary_paths = {f"usr/lib/{name}/{binary}": binary for binary in binaries}
    observed = {"binaries": {}, "unit_sha256": None}
    child = subprocess.Popen(["dpkg-deb", "--fsys-tarfile", str(deb)], stdout=subprocess.PIPE)
    try:
        with tarfile.open(fileobj=child.stdout, mode="r|") as archive:
            for entry in archive:
                path = entry.name.removeprefix("./")
                if path not in binary_paths and path != unit_path:
                    continue
                assert entry.isfile() and entry.uid == 0 and entry.gid == 0 and entry.mode & 0o022 == 0
                stream = archive.extractfile(entry)
                if path in binary_paths:
                    binary = binary_paths[path]
                    expected = binaries[binary]
                    data = stream.read(expected["bytes"] + 1)
                    assert len(data) == expected["bytes"] and hashlib.sha256(data).hexdigest() == expected["sha256"]
                    observed["binaries"][binary] = expected["sha256"]
                else:
                    data = stream.read(65537)
                    expected = package.profile_text((ROOT / "packaging/systemd/limeos-storage-reader.service").read_text(), shadow).encode()
                    assert data == expected
                    observed["unit_sha256"] = hashlib.sha256(data).hexdigest()
        assert child.wait(timeout=15) == 0
    finally:
        child.stdout.close()
        if child.poll() is None:
            child.terminate()
            child.wait(timeout=10)
    assert len(observed["binaries"]) == 5 and observed["unit_sha256"]
    payloads[profile] = observed

command = ["docker", "run", "--rm", "--network=none", "--read-only", "--memory=128m", "--pids-limit=32", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--security-opt=label=disable", "--user", "1000:1000", "--env", "GNUPGHOME=/build/.cache/a1-namespace-review/gnupg", "--env", "TMPDIR=/build/.cache/stack-installed-qualification/tmp", "--volume", str(ROOT) + ":/build", "--workdir", "/build", IMAGE]
def inside(path):
    return "/build/" + str(path.relative_to(ROOT))

files = sorted(packages.glob("*.deb"))
handoff = subprocess.check_output([*command, "sha256sum", *map(inside, files)], text=True, timeout=120).splitlines()
assert [line.split()[0] for line in handoff] == [digest(path) for path in files]
fingerprint = json.loads((ROOT / ".cache/a1-namespace-review/inputs.json").read_text())["signing_fingerprint"]
subprocess.run([*command, "packaging/repository.sh", inside(OUT / "repository"), fingerprint, *map(inside, files)], cwd=ROOT, check=True, timeout=120)
inputs = {"source": source, "binary_source": old["source"], "binary_build_record_sha256": digest(BUILD / "record.json"), "application_inputs_identical": current_inputs, "version": VERSION, "scope": "Reader profile-only package correction; all five binaries reused after exact application-input equality", "binaries": binaries, "ui": ui, "packages": {path.name: digest(path) for path in files}, "payloads": payloads, "packaging_sha256": digest(ROOT / "packaging/build.py"), "reader_unit_sha256": digest(ROOT / "packaging/systemd/limeos-storage-reader.service"), "repository_tool_image": IMAGE, "package_handoff": handoff}
(OUT / "inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
print(json.dumps({"source": source, "binary_source": old["source"], "application_inputs_identical": len(current_inputs), "version": VERSION, "packages": inputs["packages"]}), flush=True)
