"""Capture genuine namespace mountinfo rendering in an isolated small VM."""
import json
import os
import subprocess
import sys
from pathlib import Path

assert os.geteuid() == 0 and Path("/etc/hostname").read_text().strip() == "limeos-p01-test"
output = Path(sys.argv[2])
target = Path("/run/limeos-nsfs-probe")
target.touch(mode=0o600)
child = subprocess.Popen(["unshare", "--net", "--", "sleep", "30"])
mounted = False
try:
    # Readiness observes a genuine distinct namespace before binding its handle.
    import time
    deadline = time.monotonic() + 5
    while os.readlink(f"/proc/{child.pid}/ns/net") == os.readlink("/proc/self/ns/net"):
        assert child.poll() is None and time.monotonic() < deadline
        time.sleep(0.01)
    subprocess.run(["mount", "--bind", f"/proc/{child.pid}/ns/net", str(target)], check=True, timeout=5)
    mounted = True
    table = Path("/proc/1/mountinfo").read_bytes()
    assert len(table) <= 65536
    rows = [line.decode() for line in table.splitlines() if b" - nsfs " in line]
    assert rows and any(not line.split()[3].startswith("/") for line in rows)
    result = {"scope": "Kernel namespace mount rendering diagnostic; no application acceptance", "status": "passed diagnostic", "namespace_rows": rows, "pid1_mountinfo": table.decode(), "host_namespace": os.readlink("/proc/self/ns/mnt"), "pid1_namespace": os.readlink("/proc/1/ns/mnt")}
    output.write_text(json.dumps(result, indent=2) + "\n")
    print("NAMESPACE_ROWS=" + json.dumps(rows), flush=True)
finally:
    if mounted:
        subprocess.run(["umount", str(target)], check=True, timeout=5)
    target.unlink(missing_ok=True)
    child.terminate()
    child.wait(timeout=5)
