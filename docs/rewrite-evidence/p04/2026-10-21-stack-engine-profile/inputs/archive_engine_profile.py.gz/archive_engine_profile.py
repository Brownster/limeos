# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Archive the profile correction, byte-identical binary bridge and real Engine run."""
import datetime
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
state = Path(__file__).resolve().parent
out = root / "docs/rewrite-evidence/p04/2026-10-21-stack-engine-profile"
files = {}

def archive(path, name):
    data = path.read_bytes()
    packed = gzip.compress(data, mtime=0)
    target = out / (name + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(packed)
    files[str(target.relative_to(out))] = {"source": str(path.relative_to(root)), "sha256": hashlib.sha256(packed).hexdigest(), "original_sha256": hashlib.sha256(data).hexdigest(), "original_bytes": len(data)}

inputs = json.loads((state / "candidate-4/inputs.json").read_text())
attempts = {}
expected = {
    "stack-engine-profile-red-1": (1, False),
    "stack-engine-profile-reference-1": (0, False),
    "stack-engine-profile-packages-3": (0, False),
    "stack-engine-profile-installed-1": (1, False),
    "stack-engine-profile-installed-2-mounts": (143, True),
    "stack-engine-nsfs-probe-1": (0, False),
    "stack-engine-nsfs-red-1": (101, False),
    "stack-engine-nsfs-container-1": (0, False),
    "stack-engine-nsfs-clippy-1": (0, False),
    "stack-engine-nsfs-reference-1": (0, False),
    "stack-engine-profile-packages-4": (0, False),
    "stack-engine-profile-installed-3": (1, False),
    "stack-engine-profile-installed-4-images": (0, False),
}
records = {}
for label, result in expected.items():
    directory = root / ".cache/main-consolidation/attempts" / label
    record = json.loads((directory / "record.json").read_text())
    assert record.get("ended") and record["inputs_unchanged"]
    assert (record["exit_code"], record["guard_triggered"]) == result
    records[label] = record
out.mkdir(exist_ok=False)
for label, record in records.items():
    directory = root / ".cache/main-consolidation/attempts" / label
    attempts[label] = {key: record[key] for key in ("head", "started", "ended", "exit_code", "guard_triggered", "minimum_available_bytes", "inputs_unchanged")}
    for name in ("record.json", "output.log", "failure-extracted.json"):
        if (directory / name).exists():
            archive(directory / name, "attempts/" + label + "/" + name)
for candidate in ("candidate-3", "candidate-4"):
    for name in ("inputs.json", "prepare_packages.py"):
        archive(state / candidate / name, candidate + "/" + name)
for path in sorted((state / "candidate-4/repository").rglob("*")):
    if path.is_file() and not path.name.endswith(".deb"):
        archive(path, "repository/" + str(path.relative_to(state / "candidate-4/repository")))
for build in ("build-2", "build-4"):
    for path in sorted((state / build).iterdir()):
        if path.is_file():
            archive(path, build + "/" + path.name)
for group in ("engine-3", "engine-4", "engine-5", "engine-6", "nsfs-probe-1"):
    for path in sorted((state / group).iterdir()):
        if path.is_file():
            archive(path, "guest/" + group + "/" + path.name)
for name in ("run_768.py", "run_512.py", "run_384.py", "current_authority_schema.py", "archive_engine_profile.py"):
    archive(state / name, "inputs/" + name)
patch_path = state / "engine-profile-source.patch"
patch_path.write_bytes(subprocess.check_output(["git", "log", "--format=fuller", "--binary", "-p", "9249c73.." + inputs["source"]], cwd=root))
archive(patch_path, "source.patch")
manifest = {"source": inputs["source"], "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "scope": "Installed catalog/Engine reads under the compatible profile; full B2 and cutover gates remain open", "candidate": inputs, "previous_candidate": json.loads((state / "candidate-3/inputs.json").read_text()), "attempts": attempts, "files": files}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
for name, entry in files.items():
    data = (out / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == entry["sha256"]
    assert hashlib.sha256(gzip.decompress(data)).hexdigest() == entry["original_sha256"]
print(json.dumps({"packet": str(out), "source": inputs["source"], "records": len(files), "attempts": attempts}))
