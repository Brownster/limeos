# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Verify final source, failed attempts, installed images and capability witnesses."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
packet = root / "docs/rewrite-evidence/p04/2026-10-21-stack-engine-profile"
manifest = json.loads((packet / "manifest.json").read_text())
for name, entry in manifest["files"].items():
    packed = (packet / name).read_bytes()
    data = gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest() == entry["sha256"]
    assert hashlib.sha256(data).hexdigest() == entry["original_sha256"]
    assert len(data) == entry["original_bytes"]

def record(name):
    return json.loads(gzip.decompress((packet / name).read_bytes()))

build = record("build-4/record.json.gz")
assert build["source"] == manifest["source"] and build["before"] == build["after"]
assert build["exit_code"] == 0 and build["stop_reason"] is None and not build["oom_killed"] and build["container_removed"]
for name, expected in build["before"].items():
    if not name.startswith("docs/"):
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
for label in ("stack-engine-nsfs-container-1", "stack-engine-nsfs-clippy-1", "stack-engine-nsfs-reference-1"):
    check = record("attempts/" + label + "/record.json.gz")
    assert check["before"] == check["after"] == build["before"]
    assert check["exit_code"] == 0 and not check["guard_triggered"]
log = gzip.decompress((packet / "attempts/stack-engine-nsfs-container-1/output.log.gz").read_bytes()).decode()
assert "test result: ok. 357 passed; 0 failed" in log and "test result: ok. 17 passed; 0 failed" in log
old = record("build-2/record.json.gz")
previous = manifest["previous_candidate"]
assert previous["binary_source"] == old["source"]
assert previous["binary_build_record_sha256"] == hashlib.sha256(gzip.decompress((packet / "build-2/record.json.gz").read_bytes())).hexdigest()
assert all(old["before"][name] == expected for name, expected in previous["application_inputs_identical"].items())
bridge = record("attempts/stack-engine-profile-packages-3/record.json.gz")
assert all(bridge["before"][name] == expected for name, expected in previous["application_inputs_identical"].items())
candidate = manifest["candidate"]
assert candidate["source"] == build["source"]
installed = record("guest/engine-6/result.json.gz")
assert installed["status"] == "passed" and len(installed["passed"]) == 9
assert installed["version"] == candidate["version"]
assert installed["engine"]["peer"]["pid"] > 1 and installed["engine"]["peer"]["uid"] == 0
assert installed["engine"]["id"] and installed["engine"]["dockerd_sha256"]
assert installed["binaries"] == {name: entry["sha256"] for name, entry in candidate["binaries"].items()}
for name, expected in candidate["packages"].items():
    assert hashlib.sha256((root / ".cache/stack-installed-qualification/candidate-4/packages" / name).read_bytes()).hexdigest() == expected
mixed = installed["states"]["mixed"]
assert mixed["catalog"]["state"] == mixed["engine"]["state"] == "fresh"
assert mixed["stacks"][0]["counts"] == {"ordinary": 2, "running": 1, "one_offs": 1, "one_off_running": 1}
assert installed["states"]["catalog_refused"]["catalog"]["state"] == "stale"
assert installed["states"]["engine_refused"]["engine"]["state"] == "stale"
for phase in ("before_reader_restart", "final"):
    resources = installed["resources"][phase]
    assert resources["memory.max"] == "67108864" and resources["pids.max"] == "16"
    events = dict(line.split() for line in resources["memory.events"].splitlines())
    assert all(events[key] == "0" for key in ("max", "oom", "oom_kill")) and resources["pids.events"] == "max 0"
samples = installed["resources"]["observed_maxima"]
assert not samples["confinement_violations"]
assert {witness["role"] for witness in samples["runtime_witnesses"].values()} == {"manager", "guardian", "worker"}
for witness in samples["runtime_witnesses"].values():
    expected = candidate["binaries"]["limeos-executor" if witness["role"] == "manager" else "limeos-stack-read-worker"]["sha256"]
    assert witness["image_sha256"] == expected
    fields = dict(line.split(":", 1) for line in witness["status"].splitlines() if ":" in line)
    assert fields["CapEff"].strip() == fields["CapBnd"].strip() == "0000000000000000" and fields["NoNewPrivs"].strip() == "1"
for group in ("engine-3", "engine-4", "engine-5", "engine-6", "nsfs-probe-1"):
    for path, expected in record("guest/" + group + "/inputs-before.json.gz").items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
paths = sorted(path for path in packet.rglob("*") if path.is_file() and path.name != "artifacts.sha256")
(packet / "artifacts.sha256").write_text("".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + str(path.relative_to(packet)) + "\n" for path in paths))
print(json.dumps({"source": manifest["source"], "compressed_records_verified": len(manifest["files"]), "packet_files_hashed": len(paths), "native_and_build_inputs_match": True, "installed_images_match": True, "installed_checks": len(installed["passed"]), "runtime_capability_witnesses": len(samples["runtime_witnesses"])}))
