# Disposable fixture wrapper; production packages are unchanged.
import p04_approved_guest as approved
import p04_mounts_guest as mounts
from namespace_census import snapshot

original = mounts._after_refusal_facts
def diagnostics(service):
    facts = original(service)
    facts["namespace_census"] = snapshot()
    return facts

mounts._after_refusal_facts = diagnostics
approved.main(package_version='0.4.4+namespace.2')
