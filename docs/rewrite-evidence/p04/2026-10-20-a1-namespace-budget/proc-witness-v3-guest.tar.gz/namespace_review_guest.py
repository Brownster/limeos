# No thread or monitor runs during the actual production RPC.
import p04_approved_guest as approved
import p04_mounts_guest as mounts
from namespace_census import snapshot

witness = {}
original_pre = mounts.pre_effect_refusals
original_after = mounts._after_refusal_facts

def pre_effect(*args):
    witness["before"] = snapshot()
    try:
        return original_pre(*args)
    finally:
        witness["after"] = snapshot()

def diagnostics(service):
    facts = original_after(service)
    facts["namespace_census"] = snapshot()
    facts["pre_effect_task_witness"] = witness
    return facts

mounts.pre_effect_refusals = pre_effect
mounts._after_refusal_facts = diagnostics
try:
    approved.main(package_version="0.4.4+namespace.2")
except Exception:
    import subprocess
    result = subprocess.run(["dmesg", "--level=emerg,alert,crit,err"], text=True, capture_output=True, timeout=5)
    print("POST_FAILURE_KERNEL_DIAGNOSTIC " + result.stdout[-16000:], flush=True)
    raise
