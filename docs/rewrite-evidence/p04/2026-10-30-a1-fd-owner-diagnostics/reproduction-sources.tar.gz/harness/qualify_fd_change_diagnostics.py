# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Qualify failure-only FD membership diagnostics with the bounded fixture runner."""
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/main-consolidation'
checks = [
    ('a1-fd-change-format-1', ['cargo', 'fmt', '--all', '--', '--check']),
    ('a1-fd-change-focused-1', ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-executor-storage', '--lib', 'mount_admission::host_consumers::tests']),
    ('a1-fd-change-compile-1', ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-executor-storage', '--lib', '--no-run', '--message-format=json']),
    ('a1-fd-change-runtime-1', [sys.executable, str(STATE / 'a1_fd_change_runtime.py')]),
    ('a1-fd-change-doctests-1', ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-executor-storage', '--doc']),
    ('a1-fd-change-clippy-1', ['cargo', 'clippy', '--offline', '--locked', '-p', 'limeos-executor-storage', '-p', 'limeos-executor', '--all-targets', '--', '-D', 'warnings']),
    ('a1-fd-change-repository-1', ['python3', 'scripts/check_repository.py']),
]
available = next(int(v.split()[1])*1024 for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:'))
assert available >= 4 * 1024**3
for label, command in checks:
    with (STATE / (label + '-console.log')).open('xb') as stream:
        status = subprocess.run([sys.executable, str(STATE / 'guard.py'), label, *command], cwd=ROOT,
                                stdout=stream, stderr=subprocess.STDOUT).returncode
    print(label, status, flush=True)
    if status:
        raise SystemExit(status)
