#!/usr/bin/env -S uv run --offline
# /// script
# dependencies = []
# ///
"""Package the completed local Servarr settings checks without rerunning them."""

import gzip
import hashlib
import json
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/media-settings"
output = root / "docs/rewrite-evidence/p04/2026-10-16-media-settings"
output.mkdir(parents=True, exist_ok=True)
source = (cache / "source.txt").read_text().strip()
assert source == "2e283f76a80ba47e3cfab4c495c0d629712d97ca"
assert not (cache / "source-status.log").read_text().strip()
test = (cache / "test-reviewed.log").read_text()
for count in [127, 20]:
    assert f"{count} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out" in test
assert "Finished" in (cache / "clippy.log").read_text()
assert not (cache / "rustfmt.log").read_text()
assert "All checks passed!" in (cache / "ruff.log").read_text()
assert (cache / "harness-check.log").read_text().count(": OK") == 6


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


paths = sorted(set((cache / "input-paths.txt").read_text().splitlines()))
(output / "inputs.sha256").write_text(
    "".join(f"{digest(root / name)}  {name}\n" for name in paths)
)
reference = Path("/home/marc/Documents/github/pi-health")
reference_paths = [
    "arr_client.py",
    "media_seed_service.py",
    "tests/test_media_seed_service.py",
    "catalog/sonarr.yaml",
    "catalog/radarr.yaml",
    "catalog/lidarr.yaml",
]
(output / "frozen-inputs.sha256").write_text(
    "".join(
        f"{digest(reference / name)}  {reference / name}\n" for name in reference_paths
    )
)
files = {
    "test.log": "test-reviewed.log",
    "clippy.log": "clippy.log",
    "rustfmt.log": "rustfmt.log",
    "prepare.log": "prepare.log",
    "cargo-metadata.json": "cargo-metadata.json",
    "rustc-version.log": "rustc-version.log",
    "cargo-version.log": "cargo-version.log",
    "test-initial.log": "test-initial.log",
    "source-status.log": "source-status.log",
    "package-evidence.py": "package-evidence.py",
    "ruff.log": "ruff.log",
    "ruff-format.log": "ruff-format.log",
    "harness-before.sha256": "harness-before.sha256",
    "harness-check.log": "harness-check.log",
}
for name, original in files.items():
    (output / f"{name}.gz").write_bytes(
        gzip.compress((cache / original).read_bytes(), mtime=0)
    )
harness = output / "harness"
harness.mkdir(exist_ok=True)
for name in [
    "Cargo.toml",
    "Cargo.lock",
    "domain/Cargo.toml",
    "domain/lib.rs",
    "adapter/Cargo.toml",
    "adapter/lib.rs",
]:
    destination = harness / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((root / ".cache/media-settings-leaf" / name).read_bytes())
metadata = {
    "source": source,
    "base": "1607167",
    "product_committed_after_checks_without_intervening_changes": True,
    "cases": {
        "domain": {
            "media_settings": 18,
            "local_config": 24,
            "catalog_and_namespace": 37,
            "media_library": 21,
            "activity": 15,
            "discovery": 12,
        },
        "decoders": {"media_settings": 10, "media_library": 10},
    },
    "total": 147,
    "bounds": {
        "per_response_bytes": 32768,
        "profile_count": 16,
        "profile_name_utf8_bytes": 128,
        "path_utf8_bytes": 512,
        "selected_input_text_bytes": 32768,
        "streamed_report_bytes": 65536,
        "inclusive_max_age_seconds": 90,
    },
    "input_count": len(paths),
    "frozen_source": "80593b29443ea9b81eb60ed4e5c3c3ac7a236204",
    "frozen_input_count": len(reference_paths),
    "commands": [
        "uv run --offline --no-project tests/fixtures/deployment/media-settings/check-leaves.py",
        "cargo test --offline --locked --manifest-path .cache/media-settings-leaf/Cargo.toml",
        "cargo clippy --offline --locked --manifest-path .cache/media-settings-leaf/Cargo.toml --all-targets -- -D warnings",
        "rustfmt --edition 2024 --check crates/domain/src/deployment/mod.rs crates/domain/src/deployment/catalog/tests/namespaces.rs crates/domain/src/deployment/media_settings.rs crates/domain/src/deployment/media_settings/tests.rs crates/executor-container/src/deployment/mod.rs crates/executor-container/src/deployment/media.rs crates/executor-container/src/deployment/media_settings.rs crates/executor-container/src/deployment/media_settings/tests.rs",
        "uv run --offline --no-project --with ruff==0.17.0 ruff check tests/fixtures/deployment/media-settings/check-leaves.py",
    ],
    "environment": {
        "CARGO_BUILD_JOBS": "1",
        "CARGO_INCREMENTAL": "0",
        "RUST_TEST_THREADS": "2",
        "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
    },
    "limits": "Local supplied-data planners/decoders only; no acquisition, protected writer, shared registration, installed API/UI, application compatibility, ARM64 or host acceptance",
}
(output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
artifacts = sorted(
    path
    for path in output.rglob("*")
    if path.is_file() and path.name != "artifacts.sha256"
)
(output / "artifacts.sha256").write_text(
    "".join(f"{digest(path)}  {path.relative_to(output)}\n" for path in artifacts)
)
print(
    json.dumps(
        {
            "source": source,
            "inputs": len(paths),
            "artifacts": len(artifacts),
            "tests": 147,
        }
    )
)
