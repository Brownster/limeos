# /// script
# dependencies = []
# ///
import gzip
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/network-ui"
packet = root / "docs/rewrite-evidence/p04/2026-10-17-network-read-ui"

def command(*args):
    return subprocess.check_output(args, cwd=root, text=True)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source = command("git", "rev-parse", "HEAD").strip()
base = command("git", "rev-parse", "31b3b68").strip()
subprocess.run(["git", "diff", "--exit-code", "HEAD", "--", "crates", "bins", "frontend", "tests/fixtures", "Cargo.toml", "Cargo.lock"], cwd=root, check=True)
protected = ["Cargo.toml", "Cargo.lock", "crates/domain/src/lib.rs", "crates/api/src/lib.rs", "crates/persistence/src/lib.rs", "crates/executor-protocol/src/lib.rs", "crates/contracts/src/lib.rs", "bins/core/src/main.rs", "bins/executor/src/main.rs", "frontend/src/Dashboard.tsx", "frontend/src/api.ts", "frontend/package.json", "frontend/package-lock.json", "tests/fixtures/stream-b/check-leaves.py"]
for path in protected:
    assert command("git", "show", f"{base}:{path}").encode() == (root / path).read_bytes(), path
old_lock = root / "docs/rewrite-evidence/p04/2026-10-16-network-egress/harness/Cargo.lock"
assert old_lock.read_bytes() == (root / ".cache/stream-b-leaf/Cargo.lock").read_bytes()
paths = command("git", "ls-files", "-z", "crates", "bins/core/src/automation", "bins/executor/src/updates", "tests/fixtures", "frontend/src", "frontend/tests", "frontend/package.json", "frontend/package-lock.json", "frontend/tsconfig.json", "contracts/generated", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml", ".cargo").split("\0")
paths = sorted(path for path in paths if path and (root / path).is_file())
(packet / "inputs.sha256").write_text("".join(f"{digest(root / path)}  {path}\n" for path in paths))
for path in sorted((root / ".cache/stream-b-leaf").rglob("*")):
    if path.is_file():
        dest = packet / "harness" / path.relative_to(root / ".cache/stream-b-leaf")
        dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(path, dest)
for path in sorted((cache / "preview").rglob("*")):
    if path.is_file():
        dest = packet / "preview" / path.relative_to(cache / "preview")
        dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(path, dest)
shutil.copyfile(cache / "vite.config.mjs", packet / "preview/vite.config.mjs")
(cache / "source-status.log").write_text(command("git", "status", "--short", "--branch"))
(cache / "source-history.log").write_text(command("git", "log", "-3", "--format=%H %s"))
(cache / "cargo-metadata.json").write_text(command("cargo", "metadata", "--offline", "--locked", "--format-version", "1", "--manifest-path", ".cache/stream-b-leaf/Cargo.toml"))
tests = (cache / "rust-tests.log").read_text()
assert sum(map(int, re.findall(r"test result: ok\. (\d+) passed; 0 failed", tests))) == 461
assert "warning:" not in tests and "error:" not in tests
assert "Finished" in (cache / "clippy.log").read_text()
assert "built in" in (cache / "preview-build.log").read_text() and "Build failed" not in (cache / "preview-build.log").read_text()
frontend = json.loads((cache / "frontend-results.json").read_text())
assert frontend["tests"] == 123 and len(frontend["files"]) == 8
assert next(row["tests"] for row in frontend["files"] if row["file"].endswith("network-groups.test.mjs")) == 34
installed = {}
expected = json.loads((root / "frontend/package.json").read_text())
for name, version in {**expected["dependencies"], **expected["devDependencies"]}.items():
    path = root.parents[1] / "frontend/node_modules" / name / "package.json"
    actual = json.loads(path.read_text())["version"]; assert actual == version, (name, actual, version)
    installed[name] = {"version": actual, "package_json_sha256": digest(path)}
metadata = {
    "source": source, "base": base, "main_baseline": "7df3f7530865c31b7faefd1f7b12a25aa7655860",
    "source_committed_after_checks_without_intervening_product_changes": True,
    "cases": {"domain": 301, "adapter_host_policy": 127, "api": 27, "runner": 6, "rust_total": 461, "new_network_api": 8, "frontend_total": 123, "new_network_frontend": 34},
    "frontend": frontend, "input_count": len(paths), "input_scope": "Source/fixture superset, not every included crate unit suite ran",
    "harness_lock_origin": str(old_lock.relative_to(root)), "harness_lock_sha256": digest(old_lock),
    "protected_paths_unchanged_from_base": protected,
    "bounds": {"streamed_response_bytes": 65536, "serialized_api_response_bytes": 65536, "observed_containers": 16, "read_deadline_ms": 12000, "inclusive_original_sample_age_seconds": 90},
    "installed_frontend_dependencies": installed,
    "commands": [
        "uv run --offline --no-project tests/fixtures/stream-b/check-leaves.py",
        "cp docs/rewrite-evidence/p04/2026-10-16-network-egress/harness/Cargo.lock .cache/stream-b-leaf/Cargo.lock",
        "cargo test --offline --locked --manifest-path .cache/stream-b-leaf/Cargo.toml",
        "cargo clippy --offline --locked --manifest-path .cache/stream-b-leaf/Cargo.toml --all-targets -- -D warnings",
        "rustfmt --edition 2024 --check --config skip_children=true crates/api/src/deployment.rs crates/api/src/deployment/network_tests.rs",
        "npm run check (cwd frontend, pinned node_modules symlink removed afterward)",
        "uv run --offline --no-project .cache/network-ui/check-frontend.py",
        "node /home/marc/Documents/github/lime-os/frontend/node_modules/vite/bin/vite.js build --config .cache/network-ui/vite.config.mjs",
        "uv run --offline --no-project .cache/network-ui/verify-harness.py",
    ],
    "toolchain": {"rustc": command("rustc", "-Vv"), "cargo": command("cargo", "-Vv"), "node": command("node", "--version"), "uv": command("uv", "--version")},
    "environment": {"CARGO_BUILD_JOBS": "1", "CARGO_INCREMENTAL": "0", "RUST_TEST_THREADS": "2", "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target", "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp", "CCACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/ccache", "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv", "npm_config_cache": "/home/marc/Documents/github/lime-os/.cache/npm"},
    "visual_inspection": json.loads((cache / "browser-availability.json").read_text()),
    "preview_scope": "Standalone synthetic view bundle only, not the mounted authenticated panel, production dashboard or a browser render",
    "limits": "Local cached-handler/wire/controller/markup checks; protected cache/backend, production routes/middleware/contracts/shell, installed/browser lifetime, budgets/recovery/ARM64/performance/soak/Pi and defect/P04/cutover acceptance remain open",
}
(packet / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
for name in ("harness-regeneration.json", "frontend-results.json", "browser-availability.json"):
    shutil.copyfile(cache / name, packet / name)
for path in sorted(cache.iterdir()):
    if path.suffix in {".log", ".py", ".ts"} or path.name in {"cargo-metadata.json", "network-tests-assertion-failed.mjs"}:
        (packet / (path.name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
artifacts = sorted(path for path in packet.rglob("*") if path.is_file() and path.name != "artifacts.sha256")
(packet / "artifacts.sha256").write_text("".join(f"{digest(path)}  {path.relative_to(packet)}\n" for path in artifacts))
print(json.dumps({"source": source, "inputs": len(paths), "artifacts": len(artifacts)}))
