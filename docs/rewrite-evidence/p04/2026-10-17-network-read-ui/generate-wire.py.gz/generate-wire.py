# /// script
# dependencies = []
# ///
import json
from pathlib import Path

project = {"name": "media", "working_directory": "/opt/stacks/Media", "config_files": ["/opt/stacks/Media/compose.yaml"]}
def container(letter, name, service, running, health, one_off=False):
    return {"id": letter * 64, "name": name, "running": running, "health": health,
            "compose": {"project": project, "service": service, "one_off": one_off}}
provider = container("a", "vpn", "vpn", True, "not_configured")
wire = {
    "version": 1, "generated_at": 105, "source": "fresh", "sampled_at": 100, "max_age_seconds": 90,
    "observed_containers": 4, "independent_containers": 1, "unknown_mode_containers": 0,
    "groups": [{"provider": provider, "state": "orphan_hints", "member_ids": ["b" * 64, "d" * 64], "hinted_orphan_ids": ["c" * 64]}],
    "members": [
        {"container": container("b", "sonarr", "sonarr", True, "healthy"), "reference_kind": "container", "target": "a" * 64, "state": "resolved", "provider_id": "a" * 64, "hinted_provider_id": None, "dependency_hint": None},
        {"container": container("c", "transmission", "transmission", False, "unknown"), "reference_kind": "container", "target": "e" * 64, "state": "missing_provider", "provider_id": None, "hinted_provider_id": "a" * 64, "dependency_hint": "vpn"},
        {"container": container("d", "sonarr-oneoff", "sonarr", False, "not_configured", True), "reference_kind": "container", "target": "a" * 64, "state": "resolved", "provider_id": "a" * 64, "hinted_provider_id": None, "dependency_hint": None},
    ],
}
Path("tests/fixtures/deployment/networks/wire.json").write_text(json.dumps(wire, indent=2) + "\n")
