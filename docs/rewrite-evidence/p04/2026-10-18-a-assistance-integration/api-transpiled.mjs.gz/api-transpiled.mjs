import assert from "node:assert/strict";
import { test } from "node:test";
import { api, ApiError } from "data:text/javascript;base64,ZXhwb3J0IGNsYXNzIEFwaUVycm9yIGV4dGVuZHMgRXJyb3IgewogICAgZGV0YWlsOwogICAgY29uc3RydWN0b3IoZGV0YWlsKSB7CiAgICAgICAgc3VwZXIoZGV0YWlsLm1lc3NhZ2UpOwogICAgICAgIHRoaXMuZGV0YWlsID0gZGV0YWlsOwogICAgfQp9CmZ1bmN0aW9uIGlzRXJyb3JFbnZlbG9wZSh2YWx1ZSkgewogICAgaWYgKCF2YWx1ZSB8fCB0eXBlb2YgdmFsdWUgIT09ICJvYmplY3QiKQogICAgICAgIHJldHVybiBmYWxzZTsKICAgIGNvbnN0IGVycm9yID0gdmFsdWU7CiAgICByZXR1cm4gKHR5cGVvZiBlcnJvci5jb2RlID09PSAic3RyaW5nIiAmJgogICAgICAgIGVycm9yLmNvZGUubGVuZ3RoIDw9IDY0ICYmCiAgICAgICAgdHlwZW9mIGVycm9yLm1lc3NhZ2UgPT09ICJzdHJpbmciICYmCiAgICAgICAgZXJyb3IubWVzc2FnZS5sZW5ndGggPiAwICYmCiAgICAgICAgZXJyb3IubWVzc2FnZS5sZW5ndGggPD0gNTEyICYmCiAgICAgICAgdHlwZW9mIGVycm9yLnJldHJ5ID09PSAiYm9vbGVhbiIgJiYKICAgICAgICB0eXBlb2YgZXJyb3IuYXVkaXRfaWQgPT09ICJzdHJpbmciICYmCiAgICAgICAgZXJyb3IuYXVkaXRfaWQubGVuZ3RoIDw9IDEyOCk7Cn0KZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlcXVlc3QocGF0aCwgaW5pdCkgewogICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgL2FwaS92MSR7cGF0aH1gLCB7CiAgICAgICAgLi4uaW5pdCwKICAgICAgICBjcmVkZW50aWFsczogInNhbWUtb3JpZ2luIiwKICAgICAgICBzaWduYWw6IEFib3J0U2lnbmFsLnRpbWVvdXQoMTJfMDAwKSwKICAgIH0pOwogICAgaWYgKCFyZXNwb25zZS5vaykgewogICAgICAgIGNvbnN0IGVycm9yID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpOwogICAgICAgIGlmIChpc0Vycm9yRW52ZWxvcGUoZXJyb3IpKQogICAgICAgICAgICB0aHJvdyBuZXcgQXBpRXJyb3IoZXJyb3IpOwogICAgICAgIHRocm93IG5ldyBBcGlFcnJvcih7CiAgICAgICAgICAgIGNvZGU6ICJ1bmF2YWlsYWJsZSIsCiAgICAgICAgICAgIG1lc3NhZ2U6ICJUaGUgaG9zdCBjb3VsZCBub3QgY29tcGxldGUgdGhlIHJlcXVlc3QuIFRyeSBhZ2Fpbi4iLAogICAgICAgICAgICByZXRyeTogdHJ1ZSwKICAgICAgICAgICAgYXVkaXRfaWQ6IGBodHRwLSR7cmVzcG9uc2Uuc3RhdHVzfWAsCiAgICAgICAgfSk7CiAgICB9CiAgICByZXR1cm4gcmVzcG9uc2Uuc3RhdHVzID09PSAyMDQKICAgICAgICA/IHVuZGVmaW5lZAogICAgICAgIDogKGF3YWl0IHJlc3BvbnNlLmpzb24oKSk7Cn0KZXhwb3J0IGNvbnN0IGFwaSA9IHsKICAgIHBsYW5Db250YWluZXI6IChyZXNvdXJjZSwgb3BlcmF0aW9uLCBjc3JmKSA9PiByZXF1ZXN0KCIvY29udGFpbmVyL3BsYW5zIiwgewogICAgICAgIG1ldGhvZDogIlBPU1QiLAogICAgICAgIGhlYWRlcnM6IHsgIkNvbnRlbnQtVHlwZSI6ICJhcHBsaWNhdGlvbi9qc29uIiwgIlgtQ1NSRi1Ub2tlbiI6IGNzcmYgfSwKICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHJlc291cmNlLCBvcGVyYXRpb24gfSksCiAgICB9KSwKICAgIHBsYW5SZXN0YXJ0OiAocmVzb3VyY2UsIGNzcmYpID0+IHJlcXVlc3QoIi9jb250YWluZXIvcmVzdGFydC9wbGFucyIsIHsKICAgICAgICBtZXRob2Q6ICJQT1NUIiwKICAgICAgICBoZWFkZXJzOiB7ICJDb250ZW50LVR5cGUiOiAiYXBwbGljYXRpb24vanNvbiIsICJYLUNTUkYtVG9rZW4iOiBjc3JmIH0sCiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyByZXNvdXJjZSB9KSwKICAgIH0pLAogICAgYXBwcm92ZVJlc3RhcnQ6IChwcm9wb3NhbCwgY3NyZikgPT4gcmVxdWVzdChgL2NvbnRhaW5lci9wbGFucy8ke3Byb3Bvc2FsLnBsYW4uaWR9L2FwcHJvdmFsYCwgewogICAgICAgIG1ldGhvZDogIlBPU1QiLAogICAgICAgIGhlYWRlcnM6IHsgIkNvbnRlbnQtVHlwZSI6ICJhcHBsaWNhdGlvbi9qc29uIiwgIlgtQ1NSRi1Ub2tlbiI6IGNzcmYgfSwKICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGRpZ2VzdDogcHJvcG9zYWwuZGlnZXN0IH0pLAogICAgfSksCiAgICBxdWV1ZVJlc3RhcnQ6IChwcm9wb3NhbCwgYXBwcm92YWwsIGtleSwgY3NyZikgPT4gcmVxdWVzdCgiL2NvbnRhaW5lci9qb2JzIiwgewogICAgICAgIG1ldGhvZDogIlBPU1QiLAogICAgICAgIGhlYWRlcnM6IHsgIkNvbnRlbnQtVHlwZSI6ICJhcHBsaWNhdGlvbi9qc29uIiwgIlgtQ1NSRi1Ub2tlbiI6IGNzcmYgfSwKICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHByb3Bvc2FsLCBhcHByb3ZhbCwgaWRlbXBvdGVuY3lfa2V5OiBrZXkgfSksCiAgICB9KSwKICAgIHJlc3RhcnRKb2JzOiAoKSA9PiByZXF1ZXN0KCIvY29udGFpbmVyL2pvYnMiKSwKICAgIHJlc3RhcnRQcm9ncmVzczogKGlkLCBhZnRlciA9IDApID0+IHJlcXVlc3QoYC9jb250YWluZXIvam9icy8ke2lkfT9hZnRlcj0ke2FmdGVyfWApLAogICAgY2FuY2VsUmVzdGFydDogKGlkLCBjc3JmLCBwbGFuID0gZmFsc2UpID0+IHJlcXVlc3QoYC9jb250YWluZXIvJHtwbGFuID8gInBsYW5zIiA6ICJqb2JzIn0vJHtpZH0vY2FuY2VsYCwgewogICAgICAgIG1ldGhvZDogIlBPU1QiLAogICAgICAgIGhlYWRlcnM6IHsgIlgtQ1NSRi1Ub2tlbiI6IGNzcmYgfSwKICAgIH0pLAogICAgY29udGFpbmVyTG9nczogKHJlc291cmNlLCB0YWlsID0gMTAwKSA9PiByZXF1ZXN0KGAvY29udGFpbmVycy8ke2VuY29kZVVSSUNvbXBvbmVudChyZXNvdXJjZS5zbGljZSgxMCkpfS9sb2dzP3RhaWw9JHt0YWlsfWApLAogICAgb3ZlcnZpZXc6ICgpID0+IHJlcXVlc3QoIi9vdmVydmlldyIpLAogICAgcmVzb3VyY2VzOiAoa2luZCwgb2Zmc2V0ID0gMCwgcmV2aXNpb24pID0+IHJlcXVlc3QoYC9yZXNvdXJjZXM/bGltaXQ9MjAmb2Zmc2V0PSR7b2Zmc2V0fSR7a2luZCA/IGAma2luZD0ke2tpbmR9YCA6ICIifSR7cmV2aXNpb24gPT09IHVuZGVmaW5lZCA/ICIiIDogYCZyZXZpc2lvbj0ke3JldmlzaW9ufWB9YCksCiAgICBoaXN0b3J5OiAocmFuZ2UpID0+IHJlcXVlc3QoYC9zeXN0ZW0vaGlzdG9yeT9yYW5nZT0ke3JhbmdlfWApLAogICAgc2Vzc2lvbjogKCkgPT4gcmVxdWVzdCgiL2F1dGgvc2Vzc2lvbiIpLAogICAgbG9naW46IChpbnB1dCkgPT4gcmVxdWVzdCgiL2F1dGgvbG9naW4iLCB7CiAgICAgICAgbWV0aG9kOiAiUE9TVCIsCiAgICAgICAgaGVhZGVyczogeyAiQ29udGVudC1UeXBlIjogImFwcGxpY2F0aW9uL2pzb24iIH0sCiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoaW5wdXQpLAogICAgfSksCiAgICBsb2dvdXQ6IChjc3JmKSA9PiByZXF1ZXN0KCIvYXV0aC9sb2dvdXQiLCB7CiAgICAgICAgbWV0aG9kOiAiUE9TVCIsCiAgICAgICAgaGVhZGVyczogeyAiWC1DU1JGLVRva2VuIjogY3NyZiB9LAogICAgfSksCn07Cg==";

test("login sends credentials in the body with same-origin cookies and a deadline", async (t) => {
  const fixture = {
    username: "fixture-user",
    password: "synthetic-test-password",
  };
  t.mock.method(globalThis, "fetch", async (url, options) => {
    assert.equal(url, "/api/v1/auth/login");
    assert.equal(options.method, "POST");
    assert.equal(options.credentials, "same-origin");
    assert.equal(options.headers["Content-Type"], "application/json");
    assert.ok(options.signal instanceof AbortSignal);
    assert.deepEqual(JSON.parse(options.body), fixture);
    assert.ok(!url.includes(fixture.password));
    return Response.json({ csrf_token: "fixture-csrf" });
  });
  assert.equal((await api.login(fixture)).csrf_token, "fixture-csrf");
});

test("logout supplies CSRF over POST, and session reads have no mutation body", async (t) => {
  const calls = [];
  t.mock.method(globalThis, "fetch", async (url, options) => {
    calls.push([url, options]);
    return url.endsWith("logout")
      ? new Response(null, { status: 204 })
      : Response.json({});
  });
  assert.equal(await api.logout("fixture-csrf"), undefined);
  await api.session();
  assert.equal(calls[0][1].method, "POST");
  assert.equal(calls[0][1].headers["X-CSRF-Token"], "fixture-csrf");
  assert.equal(calls[1][1].method, undefined);
  assert.equal(calls[1][1].body, undefined);
});

test("safe API errors retain their details; malformed proxy responses get a fixed message", async (t) => {
  const detail = {
    code: "forbidden",
    message: "The request is outside the permitted scope.",
    retry: false,
    audit_id: "fixture-id",
  };
  t.mock.method(globalThis, "fetch", async () =>
    Response.json(detail, { status: 403 }),
  );
  await assert.rejects(api.session(), (error) => {
    assert.ok(error instanceof ApiError);
    assert.deepEqual(error.detail, detail);
    assert.equal(error.message, detail.message);
    return true;
  });
  for (const body of [
    "<html>private proxy diagnostic</html>",
    '{"message":"private proxy diagnostic"}',
  ]) {
    globalThis.fetch.mock.mockImplementation(
      async () => new Response(body, { status: 503 }),
    );
    await assert.rejects(
      api.session(),
      (error) =>
        error instanceof ApiError &&
        error.detail.code === "unavailable" &&
        !error.message.includes("private"),
    );
  }
});

test("restart approval and queue use POST and CSRF, retaining the same retry key", async (t) => {
  const calls = [];
  const proposal = { plan: { id: "a".repeat(64) }, digest: "b".repeat(64) };
  t.mock.method(globalThis, "fetch", async (url, options) => {
    calls.push([url, options]);
    return Response.json({});
  });
  await api.planRestart("container:fixture", "csrf");
  await api.approveRestart(proposal, "csrf");
  await api.queueRestart(proposal, "private-approval", "same-key", "csrf");
  await api.queueRestart(proposal, "private-approval", "same-key", "csrf");
  for (const [url, options] of calls) {
    assert.equal(options.method, "POST");
    assert.equal(options.headers["X-CSRF-Token"], "csrf");
    assert.ok(!url.includes("private-approval"));
  }
  assert.deepEqual(JSON.parse(calls[2][1].body), JSON.parse(calls[3][1].body));
});
