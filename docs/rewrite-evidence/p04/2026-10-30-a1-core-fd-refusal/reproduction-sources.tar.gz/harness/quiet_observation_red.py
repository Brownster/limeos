# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Prove active warmup can prevent its own quiet observation in the regression."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path('/home/marc/Documents/github/lime-os')
sys.path.insert(0, str(ROOT))
from tests.reference import test_p04_fixture_readiness as regression

BASELINE = '8f0c471'
source = subprocess.check_output(
    ['git', 'show', BASELINE + ':tests/privileged_vm/p04_fixture_readiness.py'], cwd=ROOT, text=True
)
node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'wait_docker_startup')
original = ast.get_source_segment(source, node)
assert 'for attempt in range(96)' in original and 'for _ in range(4)' not in original
exec(compile(original, '<original-fixture-warmup>', 'exec'), regression.fixture.__dict__)
suite = unittest.TestSuite([regression.FixtureReadinessTests(
    'test_docker_warmup_stops_sending_requests_during_quiet_observation'
)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
record = {
    'baseline_source': subprocess.check_output(['git', 'rev-parse', BASELINE], cwd=ROOT, text=True).strip(),
    'original_helper_sha256': hashlib.sha256(original.encode()).hexdigest(),
    'regression_source_sha256': hashlib.sha256(Path(regression.__file__).read_bytes()).hexdigest(),
    'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
    'expected_red': result.testsRun == 1 and len(result.errors) == 1 and not result.failures
                    and 'TimeoutError: Fixture Docker startup attempt limit exceeded' in result.errors[0][1],
}
assert record['expected_red'], record
Path(__file__).with_name('quiet-observation-red.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
