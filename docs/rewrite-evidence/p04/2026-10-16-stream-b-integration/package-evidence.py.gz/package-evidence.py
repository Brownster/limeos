# /// script
# dependencies = []
# ///
import gzip
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/stream-b"
packet = root / "docs/rewrite-evidence/p04/2026-10-16-stream-b-integration"

def command(*args):
    return subprocess.check_output(args, cwd=root, text=True)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source = command("git", "rev-parse", "HEAD").strip()
main_base = "02605383730fb56bc47035cafd34dc1e80cdf982"
heads = {
    "media_quickstart_lineage": "7fff043f697fef7a785709f97508743d11994ffc",
    "automation": "485206b0fe5675e438f81e45ca91fbb552349a50",
    "packages_prerequisites": "a3e05e7ac87343addcd955427b90b38cc616883a",
    "images_container_updates": "224f12c31517d133c7528b3663111a39081befe4",
    "networks": "f5fdffa0e53b2e823129183c6480a9480c179a86",
}
for sha in [main_base, *heads.values()]:
    subprocess.run(["git", "merge-base", "--is-ancestor", sha, source], cwd=root, check=True)
subprocess.run(["git", "diff", "--exit-code", "HEAD"], cwd=root, check=True)
(cache / "source-status.log").write_text(command("git", "status", "--short", "--branch"))
(cache / "source-history.log").write_text(command("git", "log", "-8", "--format=%H %s"))
(cache / "cargo-metadata.json").write_text(command(
    "cargo", "metadata", "--offline", "--locked", "--format-version", "1",
    "--manifest-path", ".cache/stream-b-leaf/Cargo.toml",
))
source_paths = command(
    "git", "ls-files", "-z", "crates", "bins/core/src/automation",
    "bins/executor/src/updates", "tests/fixtures", "frontend/src", "frontend/tests",
    "frontend/package.json", "frontend/package-lock.json", "frontend/tsconfig.json",
    "contracts/generated", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml", ".cargo",
).split("\0")
source_paths = sorted(path for path in source_paths if path and (root / path).is_file())
(packet / "inputs.sha256").write_text("".join(f"{digest(root / path)}  {path}\n" for path in source_paths))
for path in sorted((root / ".cache/stream-b-leaf").rglob("*")):
    if path.is_file():
        destination = packet / "harness" / path.relative_to(root / ".cache/stream-b-leaf")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)

frontend_report = json.loads((cache / "frontend-direct-results.json").read_text())
assert frontend_report["tests"] == 89
rust_log = (cache / "test-final.log").read_text()
assert sum(map(int, re.findall(r"test result: ok\. (\d+) passed; 0 failed", rust_log))) == 424
installed = {}
frontend = root.parents[1] / "frontend"
expected = json.loads((root / "frontend/package.json").read_text())
for name, version in {**expected["dependencies"], **expected["devDependencies"]}.items():
    path = frontend / "node_modules" / name / "package.json"
    actual = json.loads(path.read_text())["version"]
    assert actual == version, (name, actual, version)
    installed[name] = {"version": actual, "package_json_sha256": digest(path)}

metadata = {
    "source": source,
    "main_base": main_base,
    "merged_heads": heads,
    "source_committed_after_checks_without_intervening_product_changes": True,
    "input_count": len(source_paths),
    "input_scope": "Source and fixture superset, not a claim that every included crate unit suite ran",
    "rust_cases": {"domain": 281, "adapter_host_policy": 118, "api": 19, "runner": 6, "total": 424},
    "frontend": frontend_report,
    "installed_frontend_dependencies": installed,
    "toolchains": {"rustc": command("rustc", "-Vv"), "cargo": command("cargo", "-Vv"), "node": command("node", "--version"), "uv": command("uv", "--version")},
    "commands": [
        "uv run --offline --no-project tests/fixtures/stream-b/check-leaves.py",
        "cargo test --offline --locked --manifest-path .cache/stream-b-leaf/Cargo.toml",
        "cargo clippy --offline --locked --manifest-path .cache/stream-b-leaf/Cargo.toml --all-targets -- -D warnings",
        "rustfmt --edition 2024 --check --config skip_children=true crates/domain/src/deployment/mod.rs crates/executor-container/src/deployment/mod.rs",
        "uv run --offline --no-project --with ruff==0.17.0 ruff check tests/fixtures/stream-b/check-leaves.py",
        "uv run --offline --no-project .cache/stream-b/verify-harness.py",
        "npm run check (cwd frontend)",
        "node --experimental-strip-types --test --test-concurrency=1 tests/*.mjs (cwd frontend)",
        "uv run --offline --no-project .cache/stream-b/check-frontend-direct.py",
    ],
    "environment": {
        "CARGO_BUILD_JOBS": "1", "CARGO_INCREMENTAL": "0", "RUST_TEST_THREADS": "2",
        "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "CCACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/ccache",
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
        "npm_config_cache": "/home/marc/Documents/github/lime-os/.cache/npm",
    },
    "limits": "Local combined leaf checks; B production registrations, Store durability, installed effects/recovery, ARM64, performance, soak and cutover remain unqualified",
}
(packet / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
for name in ("harness-regeneration.json", "frontend-direct-results.json"):
    shutil.copyfile(cache / name, packet / name)
for path in sorted(cache.iterdir()):
    if path.suffix in {".log", ".py"} or path.name == "cargo-metadata.json":
        (packet / (path.name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
artifacts = sorted(path for path in packet.rglob("*") if path.is_file() and path.name != "artifacts.sha256")
(packet / "artifacts.sha256").write_text("".join(f"{digest(path)}  {path.relative_to(packet)}\n" for path in artifacts))
print(json.dumps({"source": source, "inputs": len(source_paths), "artifacts": len(artifacts)}))
