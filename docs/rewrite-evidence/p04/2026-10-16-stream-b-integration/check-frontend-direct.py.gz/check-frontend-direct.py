# /// script
# dependencies = []
# ///
import json
import re
import subprocess
from pathlib import Path

root = Path.cwd()
results = []
for path in sorted((root / "frontend/tests").glob("*.mjs")):
    result = subprocess.run(
        ["node", "--experimental-strip-types", str(path)],
        cwd=root / "frontend", capture_output=True, text=True,
    )
    log = result.stdout + result.stderr
    (root / ".cache/stream-b" / f"frontend-direct-{path.name}.log").write_text(log)
    tests = re.search(r"^# tests (\d+)$", result.stdout, re.MULTILINE)
    passed = re.search(r"^# pass (\d+)$", result.stdout, re.MULTILINE)
    failed = re.search(r"^# fail (\d+)$", result.stdout, re.MULTILINE)
    assert result.returncode == 0, (path.name, result.returncode)
    assert tests and passed and failed, path.name
    assert int(tests[1]) == int(passed[1]) > 0 and int(failed[1]) == 0, path.name
    results.append({"file": str(path.relative_to(root)), "tests": int(tests[1]), "exit_code": result.returncode})
report = {"files": results, "tests": sum(row["tests"] for row in results)}
(root / ".cache/stream-b/frontend-direct-results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report))
