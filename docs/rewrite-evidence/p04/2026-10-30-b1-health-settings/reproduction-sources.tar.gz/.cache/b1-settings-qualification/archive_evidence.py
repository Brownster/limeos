# /// script
# dependencies = []
# ///
"""Preserve the source-bound pure health-settings qualification."""
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/b1-settings-qualification'
DEST = ROOT / 'docs/rewrite-evidence/p04/2026-10-30-b1-health-settings'
COMMIT = subprocess.check_output(['git', 'rev-parse', '32265d4'], cwd=ROOT, text=True).strip()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def committed(name):
    return subprocess.check_output(['git', 'show', f'{COMMIT}:{name}'], cwd=ROOT)


def put(name, data):
    path = DEST / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


assert not DEST.exists()
records = {}
for path in sorted((ROOT / '.cache/main-consolidation/attempts').glob('b1-settings-*')):
    record = json.loads((path / 'record.json').read_text())
    assert record['inputs_unchanged'] and record['before'] == record['after']
    assert not record['guard_triggered'] and not record['observed_external_compilers']
    assert record['minimum_available_bytes'] >= record['memory_floor_bytes'] == 3 * 1024**3
    records[path.name] = record
    for name in ['record.json', 'output.log']:
        put(f'checks/{path.name}/{name}.gz', gzip.compress((path / name).read_bytes(), mtime=0))
final = ['b1-settings-rust-2', 'b1-settings-clippy-2', 'b1-settings-contracts-1']
expected = records[final[0]]['before']
assert len(expected) == 702
for label in final:
    assert records[label]['exit_code'] == 0 and records[label]['before'] == expected
for name, sha in expected.items():
    assert digest(committed(name)) == sha, name
    assert digest((ROOT / name).read_bytes()) == sha, name
for path in sorted(STATE.iterdir()):
    if path.suffix in ['.json', '.log']:
        put(f'launch-and-local/{path.name}.gz', gzip.compress(path.read_bytes(), mtime=0))
changed = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', COMMIT], cwd=ROOT, text=True).splitlines()
names = changed + ['tests/fixtures/automation/frozen-notification-settings.json', 'tests/reference/frozen_notifications.py', 'tests/reference/test_frozen_notifications.py']
sources = {name: committed(name) for name in names}
for path in [*STATE.glob('*.py'), ROOT / '.cache/main-consolidation/guard.py', ROOT / '.cache/stack-installed-qualification/detached_guard.py']:
    sources[str(path.relative_to(ROOT))] = path.read_bytes()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, data in sorted(sources.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
put('reproduction-sources.tar.gz', gzip.compress(buffer.getvalue(), mtime=0))
patch = subprocess.check_output(['git', 'show', '--format=fuller', '--binary', COMMIT], cwd=ROOT)
put('source.patch.gz', gzip.compress(patch, mtime=0))
match = {
    'qualified_commit': COMMIT,
    'recorded_precommit_head': records[final[0]]['head'],
    'final_identical_guard_input_maps': final,
    'committed_input_count': len(expected),
    'committed_inputs_match': True,
    'worktree_inputs_match': True,
    'first_passing_rust_only_source_delta': sorted(name for name in expected if expected[name] != records['b1-settings-rust-1']['before'].get(name)),
    'runtime_tests': 559,
    'compile_fail_doctests': 7,
    'new_tests': 12,
    'covered_frozen_fixture_cases': 21,
    'total_frozen_fixture_cases': 32,
    'checks': {label: {key: record[key] for key in ['started', 'ended', 'exit_code', 'inputs_unchanged', 'guard_triggered', 'minimum_available_bytes', 'memory_floor_bytes', 'observed_external_compilers']} for label, record in records.items()},
    'reproduction_source_hashes': {name: digest(data) for name, data in sorted(sources.items())},
    'scope': 'Pure migration-planner tests only; no deployed configuration, Store policy binding, runtime producer, package, ARM64, external send or cutover acceptance',
}
put('source-match.json', (json.dumps(match, indent=2) + '\n').encode())
print(json.dumps({'commit': COMMIT, 'inputs': len(expected), 'guard_records': len(records), 'files': len([path for path in DEST.rglob('*') if path.is_file()])}))
