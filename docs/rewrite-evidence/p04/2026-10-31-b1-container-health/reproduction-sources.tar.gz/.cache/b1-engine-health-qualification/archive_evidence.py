# /// script
# dependencies = []
# ///
"""Seal retained health evidence and the original local attempts."""
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT=Path('/home/marc/Documents/github/lime-os')
STATE=ROOT/'.cache/b1-engine-health-qualification'
DEST=ROOT/'docs/rewrite-evidence/p04/2026-10-31-b1-container-health'
COMMIT=(STATE/'feature-commit.txt').read_text().strip()
FINAL=json.loads((STATE/'final-checks.json').read_text())
assert len(COMMIT)==40 and not DEST.exists()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def committed(name):
    return subprocess.check_output(['git','show',f'{COMMIT}:{name}'],cwd=ROOT)


def put(name,data):
    path=DEST/name
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


records={}
for directory in sorted((ROOT/'.cache/main-consolidation/attempts').glob('b1-engine-health-*')):
    record=json.loads((directory/'record.json').read_text())
    assert record.get('ended'),directory.name
    records[directory.name]=record
    for name in ['record.json','output.log']:
        put(f'checks/{directory.name}/{name}.gz',gzip.compress((directory/name).read_bytes(),mtime=0))
expected=records[FINAL[0]]['before']
for label in FINAL:
    record=records[label]
    assert record['exit_code']==0 and record['inputs_unchanged']
    assert record['before']==record['after']==expected
    assert not record['guard_triggered'] and not record['observed_external_compilers']
    assert record['minimum_available_bytes']>=record['memory_floor_bytes']==3*1024**3
for name,sha in expected.items():
    assert digest(committed(name))==digest((ROOT/name).read_bytes())==sha,name
for path in sorted(STATE.iterdir()):
    if path.is_file() and path.suffix in ['.json','.log']:
        put(f'launch-and-local/{path.name}.gz',gzip.compress(path.read_bytes(),mtime=0))
changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',COMMIT],cwd=ROOT,text=True).splitlines()
sources={name:committed(name) for name in changed}
for path in [*STATE.glob('*.py'),ROOT/'.cache/main-consolidation/guard.py',ROOT/'.cache/stack-installed-qualification/detached_guard.py']:
    sources[str(path.relative_to(ROOT))]=path.read_bytes()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,data in sorted(sources.items()):
        info=tarfile.TarInfo(name)
        info.size=len(data)
        info.mode=0o755 if (ROOT/name).stat().st_mode&0o111 else 0o644
        info.mtime=0
        archive.addfile(info,io.BytesIO(data))
put('reproduction-sources.tar.gz',gzip.compress(buffer.getvalue(),mtime=0))
put('source.patch.gz',gzip.compress(subprocess.check_output(['git','show','--format=fuller','--binary',COMMIT],cwd=ROOT),mtime=0))
summary={
    'qualified_commit':COMMIT,
    'parent_commit':subprocess.check_output(['git','rev-parse',f'{COMMIT}^'],cwd=ROOT,text=True).strip(),
    'final_identical_guard_input_maps':FINAL,
    'committed_input_count':len(expected),
    'committed_inputs_match':True,
    'worktree_inputs_match':True,
    'runtime_tests_passed':986,
    'compile_fail_doctests_passed':33,
    'new_runtime_tests':11,
    'new_compile_fail_doctests':2,
    'outer_ignored_child_entry_points':[
        'storage_mount_admission::tests::journal_capacity_probe',
        'runtime_tests::mount_runtime_child',
    ],
    'passing_parent_regressions':[
        'storage_mount_admission::tests::operation_capacity_boundaries_use_real_descriptors_in_an_isolated_process',
        'runtime_tests::mount_bootstrap_keeps_its_thread_set_through_unix_and_child_io',
    ],
    'checks':{label:{key:record[key] for key in ['started','ended','exit_code','inputs_unchanged','guard_triggered','minimum_available_bytes','memory_floor_bytes','observed_external_compilers']} for label,record in records.items()},
    'draft_input_differences_from_final':{label:sorted(name for name in set(expected)|set(record['before']) if expected.get(name)!=record['before'].get(name)) for label,record in records.items() if label not in FINAL},
    'reproduction_source_hashes':{name:digest(data) for name,data in sorted(sources.items())},
    'scope':'Actual owned Unix-listener HTTP collection under private unit credentials/clocks; no installed UID-0 Engine, actual Docker, worker/RPC registration, API/UI, footprint, package, ARM64/Pi or cutover qualification',
}
put('source-match.json',(json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps({'commit':COMMIT,'inputs':len(expected),'guards':len(records),'files':len([p for p in DEST.rglob('*') if p.is_file()])}))
