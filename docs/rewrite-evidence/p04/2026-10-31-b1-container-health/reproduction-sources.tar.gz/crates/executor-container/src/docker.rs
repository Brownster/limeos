//! Selected Docker Engine API over a fixed Unix socket. No automatic POST retry.
use crate::Engine;
use http_body_util::{BodyExt, Empty};
use hyper::{Request, StatusCode, body::Bytes};
use limeos_domain::{ContainerAction, ContainerSnapshot, Error, ErrorCode, Result, opaque_id};
use serde_json::Value;
use std::{path::PathBuf, time::Duration};
use tokio::net::UnixStream;
pub mod compose_evidence;
pub mod health_evidence;
pub mod process_evidence;
mod read_admission;
mod storage;
#[cfg(test)]
mod tests;

#[derive(Clone)]
pub struct Docker {
    socket: PathBuf,
}
impl Docker {
    pub fn new(socket: PathBuf) -> Self {
        Self { socket }
    }
    pub async fn logs(
        &self,
        resource: &str,
        options: limeos_domain::LogOptions,
    ) -> Result<limeos_domain::ContainerLogs> {
        options.validate()?;
        let id = resource.strip_prefix("container:").unwrap_or_default();
        if !opaque_id(id) {
            return Err(Error(ErrorCode::InvalidInput));
        }
        tokio::time::timeout(Duration::from_secs(4), async {
            let version = self.version().await?;
            let inspect = self.json(format!("/{version}/containers/{id}/json"), 512 * 1024).await?;
            if inspect["Id"].as_str() != Some(id) {return Err(Error(ErrorCode::Conflict));}
            let tty = inspect["Config"]["Tty"].as_bool().ok_or(Error(ErrorCode::Unavailable))?;
            let (status, raw, clipped) = self.request_clipped("GET", format!("/{version}/containers/{id}/logs?stdout=1&stderr=1&follow=0&tail={}&timestamps=1", options.tail), 64 * 1024, true).await?;
            if status != StatusCode::OK {return Err(Error(ErrorCode::Unavailable));}
            crate::logs::decode(resource.into(), &raw, tty, clipped)
        }).await.map_err(|_| Error(ErrorCode::Unavailable))?
    }
    async fn request(
        &self,
        method: &str,
        path: String,
        limit: usize,
    ) -> Result<(StatusCode, Vec<u8>)> {
        let (status, bytes, _) = self.request_clipped(method, path, limit, false).await?;
        Ok((status, bytes))
    }
    async fn request_clipped(
        &self,
        method: &str,
        path: String,
        limit: usize,
        clip: bool,
    ) -> Result<(StatusCode, Vec<u8>, bool)> {
        self.request_clipped_inner(method, path, limit, clip, None)
            .await
    }
    async fn request_clipped_inner(
        &self,
        method: &str,
        path: String,
        limit: usize,
        clip: bool,
        authenticated: Option<(
            &process_evidence::AuthenticatedEngine,
            &process_evidence::ResponseBudget,
        )>,
    ) -> Result<(StatusCode, Vec<u8>, bool)> {
        if let Some((peer, _)) = authenticated {
            peer.revalidate_socket()?;
        }
        let stream = UnixStream::connect(&self.socket)
            .await
            .map_err(|_| Error(ErrorCode::Unavailable))?;
        if let Some((peer, _)) = authenticated {
            peer.authenticate(&stream)?;
            peer.revalidate_socket()?;
        }
        let mut builder = hyper::client::conn::http1::Builder::new();
        if authenticated.is_some() {
            builder.max_buf_size(32 * 1024).max_headers(64);
        }
        let (mut sender, connection) = builder
            .handshake(hyper_util::rt::TokioIo::new(stream))
            .await
            .map_err(|_| Error(ErrorCode::Unavailable))?;
        // A dropped request must also end its connection task. In particular a
        // timeout cannot leave an unbounded set of stuck Engine connections.
        let connection = tokio::spawn(async move {
            let _ = connection.await;
        });
        struct ConnectionTask(tokio::task::JoinHandle<()>);
        impl Drop for ConnectionTask {
            fn drop(&mut self) {
                self.0.abort();
            }
        }
        let _connection = ConnectionTask(connection);
        let request = Request::builder()
            .method(method)
            .uri(path)
            .header("Host", "localhost")
            .header("Accept", "application/json")
            .body(Empty::<Bytes>::new())
            .map_err(|_| Error(ErrorCode::InvalidInput))?;
        let response = sender
            .send_request(request)
            .await
            .map_err(|_| Error(ErrorCode::Unavailable))?;
        let status = response.status();
        let mut body = response.into_body();
        let mut bytes = Vec::new();
        while let Some(frame) = body.frame().await {
            if let Ok(data) = frame
                .map_err(|_| Error(ErrorCode::Unavailable))?
                .into_data()
            {
                if let Some((_, budget)) = authenticated {
                    budget.consume(data.len())?;
                }
                if bytes.len() + data.len() > limit {
                    if clip {
                        bytes.extend_from_slice(&data[..limit - bytes.len()]);
                        return Ok((status, bytes, true));
                    }
                    return Err(Error(ErrorCode::Unavailable));
                }
                if let Some((_, budget)) = authenticated {
                    if budget.constrained() {
                        bytes
                            .try_reserve_exact(data.len())
                            .map_err(|_| Error(ErrorCode::Unavailable))?;
                    }
                }
                bytes.extend_from_slice(&data);
            }
        }
        if let Some((peer, _)) = authenticated {
            peer.revalidate_socket()?;
        }
        Ok((status, bytes, false))
    }
    async fn json(&self, path: String, limit: usize) -> Result<Value> {
        tokio::time::timeout(Duration::from_secs(2), async {
            let (status, bytes) = self.request("GET", path, limit).await?;
            if status != StatusCode::OK {
                return Err(Error(ErrorCode::Unavailable));
            }
            serde_json::from_slice(&bytes).map_err(|_| Error(ErrorCode::Unavailable))
        })
        .await
        .map_err(|_| Error(ErrorCode::Unavailable))?
    }
    async fn version(&self) -> Result<String> {
        let value = self.json("/version".into(), 8192).await?;
        parse_api_version(&value)
    }
    async fn effect(&self, id: &str, operation: ContainerAction) -> Result<()> {
        if !opaque_id(id) {
            return Err(Error(ErrorCode::InvalidInput));
        }
        let version = self.version().await?;
        let query = if operation == ContainerAction::Start {
            ""
        } else {
            "?t=10"
        };
        let (status, _) = self
            .request(
                "POST",
                format!("/{version}/containers/{id}/{}{query}", operation.as_str()),
                8192,
            )
            .await?;
        if status != StatusCode::NO_CONTENT {
            return Err(Error(ErrorCode::Unavailable));
        }
        Ok(())
    }
}
fn parse_api_version(value: &Value) -> Result<String> {
    let parse = |s: &str| s.strip_prefix("1.")?.parse::<u32>().ok();
    let max = parse(value["ApiVersion"].as_str().unwrap_or_default())
        .ok_or(Error(ErrorCode::Unavailable))?
        .min(56);
    let min = parse(value["MinAPIVersion"].as_str().unwrap_or("1.24"))
        .ok_or(Error(ErrorCode::Unavailable))?;
    if max < 41 || min > max {
        return Err(Error(ErrorCode::Unavailable));
    }
    Ok(format!("v1.{max}"))
}
impl Engine for Docker {
    async fn inspect(&self, id: &str) -> Result<ContainerSnapshot> {
        if !opaque_id(id) {
            return Err(Error(ErrorCode::InvalidInput));
        }
        let version = self.version().await?;
        let value = self
            .json(format!("/{version}/containers/{id}/json"), 512 * 1024)
            .await?;
        // Reject an inconsistent identity; never leak Config.Env, labels or paths.
        if value["Id"].as_str() != Some(id) {
            return Err(Error(ErrorCode::Unavailable));
        }
        let snapshot = ContainerSnapshot {
            resource: format!("container:{id}"),
            image: value["Image"]
                .as_str()
                .ok_or(Error(ErrorCode::Unavailable))?
                .into(),
            started_at: value["State"]["StartedAt"]
                .as_str()
                .ok_or(Error(ErrorCode::Unavailable))?
                .into(),
            running: value["State"]["Running"]
                .as_bool()
                .ok_or(Error(ErrorCode::Unavailable))?,
        };
        snapshot
            .validate()
            .map_err(|_| Error(ErrorCode::Unavailable))?;
        Ok(snapshot)
    }
    async fn restart(&self, id: &str) -> Result<()> {
        // Negotiate before POST. A lost/failed response is uncertainty, never a
        // reason to issue a second restart. The 10-second grace is server owned.
        self.effect(id, ContainerAction::Restart).await
    }
    async fn start(&self, id: &str) -> Result<()> {
        self.effect(id, ContainerAction::Start).await
    }
    async fn stop(&self, id: &str) -> Result<()> {
        self.effect(id, ContainerAction::Stop).await
    }
}
