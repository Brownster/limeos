import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";
import { mkdirSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
const require = createRequire(resolve("frontend/package.json"));
const { build } = await import(pathToFileURL(require.resolve("vite")).href);
const root = resolve(".cache/automation-ui/panel");
mkdirSync(root, {recursive:true});
writeFileSync(resolve(root,"index.html"), '<!doctype html><html lang="en"><head><meta charset="UTF-8"><title>Automation panel qualification</title></head><body><div id="root"></div><script type="module" src="/entry.tsx"></script></body></html>');
writeFileSync(resolve(root,"entry.tsx"), `import React from "react"; import {createRoot} from "react-dom/client"; import {AutomationPanel} from ${JSON.stringify(resolve("frontend/src/AutomationView.tsx"))}; import ${JSON.stringify(resolve("frontend/src/style.css"))}; createRoot(document.getElementById("root")!).render(<AutomationPanel principal="local-qualification" grantRevision={1} csrf="fixture-only" canManage={true} canAcknowledge={true} expired={() => {}}/>);`);
await build({root, configFile:false, resolve:{alias:[
  {find:"react/jsx-runtime",replacement:require.resolve("react/jsx-runtime")},
  {find:"react-dom/client",replacement:require.resolve("react-dom/client")},
  {find:"react-dom",replacement:require.resolve("react-dom")},
  {find:"react",replacement:require.resolve("react")},
]}, build:{outDir:resolve(".cache/automation-ui/panel-dist"),emptyOutDir:true}});
