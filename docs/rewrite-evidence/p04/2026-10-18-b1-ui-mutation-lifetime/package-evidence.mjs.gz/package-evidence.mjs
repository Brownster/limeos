import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from "node:fs";
import { resolve } from "node:path";
import { gzipSync } from "node:zlib";
import { createRequire } from "node:module";
const scratch = ".cache/automation-ui";
const packet = "docs/rewrite-evidence/p04/2026-10-18-b1-ui-mutation-lifetime";
mkdirSync(packet, {recursive:true});
const digest = data => createHash("sha256").update(data).digest("hex");
const source = readFileSync(`${scratch}/tested-source.txt`, "utf8").trim();
assert.match(source,/^[0-9a-f]{40}$/);
const paths = readFileSync(`${scratch}/input-paths.txt`, "utf8").trim().split("\n").sort();
const inputs = paths.map(path => ({path,sha256:digest(readFileSync(path)),bytes:statSync(path).size}));
writeFileSync(`${packet}/inputs.sha256`, inputs.map(row=>`${row.sha256}  ${row.path}\n`).join(""));
const checks = [
  ["api.mjs","api-transpiled-direct.log",4],
  ["automation-controller.test.mjs","frontend-automation-controller.test.mjs.log",14],
  ["automation.test.mjs","frontend-automation.test.mjs.log",10],
  ["automation-mutations.test.mjs","frontend-automation-mutations.test.mjs.log",15],
  ["media-activity-client.test.mjs","frontend-media-activity-client.test.mjs.log",29],
  ["media-activity.test.mjs","frontend-media-activity.test.mjs.log",10],
  ["observations.test.mjs","frontend-observations.test.mjs.log",4],
  ["stack-discovery.test.mjs","frontend-stack-discovery.test.mjs.log",18],
].map(([file,log,expected])=>{
  const output=readFileSync(`${scratch}/${log}`,"utf8");
  const count=key=>Number(output.match(new RegExp(`^# ${key} (\\d+)$`,"m"))?.[1]);
  assert.equal(count("tests"),expected,file);assert.equal(count("pass"),expected,file);assert.equal(count("fail"),0,file);
  return {file,log,passed:expected,failed:0};
});
assert.equal(checks.reduce((sum,row)=>sum+row.passed,0),104);
const require=createRequire(resolve("frontend/package.json"));
const dependencies=["react","react-dom","typescript","vite"].map(name=>{
  const path=require.resolve(`${name}/package.json`);const data=readFileSync(path);
  return {name,version:JSON.parse(data).version,package_json_sha256:digest(data)};
});
const domPath=resolve(require.resolve("react-dom/package.json"),"../cjs/react-dom.development.js");
const dom=readFileSync(domPath,"utf8");
assert.ok(dom.includes("flushPassiveEffectsImpl") && dom.includes("commitHookEffectListUnmount"));
const changed=readFileSync(`${scratch}/changed-paths.txt`,"utf8").trim().split("\n");
assert.equal(changed.length,8);assert.ok(changed.every(path=>path.startsWith("frontend/")||path==="docs/plans/2026-10-18-b1-ui-mutation-lifetime-design.md"));
const manifest={tested_source:source,base:"7df3f7530865c31b7faefd1f7b12a25aa7655860",branch:"engineer/p04-automation-ui-lifetime",node:process.version,platform:process.platform,architecture:process.arch,dependencies,react_dom_development_sha256:digest(dom),input_count:inputs.length,changed_paths:changed,checks,passed_cases:104,new_cases:15,browser_execution:"UNRUN",installed_qualification:"UNRUN",rust_checks:"UNRUN: no Rust changes",central_schedule_registration:"Separate owner worktree; not included"};
writeFileSync(`${packet}/manifest.json`,JSON.stringify(manifest,null,2)+"\n");
const files=[...checks.map(row=>row.log),"types.log","production-build.log","panel-build.log","baseline-reproduction.log","initial-count-refusal.log","frontend-suite.log","api-explicit.log","baseline-AutomationView.tsx","reproduce.mjs","check-frontend.mjs","build-panel.mjs","package-evidence.mjs","api-transpiled.mjs","changed-paths.txt","tested-source.txt"];
for(const file of new Set(files))writeFileSync(`${packet}/${file}.gz`,gzipSync(readFileSync(`${scratch}/${file}`),{level:9}));
for(const directory of ["frontend/dist",`${scratch}/panel-dist`]){
  const collect=path=>{
    for(const name of readdirSync(path)){const target=`${path}/${name}`;if(statSync(target).isDirectory())collect(target);else {
      const suffix=target.slice(directory.length+1).replaceAll("/","_");
      const label=directory.startsWith("frontend")?"main-bundle":"panel-bundle";
      writeFileSync(`${packet}/${label}-${suffix}.gz`,gzipSync(readFileSync(target),{level:9}));
    }}
  };collect(directory);
}
const panelJS=readdirSync(`${scratch}/panel-dist/assets`).find(path=>path.endsWith(".js"));
const panel=readFileSync(`${scratch}/panel-dist/assets/${panelJS}`,"utf8");
assert.ok(panel.includes("Request outcome is unconfirmed")&&panel.includes("Saving acknowledgment")&&panel.includes("Create observation schedule"));
const artifacts=readdirSync(packet).filter(path=>path!=="artifacts.sha256").sort();
writeFileSync(`${packet}/artifacts.sha256`,artifacts.map(path=>`${digest(readFileSync(`${packet}/${path}`))}  ${path}\n`).join(""));
console.log(JSON.stringify({source,input_count:inputs.length,artifacts:artifacts.length,tests:104}));
