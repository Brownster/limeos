import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(new URL('../../frontend/package.json', import.meta.url));
const ts = require('typescript');
const source = readFileSync('.cache/automation-ui/baseline-AutomationView.tsx', 'utf8');
const parsed = ts.createSourceFile('AutomationView.tsx', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
let expression;
function visit(node) {
  if (ts.isVariableDeclaration(node) && node.name.getText(parsed) === 'mutate') expression = node.initializer.getText(parsed);
  ts.forEachChild(node, visit);
}
visit(parsed);
assert.ok(expression, 'extract actual old mutation callback');
const js = ts.transpileModule(`const callback = ${expression};`, {compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
let busy = false, sends = 0, completed = 0, failures = 0;
const callback = new Function('blocked', 'setBusy', 'setError', 'changed', 'failed', `${js}; return callback;`)(false, value => {busy=value;}, () => {}, () => {completed++;}, () => {failures++;});
let finish;
const response = new Promise(resolve => {finish=resolve;});
const first = callback(() => {sends++;return response;});
const duplicate = callback(() => {sends++;return response;});
assert.equal(busy,true);
assert.equal(sends,2,'both callbacks use the same render snapshot despite setBusy(true)');
// The component can now be unmounted or replaced; the extracted callback has no lifetime check.
finish({}); await Promise.all([first,duplicate]);
assert.equal(completed,2,'both abandoned continuations still call changed');
assert.equal(failures,0);
console.log(JSON.stringify({source:'7df3f753:frontend/src/AutomationView.tsx',actual_callback_extracted:true,post_invocations:sends,abandoned_completion_callbacks:completed,expected_failure_reproduced:true}));
