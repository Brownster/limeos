import { readFileSync, readdirSync, writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { resolve } from "node:path";
const require = createRequire(resolve("frontend/package.json"));
const ts = require("typescript");
const results = [];
for (const file of readdirSync("frontend/tests").filter(file => file.endsWith(".mjs")).sort()) {
  let path = `tests/${file}`;
  if (file === "api.mjs") {
    // This runtime returned no native case output for the direct .ts import.
    // Use the pinned compiler, as the other frontend test helpers already do.
    const code = ts.transpileModule(readFileSync("frontend/src/api.ts", "utf8"), { compilerOptions: {module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022} }).outputText;
    const url = `data:text/javascript;base64,${Buffer.from(code).toString("base64")}`;
    const fixture = readFileSync(`frontend/tests/${file}`, "utf8").replace('"../src/api.ts"', JSON.stringify(url));
    path = resolve(".cache/automation-ui/api-transpiled.mjs"); writeFileSync(path, fixture);
  }
  const result = spawnSync("node", ["--experimental-strip-types", path], { cwd: "frontend", encoding: "utf8", env: process.env });
  writeFileSync(`.cache/automation-ui/frontend-${file}.log`, result.stdout + result.stderr);
  const count = key => Number(result.stdout.match(new RegExp(`^# ${key} (\\d+)$`, "m"))?.[1]);
  const tests = count("tests"), passed = count("pass"), failed = count("fail");
  assert.equal(result.status, 0, `${file}: see preserved log`);
  assert.ok(tests > 0 && tests === passed && failed === 0, file);
  results.push({ file, tests, passed, failed, exit_code: result.status });
}
const report = { files: results, tests: results.reduce((sum, row) => sum + row.tests, 0) };
writeFileSync(".cache/automation-ui/frontend-results.json", JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report));
