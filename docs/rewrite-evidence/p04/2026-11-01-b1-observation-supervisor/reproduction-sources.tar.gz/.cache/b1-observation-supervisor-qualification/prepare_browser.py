# /// script
# dependencies = []
# ///
"""Adapt the existing closed mounted-browser fixture for current runtime states."""
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os')
state = Path(__file__).parent
text = (root / '.cache/schedules-ui/browser-2-fixture.py').read_text()
text = text.replace('"partial": False', '"partial": True')
before = '"status": "awaiting_producer",\n                                "last_occurrence": None,'
assert text.count(before) == 1
text = text.replace(before, '"status": "scheduled",\n                                "runtime": {"phase": "waiting", "last_attempt": None},\n                                "last_occurrence": None,')
before = '''                    rows[0]["status"] = (
                        "paused" if body["paused"] else "awaiting_producer"
                    )'''
assert text.count(before) == 1
text = text.replace(before, '''                    rows[0]["status"] = "paused" if body["paused"] else "scheduled"
                    if body["paused"]:
                        rows[0].pop("runtime", None)
                    else:
                        rows[0]["runtime"] = {"phase": "waiting", "last_attempt": None}''')
text = text.replace('"Waiting for observations", exact=True', '"Automatic checks enabled", exact=True')
before = '            page.screenshot(path=str(args.output / "schedules.png"), full_page=True)'
assert text.count(before) == 1
text = text.replace(before, '''            for phase, label in [("checking", "Checking containers"), ("partial", "Last container check completed"), ("unavailable", "Container checks unavailable")]:
                rows[0]["runtime"] = {"phase": phase, "last_attempt": int(time.time())}
                page.get_by_role("button", name="Refresh schedules", exact=True).click()
                page.get_by_text(label, exact=True).wait_for()
                assert page.locator("time").count() == 1
            assert "Check service setup and current permissions" in page.locator("body").inner_text()
''' + before)
text = text.replace('"desktop/mobile render",', '"runtime waiting/checking/partial/unavailable phases",\n                            "historical attempt time and partial coverage",\n                            "desktop/mobile render",')
(state / 'browser_fixture.py').write_text(text)
path = state / 'launch_check.py'
text = path.read_text()
text = text.replace("commands = {", "commands = {\n    'browser': ['uv', 'run', '--offline', '--no-project', '--python', '/usr/bin/python3', str(STATE / 'browser_fixture.py'), '--output', str(STATE / 'browser-current')],")
text = text.replace("'--bin', 'limeos-core', 'automation_runtime']", "'--bin', 'limeos-core', 'automation_runtime', '--', '--nocapture']")
path.write_text(text)
