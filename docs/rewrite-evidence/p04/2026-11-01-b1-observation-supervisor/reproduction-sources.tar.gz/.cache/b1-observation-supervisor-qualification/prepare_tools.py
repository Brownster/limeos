# /// script
# dependencies = []
# ///
"""Reuse the unchanged native guard launch pattern for this runtime qualification."""
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os')
old = root / '.cache/b1-container-admission-qualification'
state = Path(__file__).parent
for name in ['launch_check.py', 'summarize.py', 'record_end.py', 'archive_evidence.py', 'seal_packet.py', 'check_sanity.py']:
    text = (old / name).read_text()
    text = text.replace('2026-10-31-b1-container-admission-recovery-design.md', '2026-10-31-b1-observation-supervisor-design.md')
    text = text.replace('2026-10-31-b1-container-admission-recovery', '2026-10-31-b1-observation-supervisor')
    text = text.replace('b1-container-admission', 'b1-observation-supervisor')
    if name == 'launch_check.py':
        text = text.replace("'container_read'", "'runtime_hints'").replace("'health_collection'", "'automation_runtime'")
        text = text.replace("commands = {", "commands = {\n    'integration': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-core', '--test', 'observation_runtime', '--', '--nocapture'],\n    'schema': ['cargo', 'run', '--offline', '--locked', '-p', 'limeos-schema', '--', str(STATE / 'generated')],\n    'frontend': [sys.executable, str(STATE / 'check_frontend.py')],")
    (state / name).write_text(text)
text = (root / '.cache/b1-health-runtime-qualification/check_frontend.py').read_text().replace('b1-health-runtime-qualification','b1-observation-supervisor-qualification')
(state / 'check_frontend.py').write_text(text)

# Update only obsolete descriptions in the actual generator source.
path = root / 'bins/schema/src/main.rs'
text = path.read_text()
replacements = {
    'Does not start automation.': 'Does not create or resume schedules.',
    'Read at most 32 owned ObserveHealth schedules within 64 KiB. Metadata only: AwaitingProducer is not running; AuthoritySuspended requires explicit current-authority resume. Reads do not revise authority, advance watermarks or invoke a collector.': 'Read at most 32 owned ObserveHealth schedules within 64 KiB. Scheduled includes bounded historical partial/unavailable runtime diagnostics while the owned Core producer runs. AwaitingProducer is not running; AuthoritySuspended requires explicit current-authority resume. Reads do not revise authority, advance watermarks or invoke a collector.',
    'No timer, job, producer or effect is started.': 'The owned Core producer later admits due container observations under current authority; this request commits metadata only.',
    'Durable schedule metadata, awaiting a genuine producer': 'Durable schedule metadata with current partial observation registration',
    'The production collector and supervisor remain unavailable.': 'Registered automatic container checks remain globally partial.',
}
for before, after in replacements.items():
    assert text.count(before) == 1, before
    text = text.replace(before, after)
path.write_text(text)
