# /// script
# dependencies = []
# ///
"""Summarize current immutable run records and outer Cargo result groups."""
import json
import re
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os/.cache/main-consolidation/attempts')
for directory in sorted(root.glob('b1-observation-supervisor-*')):
    record = json.loads((directory / 'record.json').read_text())
    group = 'start'
    groups = {}
    output = (directory / 'output.log').read_text()
    for line in output.splitlines():
        if re.match(r'\s*(?:Running |Doc-tests )', line):
            group = line.strip()
        match = re.search(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', line)
        if match:
            groups[group] = {'passed': int(match[2]), 'failed': int(match[3]), 'ignored': int(match[4]), 'doc': group.startswith('Doc-tests ')}
    summary = {key: record.get(key) for key in ['pid', 'ended', 'exit_code', 'inputs_unchanged', 'minimum_available_bytes', 'guard_triggered']}
    summary.update(runtime=sum(g['passed'] for g in groups.values() if not g['doc']), doctests=sum(g['passed'] for g in groups.values() if g['doc']), ignored=sum(g['ignored'] for g in groups.values()), tail=output.splitlines()[-3:])
    print(json.dumps({'label': directory.name, **summary}))
