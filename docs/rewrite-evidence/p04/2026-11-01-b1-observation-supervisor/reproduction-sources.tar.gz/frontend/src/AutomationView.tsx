import { useEffect, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { automationClient } from "./automation-client";
import { AutomationController } from "./automation-controller";
import { NotificationsView } from "./NotificationsView";
import type { AutomationState, PageKind } from "./automation-controller";
import type { AlertState, Page, ObserveHealthScheduleInput, ScheduleView } from "./automation-client";

export function AutomationView({ schedules, alerts, canManage, create, pause, moreSchedules, moreAlerts, error, busy = false, disabled = false, showAlerts = true }: {
  schedules: Page<ScheduleView> | null; alerts: Page<AlertState> | null; canManage: boolean;
  create?: (input: ObserveHealthScheduleInput) => void; pause?: (row: ScheduleView) => void;
  moreSchedules: () => void; moreAlerts: () => void;
  error?: string | null; busy?: boolean; disabled?: boolean; showAlerts?: boolean;
}) {
  const [formError, setFormError] = useState("");
  const [minutes, setMinutes] = useState(10); const [start, setStart] = useState(0); const [end, setEnd] = useState(0);
  const [windowEnabled, setWindowEnabled] = useState(false);
  const [missed, setMissed] = useState<ObserveHealthScheduleInput["missed"]>("coalesce_latest");
  const blocked = busy || disabled;
  return <section aria-labelledby="automation-heading">
    <p className="eyebrow">AUTOMATION</p><h2 id="automation-heading">{showAlerts ? "Schedules and alerts" : "Health schedules"}</h2>
    {(schedules?.partial || (showAlerts && alerts?.partial)) && <p className="notice" role="status">Some observations are unavailable. {showAlerts && "Missing observations keep active alerts open."}</p>}
    {error && <p className="error" role="alert">{error}</p>}
    {formError && <p className="error" role="alert">{formError}</p>}
    {busy && <p role="status">Saving schedule change…</p>}
    <div className="table-wrap" tabIndex={0} role="region" aria-label="Observation schedules"><table className="schedules-table"><caption>Observation schedules</caption><thead><tr><th scope="col">Schedule</th><th scope="col">Timing</th><th scope="col">Status</th><th scope="col">Action</th></tr></thead>
      <tbody>{schedules?.items.map(row => <tr key={row.schedule.id}><th scope="row"><abbr title={row.schedule.id}>{scheduleReference(row.schedule.id)}</abbr><small>{row.schedule.definition.operation === "observe_health" ? "Health observations" : row.schedule.definition.operation.replaceAll("_", " ")}</small></th>
        <td>Every {row.schedule.definition.interval_seconds / 60} minutes<small>{row.schedule.definition.window ? `UTC ${clock(row.schedule.definition.window.start_minute)}–${clock(row.schedule.definition.window.end_minute)}` : "Any time · UTC"}</small></td>
        <td><span className={`badge ${row.status === "blocked" || row.status === "authority_suspended" || row.status === "scheduled" ? "warning" : ""}`}>{scheduleLabel(row)}</span>{row.status === "blocked" && <small>Operation adapter is unavailable.</small>}
          {row.status === "awaiting_producer" && <small>Schedule saved. Automatic observations are not available yet.</small>}
          {row.status === "scheduled" && <>
            <small>{row.runtime?.phase === "unavailable" ? "Container checks are unavailable. Check service setup and current permissions." : "Automatic container checks are enabled."} Health coverage remains partial; other scheduled checks are unavailable.</small>
            {row.runtime?.last_attempt !== null && row.runtime?.last_attempt !== undefined && <small>Last attempt · <time dateTime={new Date(row.runtime.last_attempt * 1000).toISOString()}>{new Date(row.runtime.last_attempt * 1000).toISOString()}</time></small>}
          </>}
          {row.status === "authority_suspended" && <small>Scheduling permission needs renewal before this schedule can resume.</small>}
          {row.last_occurrence && <small>Latest occurrence · {new Date(row.last_occurrence.key.due * 1000).toISOString()}<br />{row.last_occurrence.outcome.outcome === "job" ? `Job ${row.last_occurrence.outcome.id} · ${row.last_occurrence.outcome.state.replaceAll("_", " ")}` : row.last_occurrence.outcome.outcome}</small>}</td>
        <td>{canManage && <button aria-label={`${row.schedule.paused ? "Resume" : "Pause"} ${row.schedule.id}`} disabled={blocked || !pause} onClick={() => { if (!blocked) pause?.(row); }}>{row.schedule.paused ? "Resume" : "Pause"} {scheduleReference(row.schedule.id)}</button>}</td>
      </tr>)}{schedules?.items.length === 0 && <tr><td colSpan={4}>No schedules on this page.</td></tr>}{!schedules && <tr><td colSpan={4}>Schedule data is unavailable.</td></tr>}</tbody></table></div>
    {schedules?.next && <button onClick={moreSchedules} disabled={busy}>Next schedules</button>}
    {canManage && <form onSubmit={event => {
      event.preventDefault();
      if (blocked) return;
      if (windowEnabled && start === end) { setFormError("Choose different window start and end times."); return; }
      setFormError("");
      const definition: ObserveHealthScheduleInput = { interval_seconds: minutes * 60,
        grace_seconds: 30, missed, window: windowEnabled ? { start_minute: start, end_minute: end } : null };
      create?.(definition);
    }}><h3>Create a health observation schedule</h3>
      <label htmlFor="observation-interval">Interval in minutes</label><input id="observation-interval" type="number" required min={1} max={44640} step={1} value={minutes} disabled={blocked} onChange={event => setMinutes(Number(event.target.value))} />
      <label htmlFor="missed-observations">Missed observations</label><select id="missed-observations" value={missed} disabled={blocked} onChange={event => setMissed(event.target.value as ObserveHealthScheduleInput["missed"])}><option value="coalesce_latest">Use the most recent due occurrence</option><option value="skip">Skip missed occurrences</option></select>
      <label style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}><input style={{ width: "auto" }} type="checkbox" checked={windowEnabled} disabled={blocked} onChange={event => setWindowEnabled(event.target.checked)} /> Use a daily UTC maintenance window</label>
      {windowEnabled && <><label htmlFor="window-start">Window start (UTC)</label><input id="window-start" type="time" required value={clock(start)} disabled={blocked} onChange={event => setStart(minute(event.target.value))} />
        <label htmlFor="window-end">Window end (UTC)</label><input id="window-end" type="time" required value={clock(end)} disabled={blocked} onChange={event => setEnd(minute(event.target.value))} /></>}
      <button disabled={blocked || !create}>Create observation schedule</button>
    </form>}
    {showAlerts && <><h3>Active alerts</h3><ul>{alerts?.items.filter(row => row.incident.phase === "open").map(row => <li key={row.key}><strong>{row.key}</strong>{row.incident.phase === "open" && <p>{row.incident.summary} <span className="badge warning">{row.incident.severity}</span></p>}</li>)}</ul>
    {!alerts && <p>Alert data is unavailable.</p>}
    {alerts?.items.every(row => row.incident.phase !== "open") && <p>No active alerts on this page.</p>}
    {alerts?.next && <button onClick={moreAlerts}>Next alerts</button>}</>}
  </section>;
}
function clock(value: number): string { return `${Math.floor(value / 60).toString().padStart(2, "0")}:${(value % 60).toString().padStart(2, "0")}`; }
function scheduleReference(id: string): string { return id.length > 16 ? `${id.slice(0, 8)}…` : id; }
function minute(value: string): number { const [hours, minutes] = value.split(":").map(Number); return hours * 60 + minutes; }
function scheduleLabel(row: ScheduleView): string {
  switch (row.status) {
    case "awaiting_producer": return "Waiting for observations";
    case "scheduled": {
      switch (row.runtime?.phase) {
        case "checking": return "Checking containers";
        case "partial": return "Last container check completed";
        case "unavailable": return "Container checks unavailable";
        default: return "Automatic checks enabled";
      }
    }
    case "authority_suspended": return "Permission needs renewal";
    case "paused": return "Paused";
    case "blocked": return "Blocked";
  }
}

/** Integrator mounts this with the existing authenticated session and current permissions. */
export function AutomationPanel({ principal, grantRevision, csrf, canManage, canAcknowledge, expired }: {
  principal: string; grantRevision: number; csrf: string; canManage: boolean; canAcknowledge: boolean; expired: () => void;
}) {
  const owner = JSON.stringify([principal, grantRevision, csrf, canManage, canAcknowledge]);
  return <OwnedAutomationPanel key={owner} csrf={csrf} canManage={canManage} canAcknowledge={canAcknowledge} expired={expired} />;
}
// Dispose in the browser's unmount commit, before ready async continuations can
// run during the gap before passive cleanup. SSR owns no active requests.
const useOwnerEffect = typeof window === "undefined" ? useEffect : useLayoutEffect;
function OwnedAutomationPanel({ csrf, canManage, canAcknowledge, expired }: {
  csrf: string; canManage: boolean; canAcknowledge: boolean; expired: () => void;
}) {
  const expiry = useRef(expired); expiry.current = expired;
  const controller = useMemo(() => new AutomationController(() => expiry.current()), []);
  const state = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot);
  useOwnerEffect(() => {
    void controller.start();
    const refresh = () => { void controller.refresh(); };
    window.addEventListener("focus", refresh); window.addEventListener("online", refresh);
    return () => { window.removeEventListener("focus", refresh); window.removeEventListener("online", refresh); controller.dispose(); };
  }, [controller]);
  if (state.expired) return null;
  const changed = () => { void controller.refresh(); };
  const fresh = (kind: PageKind) => state[kind].page !== null && !state[kind].loading && !state[kind].stale && !state[kind].error;
  return <>
    <button onClick={changed} disabled={state.schedules.loading && state.alerts.loading && state.notifications.loading}>Refresh automation</button>
    <AutomationReadStatus state={state} />
    <AutomationView schedules={state.schedules.page} alerts={state.alerts.page} canManage={canManage} disabled={!fresh("schedules") || state.mutations.schedules.denied}
      busy={state.mutations.schedules.pending} error={state.mutations.schedules.error}
      create={definition => { if (canManage) void controller.mutate("schedules", signal => automationClient.create(definition, csrf, signal)); }}
      pause={row => { if (canManage) void controller.mutate("schedules", signal => automationClient.pause(row, csrf, signal)); }}
      moreSchedules={() => { void controller.next("schedules"); }} moreAlerts={() => { void controller.next("alerts"); }} />
    {state.schedules.after && <button disabled={state.schedules.loading} onClick={() => { void controller.first("schedules"); }}>First schedules</button>}
    {state.alerts.after && <button disabled={state.alerts.loading} onClick={() => { void controller.first("alerts"); }}>First alerts</button>}
    <NotificationsView value={state.notifications.page} canAcknowledge={canAcknowledge} disabled={!fresh("notifications") || state.mutations.notifications.denied}
      busy={state.mutations.notifications.pending} error={state.mutations.notifications.error}
      acknowledge={row => { if (canAcknowledge) void controller.mutate("notifications", signal => automationClient.acknowledge(row, csrf, signal)); }}
      more={() => { void controller.next("notifications"); }} />
    {state.notifications.after && <button disabled={state.notifications.loading} onClick={() => { void controller.first("notifications"); }}>First notifications</button>}
  </>;
}
export function AutomationReadStatus({ state, kinds = ["schedules", "alerts", "notifications"] }: { state: AutomationState; kinds?: readonly PageKind[] }) {
  return <div aria-label="Automation connection status" aria-live="polite">
    {kinds.map(kind => <div key={kind}>
      {state[kind].loading && <p role="status">Loading {kind}…</p>}
      {state[kind].stale && <p className="notice">Previously read {kind} may be out of date. Changes are paused until a successful refresh.</p>}
      {state[kind].error && <p className="error" role="alert">{kind}: {state[kind].error}</p>}
    </div>)}
  </div>;
}
