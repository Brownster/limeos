# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Join the test-only correction to unchanged candidate-11 production inputs."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-docker-startup-qualification'
BUILDERS = ROOT / '.cache/stack-installed-qualification'
BUILD = BUILDERS / 'build-11'
PACKAGES = BUILDERS / 'candidate-11'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
build = json.loads((BUILD / 'record.json').read_text())
packages = json.loads((PACKAGES / 'inputs.json').read_text())
assert build['exit_code'] == 0 and build['inputs_unchanged'] and build['container_removed']
assert build['source'] == packages['source']
changes = {name: {'built_sha256': old, 'fixture_sha256': sha(ROOT / name)}
           for name, old in build['before'].items() if sha(ROOT / name) != old}
assert set(changes) == {
    'tests/privileged_vm/p04_fixture_readiness.py',
    'tests/privileged_vm/p04_mounts_guest.py',
    'tests/reference/test_p04_fixture_readiness.py',
}
for name in build['before']:
    assert sha(ROOT / name) == hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=ROOT)).hexdigest(), name
for name, expected in packages['repository'].items():
    assert sha(PACKAGES / 'repository' / name) == expected, name
STATE.mkdir(exist_ok=False)
guest = STATE / 'guest-1'
guest.mkdir()
for source in sorted((ROOT / 'tests/privileged_vm').glob('*.py')):
    shutil.copyfile(source, guest / source.name)
census = ROOT / '.cache/a1-task-difference/guest/namespace_census.py'
shutil.copyfile(census, guest / census.name)
shutil.copyfile(BUILDERS / 'installed_fd_context_guest.py', guest / 'installed_guest.py')
shutil.copyfile(ROOT / 'tests/privileged_vm/run.py', STATE / 'run_1024.py')
shutil.copyfile(ROOT / 'tests/privileged_vm/current_authority_schema.py', STATE / 'current_authority_schema.py')
parent = json.loads((ROOT / '.cache/a1-fd-context-qualification/inputs-2.json').read_text())
guest_changes = [name for name, old in parent['guest'].items() if sha(guest / name) != old]
assert guest_changes == ['p04_fixture_readiness.py', 'p04_mounts_guest.py']
manifest = {
    'fixture_source': head, 'product_source': build['source'],
    'production_inputs_unchanged': True, 'test_only_changes_since_package_build': changes,
    'snapshotter_sha256': sha(Path(__file__)), 'package_inputs_sha256': sha(PACKAGES / 'inputs.json'),
    'schema_source_sha256': sha(ROOT / 'crates/persistence/src/lib.rs'),
    'packages': packages['packages'], 'binaries': packages['binaries'], 'ui': packages['ui'],
    'guest_memory_mib': 1024, 'runner_sha256': sha(STATE / 'run_1024.py'),
    'runner_support': {'current_authority_schema.py': sha(STATE / 'current_authority_schema.py')},
    'only_runner_change': 'none; exact committed canonical non-build 1024-MiB runner',
    'guest_changes_since_prior_run': guest_changes,
    'observational_census_sha256': sha(census), 'upgrade_qualification': False,
    'guest': {p.name: sha(p) for p in sorted(guest.glob('*.py'))},
}
(STATE / 'inputs-1.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'fixture_source': head, 'product_source': build['source'],
                  'test_only_changes': list(changes), 'guest_modules': len(manifest['guest'])}))
