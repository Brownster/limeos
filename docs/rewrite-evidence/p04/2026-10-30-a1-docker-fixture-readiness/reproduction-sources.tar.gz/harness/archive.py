# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Seal the startup correction and its distinct uncertain installed run."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-docker-startup-qualification'
BUILDERS = ROOT / '.cache/stack-installed-qualification'
ATTEMPTS = ROOT / '.cache/main-consolidation/attempts'
OUT = ROOT / 'docs/rewrite-evidence/p04/2026-10-30-a1-docker-fixture-readiness'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def archive(name, path):
    target = OUT / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
fixture = json.loads((STATE / 'inputs-1.json').read_text())
packages = json.loads((BUILDERS / 'candidate-11/inputs.json').read_text())
build = json.loads((BUILDERS / 'build-11/record.json').read_text())
assert fixture['fixture_source'] == head
assert fixture['product_source'] == build['source'] == packages['source']
assert sha(BUILDERS / 'candidate-11/inputs.json') == fixture['package_inputs_sha256']
current = {n: sha(ROOT / n) for n in build['before']}
changes = {n for n in current if current[n] != build['before'][n]}
assert changes == set(fixture['test_only_changes_since_package_build'])
for name, expected in current.items():
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=ROOT)).hexdigest() == expected, name
for name, expected in fixture['guest'].items():
    assert sha(STATE / 'guest-1' / name) == expected, name
assert sha(STATE / 'run_1024.py') == fixture['runner_sha256'] == sha(ROOT / 'tests/privileged_vm/run.py')
vm = ATTEMPTS / 'a1-docker-startup-vm-1'
record = json.loads((vm / 'record.json').read_text())
assert record['head'] == head and record['before'] == record['after'] == current
assert record['exit_code'] == 1 and record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
log = (vm / 'output.log').read_text()
failure = next(json.loads(l.partition(' ')[2]) for l in log.splitlines() if l.startswith('A1_FAILURE '))
assert failure['stage'] == 'await_terminal_receipt' and failure['job']['state'] == 'needs_intervention'
assert failure['fixture_sha256'] == fixture['guest']['p04_mounts_guest.py']
assert failure['schema_source_sha256'] == fixture['schema_source_sha256'] and failure['authority_schema'] == 12
for name, expected in failure['binary_sha256'].items():
    assert expected == packages['binaries'][name]['sha256'], name
assert failure['package_version'] == packages['version']
assert 'A1_ADMISSION_DIAGNOSTIC_RECORDS=0' in log
startup = failure['fixture_docker_startup']
assert startup['quiet_seconds'] >= 3 and startup['elapsed_seconds'] < 15
assert not startup['service_stopped_or_modified']
assert len(failure['pre_effect']['cases']) == 3 and all(c['no_effect'] for c in failure['pre_effect']['cases'])
assert not (ROOT / '.cache/main-consolidation/tmp/limeos-p01-vm-c62_xxni').exists()
native = json.loads((ATTEMPTS / 'a1-docker-startup-reference-3/record.json').read_text())
assert native['before'] == native['after'] == current and native['inputs_unchanged']
assert native['exit_code'] == 0 and native['ended'] and not native['guard_triggered']
assert 'Ran 91 tests' in (ATTEMPTS / 'a1-docker-startup-reference-3/output.log').read_text()
OUT.mkdir(exist_ok=False)
for label in ('a1-docker-startup-reference-1', 'a1-docker-startup-reference-2', 'a1-docker-startup-reference-3', 'a1-docker-startup-vm-1'):
    for name in ('record.json', 'output.log'):
        archive('checks/' + label + '-' + name, ATTEMPTS / label / name)
for name in ('inputs-1.json', 'admission-1.json', 'guard-launch-1.json', 'guard-console-1.log',
             'result-1-vm-failure.txt', 'result-1-startup-console.txt', 'local-checks.json',
             'local-check-1.log', 'local-check-2.log', 'local-check-3.log', 'local-check-4.log'):
    archive(name, STATE / name)
archive('package-inputs.json', BUILDERS / 'candidate-11/inputs.json')
archive('build-record.json', BUILDERS / 'build-11/record.json')
files = {'guest/' + p.name: p for p in sorted((STATE / 'guest-1').glob('*.py'))}
files.update({'runner/' + n: STATE / n for n in ('run_1024.py', 'current_authority_schema.py')})
files.update({'harness/' + n: BUILDERS / n for n in ('prepare_docker_startup_guest.py', 'launch_docker_startup_vm.py', 'detached_guard.py')})
files.update({'harness/guard.py': ROOT / '.cache/main-consolidation/guard.py', 'harness/archive.py': Path(__file__),
              'reference/test_p04_fixture_readiness.py': ROOT / 'tests/reference/test_p04_fixture_readiness.py'})
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        tar.addfile(info, io.BytesIO(data))
(OUT / 'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
summary = {'fixture_source': head, 'product_source': build['source'], 'recorded_inputs_match_fixture_commit': len(current),
           'test_only_changes_since_package_build': fixture['test_only_changes_since_package_build'],
           'native_reference_tests': 91, 'native_precommit_record_head': native['head'],
           'native_recorded_inputs_match_fixture_commit': True, 'docker_startup': startup,
           'vm': {k: record[k] for k in ('started', 'ended', 'exit_code', 'minimum_available_bytes', 'inputs_unchanged', 'guard_triggered')},
           'stage': failure['stage'], 'action': failure['action'], 'job_state': failure['job']['state'],
           'root_receipt_and_exact_effect_stage_recorded': False, 'admission_diagnostic_records': 0,
           'vm_scratch_removed': True, 'a1_accepted': False, 'installed_ui_qualification': False,
           'operation_retried': False, 'production_pi_accessed': False}
(OUT / 'source-match.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'fixture_source': head, 'product_source': build['source'], 'native_tests': 91,
                  'startup_read_passes': startup['read_passes'], 'stage': failure['stage'], 'a1_accepted': False}))
