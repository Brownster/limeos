#!/usr/bin/env -S uv run --offline
# /// script
# dependencies = []
# ///
"""Package checked quickstart preparation evidence without rerunning suites."""

import gzip
import hashlib
import json
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/quickstart"
output = root / "docs/rewrite-evidence/p04/2026-10-16-media-quickstart"
output.mkdir(parents=True, exist_ok=True)
source = (cache / "source.txt").read_text().strip()
assert source == "684aa81a6a5a9117d34c07abcd057974e30ccfb1"
assert not (cache / "source-status.log").read_text().strip()
assert (
    "186 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
    in (cache / "test-reviewed.log").read_text()
)
assert "0 passed; 1 failed" in (cache / "capacity-red.log").read_text()
assert "Finished" in (cache / "clippy.log").read_text()
assert not (cache / "rustfmt.log").read_text()
assert "All checks passed!" in (cache / "ruff.log").read_text()
assert (cache / "harness-check.log").read_text().count(": OK") == 3


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


paths = sorted(set((cache / "input-paths.txt").read_text().splitlines()))
(output / "inputs.sha256").write_text(
    "".join(f"{digest(root / name)}  {name}\n" for name in paths)
)
reference = Path("/home/marc/Documents/github/pi-health")
reference_paths = [
    "media_quickstart_service.py",
    "tests/test_media_quickstart_service.py",
    "media_layout.py",
    "tests/test_media_layout.py",
    "media_layout_service.py",
    "media_profile_service.py",
    "tests/test_media_profile_service.py",
    "storage_compatibility.py",
    "catalog/bundles/media-server.yaml",
]
(output / "frozen-inputs.sha256").write_text(
    "".join(
        f"{digest(reference / name)}  {reference / name}\n" for name in reference_paths
    )
)
files = {
    "test.log": "test-reviewed.log",
    "test-initial.log": "test-initial.log",
    "capacity-red.log": "capacity-red.log",
    "capacity-red.rs": "capacity-red.rs",
    "capacity-tests-red.rs": "capacity-tests-red.rs",
    "clippy.log": "clippy.log",
    "rustfmt.log": "rustfmt.log",
    "prepare.log": "prepare.log",
    "cargo-metadata.json": "cargo-metadata.json",
    "rustc-version.log": "rustc-version.log",
    "cargo-version.log": "cargo-version.log",
    "source-status.log": "source-status.log",
    "package-evidence.py": "package-evidence.py",
    "ruff.log": "ruff.log",
    "ruff-format.log": "ruff-format.log",
    "harness-before.sha256": "harness-before.sha256",
    "harness-check.log": "harness-check.log",
}
for name, original in files.items():
    (output / f"{name}.gz").write_bytes(
        gzip.compress((cache / original).read_bytes(), mtime=0)
    )
harness = output / "harness"
harness.mkdir(exist_ok=True)
for name in ["Cargo.toml", "Cargo.lock", "lib.rs"]:
    (harness / name).write_bytes((root / ".cache/quickstart-leaf" / name).read_bytes())
metadata = {
    "source": source,
    "base": "f4514d4",
    "product_committed_after_checks_without_intervening_changes": True,
    "cases": {
        "quickstart": 23,
        "indexer_apps": 18,
        "download_clients": 18,
        "media_settings": 18,
        "local_config": 24,
        "catalog_and_namespace": 37,
        "media_library": 21,
        "activity": 15,
        "discovery": 12,
    },
    "total": 186,
    "suite": "domain only",
    "input_count": len(paths),
    "bounds": {
        "declared_services": 16,
        "installation_mappings": 16,
        "name_bytes": 64,
        "path_utf8_bytes": 512,
        "timezone_bytes": 64,
        "generated_directories": 16,
        "selected_input_text_bytes": 32768,
        "streamed_report_bytes": 65536,
        "inclusive_max_age_seconds": 90,
        "effective_catalog_services": 16,
    },
    "profile_draft_version": 2,
    "frozen_source": "80593b29443ea9b81eb60ed4e5c3c3ac7a236204",
    "frozen_input_count": len(reference_paths),
    "commands": [
        "uv run --offline --no-project tests/fixtures/deployment/quickstart/check-leaf.py",
        "cargo test --offline --locked --manifest-path .cache/quickstart-leaf/Cargo.toml",
        "cargo clippy --offline --locked --manifest-path .cache/quickstart-leaf/Cargo.toml --all-targets -- -D warnings",
        "rustfmt --edition 2024 --check crates/domain/src/deployment/quickstart.rs crates/domain/src/deployment/quickstart/tests.rs crates/domain/src/deployment/mod.rs",
        "uv run --offline --no-project --with ruff==0.17.0 ruff check tests/fixtures/deployment/quickstart/check-leaf.py",
    ],
    "environment": {
        "CARGO_BUILD_JOBS": "1",
        "CARGO_INCREMENTAL": "0",
        "RUST_TEST_THREADS": "2",
        "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
    },
    "limits": "Pure local domain preparation only; workflow barriers are declarations, with no event consumer, receipt authority, durable state, filesystem/Compose effect, profile save, API/UI or installed acceptance",
}
assert sum(metadata["cases"].values()) == metadata["total"]
(output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
artifacts = sorted(
    path
    for path in output.rglob("*")
    if path.is_file() and path.name != "artifacts.sha256"
)
(output / "artifacts.sha256").write_text(
    "".join(f"{digest(path)}  {path.relative_to(output)}\n" for path in artifacts)
)
print(
    json.dumps(
        {
            "source": source,
            "inputs": len(paths),
            "artifacts": len(artifacts),
            "tests": 186,
        }
    )
)
