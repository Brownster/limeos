# /// script
# dependencies = []
# ///
"""Prepare packaging of this candidate, preserving older build recipes."""
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
builders = root / '.cache/stack-installed-qualification'
text = (builders / 'prepare_packages_11.py').read_text()
text = text.replace('import subprocess\n', 'import subprocess\nimport sys\n')
text = text.replace('build-11', 'build-12').replace('candidate-11', 'candidate-12').replace('signing-11', 'signing-12')
text = text.replace('0.4.11+fdcontext.1', '0.4.12+gateabort.1')
text = text.replace("ROOT / '.cache/main-consolidation/attempts/a1-fd-context-ui-build-1/record.json'", "ROOT / '.cache/main-consolidation/attempts/a1-installed-recovery-frontend-1/record.json'")
text = text.replace("['python3', 'packaging/build.py'", "[sys.executable, 'packaging/build.py'")
text = text.replace('LimeOS disposable FD context A1 fixture 2026-10-30', 'LimeOS disposable gated refusal fixture 2026-11-04')
# The source-bound UI phase used the same product map; sign only that exact UI.
needle = "assert ui_record['head'] == record['source']\n"
assert needle in text
text = text.replace(needle, needle + "assert ui_record['before'] == record['before']\n")
(builders / 'prepare_packages_12.py').write_text(text)
