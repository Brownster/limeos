# /// script
# dependencies = []
# ///
"""Prepare a fresh immutable Debian build without modifying product source."""
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-installed-recovery-qualification'
builders = root / '.cache/stack-installed-qualification'
assert not (builders / 'build-12').exists()
assert not (builders / 'candidate-12').exists()
inside = (builders / 'build_inside.py').read_text()
inside = inside.replace("assert records['limeos-stack-read-worker']['bytes'] <= 8 * 1024**2", "assert records['limeos-stack-read-worker']['bytes'] <= 8 * 1024**2\nassert records['limeos-executor']['bytes'] <= 8 * 1024**2")
(builders / 'build_inside_12.py').write_text(inside)
build = (builders / 'build_candidate_11.py').read_text().replace('build-11', 'build-12').replace('build_inside.py', 'build_inside_12.py')
(builders / 'build_candidate_12.py').write_text(build)
prior = root / '.cache/a1-gated-refusal-qualification'
launch = (prior / 'launch_check.py').read_text().replace('a1-gated-refusal', 'a1-installed-recovery')
(state / 'launch_check.py').write_text(launch)
for name in ['check_frontend.py', 'check_sanity.py']:
    (state / name).write_text((prior / name).read_text().replace('a1-gated-refusal', 'a1-installed-recovery'))
