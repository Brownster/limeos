# /// script
# dependencies = []
# ///
"""Freeze the current committed guest modules against freshly built packages."""
import hashlib
import ast
import json
from pathlib import Path
import shutil
import subprocess

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-installed-recovery-qualification'
builders = root / '.cache/stack-installed-qualification'
build = json.loads((builders / 'build-12/record.json').read_text())
packages = json.loads((builders / 'candidate-12/inputs.json').read_text())
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == build['source'] == packages['source']
assert build['exit_code'] == 0 and build['inputs_unchanged'] and build['container_removed']
assert build['stop_reason'] is None and not build['oom_killed']
for name, expected in build['before'].items():
    assert sha(root / name) == expected, name
guest = state / 'guest-1'
guest.mkdir(exist_ok=False)
for path in sorted((root / 'tests/privileged_vm').glob('*.py')):
    shutil.copyfile(path, guest / path.name)
census = root / '.cache/a1-task-difference/guest/namespace_census.py'
shutil.copyfile(census, guest / census.name)
wrapper = (root / '.cache/a1-api-session-qualification/guest-1/installed_guest.py').read_text()
assert wrapper.count('0.4.11+fdcontext.1') == 1
wrapper = wrapper.replace('0.4.11+fdcontext.1', packages['version'])
needle = 'try:\n    approved.main('
assert wrapper.count(needle) == 1
supplement = '''# Preserve the same single post-failure read separately if the main packet
# reaches its aggregate stdout bound. No new read or execution authority.
original_execution_snapshot = mounts.execution_failure_snapshot
def execution_snapshot(action):
    value = original_execution_snapshot(action)
    extra = dict(value)
    encoded = json.dumps(extra, sort_keys=True, separators=(',', ':'))
    if len(encoded.encode()) > 128 * 1024:
        extra.pop('target_mount_rows', None)
        extra['target_mount_rows'] = {'available': False, 'reason': 'supplemental stdout bound; original result retains the read'}
        encoded = json.dumps(extra, sort_keys=True, separators=(',', ':'))
    if len(encoded.encode()) <= 128 * 1024:
        print('A1_EXECUTION_OBSERVATION ' + encoded, flush=True)
    else:
        print('A1_EXECUTION_OBSERVATION ' + json.dumps({'available': False, 'reason': 'supplemental stdout bound', 'action': action}), flush=True)
    return value
mounts.execution_failure_snapshot = execution_snapshot

'''
wrapper = wrapper.replace(needle, supplement + needle)
ast.parse(wrapper)
(guest / 'installed_guest.py').write_text(wrapper)
for name in ['run.py', 'current_authority_schema.py']:
    shutil.copyfile(root / 'tests/privileged_vm' / name, state / ('run_1024.py' if name == 'run.py' else name))
manifest = {'fixture_source': head, 'product_source': packages['source'],
    'production_inputs_unchanged': True, 'test_only_changes_since_package_build': {},
    'product_input_count': len(build['before']), 'package_inputs_sha256': sha(builders / 'candidate-12/inputs.json'),
    'build_record_sha256': sha(builders / 'build-12/record.json'),
    'schema_source_sha256': sha(root / 'crates/persistence/src/lib.rs'),
    'packages': packages['packages'], 'binaries': packages['binaries'], 'ui': packages['ui'],
    'guest_memory_mib': 1024, 'runner_sha256': sha(state / 'run_1024.py'),
    'runner_support': {'current_authority_schema.py': sha(state / 'current_authority_schema.py')},
    'only_runner_change': 'none; exact committed canonical non-build 1024-MiB runner',
    'observational_census_sha256': sha(census), 'upgrade_qualification': False,
    'wrapper_addition': 'Same single post-failure execution read also printed independently within 128 KiB; original result and all assertions unchanged',
    'scope': 'One fresh disposable AMD64 mount qualification; no installed ARM64/Pi or upgrade/return acceptance',
    'guest': {p.name: sha(p) for p in sorted(guest.glob('*.py'))}}
(state / 'inputs-1.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'source': head, 'inputs': len(build['before']), 'guest_modules': len(manifest['guest']), 'version': packages['version']}))
