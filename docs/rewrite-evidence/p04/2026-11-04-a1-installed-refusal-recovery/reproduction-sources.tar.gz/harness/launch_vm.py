# /// script
# dependencies = []
# ///
"""Revalidate frozen bytes, then start one guarded disposable guest."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-installed-recovery-qualification'
builders = root / '.cache/stack-installed-qualification'
manifest = json.loads((state / 'inputs-1.json').read_text())
packages = json.loads((builders / 'candidate-12/inputs.json').read_text())
build = json.loads((builders / 'build-12/record.json').read_text())
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

label = 'a1-installed-recovery-vm-1'
assert not (root / '.cache/main-consolidation/attempts' / label).exists()
assert not (state / 'guard-launch-1.json').exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == manifest['fixture_source'] == packages['source'] == build['source']
assert sha(builders / 'candidate-12/inputs.json') == manifest['package_inputs_sha256']
assert sha(builders / 'build-12/record.json') == manifest['build_record_sha256']
assert build['exit_code'] == 0 and build['inputs_unchanged'] and build['container_removed']
for name, expected in build['before'].items(): assert sha(root / name) == expected, name
for name, expected in manifest['guest'].items(): assert sha(state / 'guest-1' / name) == expected, name
for name, expected in manifest['runner_support'].items(): assert sha(state / name) == expected, name
assert sha(state / 'run_1024.py') == manifest['runner_sha256'] == sha(root / 'tests/privileged_vm/run.py')
assert sha(root / 'crates/persistence/src/lib.rs') == manifest['schema_source_sha256']
for name, expected in packages['repository'].items(): assert sha(builders / 'candidate-12/repository' / name) == expected, name
busy = [line.strip() for line in subprocess.check_output(['ps', '-eo', 'comm'], text=True).splitlines() if line.strip() in ('cargo', 'rustc', 'rustdoc')]
assert not busy
now = datetime.datetime.now(datetime.timezone.utc)
assert packages['signing_key_expires'] > int(now.timestamp()) + 3600
available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
minimum = 3 * 1024**3 + 1536 * 1024**2
admission = {'at': now.isoformat(), 'available_bytes': available, 'start_threshold_bytes': minimum,
    'runtime_stop_floor_bytes': 3 * 1024**3, 'guest_memory_mib': 1024,
    'disk_free_bytes': shutil.disk_usage(root).free, 'admitted': available >= minimum and shutil.disk_usage(root).free >= 8 * 1024**3}
(state / 'admission-1.json').write_text(json.dumps(admission, indent=2) + '\n')
print(json.dumps(admission), flush=True)
if not admission['admitted']: raise SystemExit(75)
wrapper = builders / 'detached_guard.py'
command = [sys.executable, str(wrapper), label, sys.executable, str(state / 'run_1024.py'),
    '--image', str(root / '.cache/a1-namespace-review/debian-12-genericcloud-amd64.qcow2'),
    '--checksums', str(root / '.cache/a1-namespace-review/SHA512SUMS'),
    '--repository', str(builders / 'candidate-12/repository'),
    '--guest-script', str(state / 'guest-1/installed_guest.py'), '--storage-disks', '--output', str(state / 'result-1.json')]
with (state / 'guard-console-1.log').open('xb') as log:
    child = subprocess.Popen(command, cwd=root, start_new_session=True, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
raw = (Path('/proc') / str(child.pid) / 'stat').read_text()
launch = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': child.pid,
    'start_ticks': int(raw[raw.rindex(')') + 1:].split()[19]), 'session': os.getsid(child.pid),
    'process_group': os.getpgid(child.pid), 'command': command, 'label': label,
    'launcher_sha256': sha(Path(__file__)), 'wrapper_sha256': sha(wrapper),
    'guard_sha256': sha(root / '.cache/main-consolidation/guard.py')}
assert launch['session'] == launch['process_group'] == child.pid
(state / 'guard-launch-1.json').write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps({'pid': child.pid, 'label': label}), flush=True)
