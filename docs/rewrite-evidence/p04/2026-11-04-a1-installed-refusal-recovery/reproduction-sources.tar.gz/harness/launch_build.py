# /// script
# dependencies = []
# ///
"""Launch one native self-guarded builder and retain its original identity."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-installed-recovery-qualification'
builder = root / '.cache/stack-installed-qualification/build_candidate_12.py'
assert not (state / 'build-launch.json').exists()
assert not (builder.parent / 'build-12').exists()
with (state / 'build-console.log').open('xb') as log:
    child = subprocess.Popen([sys.executable, str(builder)], cwd=root, start_new_session=True,
        stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
raw = (Path('/proc') / str(child.pid) / 'stat').read_text()
record = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': child.pid,
    'start_ticks': int(raw[raw.rindex(')') + 1:].split()[19]), 'session': os.getsid(child.pid),
    'process_group': os.getpgid(child.pid), 'builder_sha256': hashlib.sha256(builder.read_bytes()).hexdigest(),
    'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()}
assert record['session'] == record['process_group'] == child.pid
(state / 'build-launch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
