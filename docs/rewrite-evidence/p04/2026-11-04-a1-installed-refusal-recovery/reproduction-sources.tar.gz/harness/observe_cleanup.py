# /// script
# dependencies = []
# ///
"""Observe original owned identities and container/VM cleanup without stopping anything."""
import datetime
import json
from pathlib import Path
import subprocess

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-installed-recovery-qualification'
builders = root / '.cache/stack-installed-qualification'
attempts = root / '.cache/main-consolidation/attempts'
record = json.loads((attempts / 'a1-installed-recovery-vm-1/record.json').read_text())
assert record.get('ended') and record.get('exit_code') is not None
assert not (state / 'cleanup.json').exists()
originals = []
for name in ('build-launch.json', 'frontend-1-launch.json', 'package-1-launch.json', 'guard-launch-1.json'):
    value = json.loads((state / name).read_text())
    originals.append({'from': name, 'pid': value['pid'], 'start_ticks': value['start_ticks']})
for phase in ('frontend', 'package', 'vm'):
    name = 'a1-installed-recovery-' + phase + '-1'
    value = json.loads((attempts / name / 'record.json').read_text())
    assert value.get('ended')
    originals.append({'from': name, 'pid': value['pid']})
observed = json.loads((state / 'vm-process-observation-1.json').read_text())
for kind in ('runner', 'qemu'):
    values = observed[kind] if kind == 'qemu' else [observed[kind]]
    for value in values:
        originals.append({'from': kind + ' native observation', 'pid': value['pid'], 'start_ticks': value['start_ticks']})
for value in originals:
    proc = Path('/proc') / str(value['pid'])
    try:
        raw = (proc / 'stat').read_text()
        fields = raw[raw.rindex(')') + 1:].split()
        value.update(observed_start_ticks=int(fields[19]), state=fields[0])
        value['original_absent'] = 'start_ticks' in value and value['start_ticks'] != value['observed_start_ticks']
    except FileNotFoundError:
        value.update(proc_absent=True, original_absent=True)
assert all(value['original_absent'] for value in originals), originals
scratch = set()
for value in observed['qemu']:
    for argument in value['command']:
        if argument.startswith('file=' + str(root / '.cache/main-consolidation/tmp/limeos-p01-vm-')):
            scratch.add(str(Path(argument.removeprefix('file=').split(',')[0]).parent))
assert len(scratch) == 1
assert all(not Path(name).exists() for name in scratch)
build = json.loads((builders / 'build-12/record.json').read_text())
container = subprocess.run(['docker', 'inspect', build['container']], text=True, capture_output=True)
assert container.returncode != 0 and 'no such object' in container.stderr.casefold()
packages = json.loads((builders / 'candidate-12/inputs.json').read_text())
ids = subprocess.check_output(['docker', 'ps', '-a', '--no-trunc', '--filter', 'ancestor=' + packages['repository_tool_image'], '--format', '{{.ID}}'], text=True).split()
matching_signers = []
for container_id in ids:
    value = json.loads(subprocess.check_output(['docker', 'inspect', container_id], text=True))[0]
    if 'GNUPGHOME=/build/.cache/stack-installed-qualification/signing-12' in value['Config'].get('Env', []):
        matching_signers.append({'id': container_id, 'state': value['State']})
assert not matching_signers
value = {'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'processes': originals, 'all_recorded_original_processes_absent': True,
         'vm_scratch': [{'path': name, 'absent': True} for name in sorted(scratch)],
         'build_container': {'id': build['container'], 'absent': True, 'inspection_stderr': container.stderr},
         'matching_disposable_signer_containers': matching_signers,
         'observation_only': True, 'unrelated_processes_stopped': False}
with (state / 'cleanup.json').open('x') as stream:
    json.dump(value, stream, indent=2)
    stream.write('\n')
print(json.dumps({'all_recorded_original_processes_absent': True, 'recorded_identities': len(originals),
                  'unique_pids': len({value['pid'] for value in originals}), 'vm_scratch_removed': True,
                  'build_container_absent': True, 'matching_signer_containers': 0}))
