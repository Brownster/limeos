# /// script
# dependencies = []
# ///
"""Extract bounded structured markers from the original completed VM output."""
import json
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-installed-recovery-qualification'
attempt = root / '.cache/main-consolidation/attempts/a1-installed-recovery-vm-1'
record = json.loads((attempt / 'record.json').read_text())
assert record.get('ended')
values = {}
for line in (attempt / 'output.log').read_text().splitlines():
    for prefix in ('A1_FAILURE', 'A1_EXECUTION_OBSERVATION', 'A1_ADMISSION_DIAGNOSTIC'):
        if line.startswith(prefix + ' '):
            values.setdefault(prefix, []).append(json.loads(line.partition(' ')[2]))
with (state / 'structured-outcome.json').open('x') as stream:
    json.dump(values, stream, indent=2)
    stream.write('\n')
for prefix, entries in values.items():
    print(prefix, 'count=', len(entries))
    for entry in entries:
        print(json.dumps({'keys': list(entry), **{key: entry[key] for key in
            ('stage', 'action', 'job', 'error', 'failure', 'package_version', 'authority_schema',
             'last_api_session', 'event', 'phase', 'added', 'removed', 'owner_before', 'fd') if key in entry}}, indent=2))
