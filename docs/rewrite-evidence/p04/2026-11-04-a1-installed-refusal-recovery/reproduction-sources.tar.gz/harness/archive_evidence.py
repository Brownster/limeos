# /// script
# dependencies = []
# ///
"""Archive a completed source-bound installed attempt, excluding runtime secrets/images."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-installed-recovery-qualification'
builders = root / '.cache/stack-installed-qualification'
attempts = root / '.cache/main-consolidation/attempts'
out = root / 'docs/rewrite-evidence/p04/2026-11-04-a1-installed-refusal-recovery'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
manifest = read(state / 'inputs-1.json')
build = read(builders / 'build-12/record.json')
packages = read(builders / 'candidate-12/inputs.json')
assert head == manifest['fixture_source'] == manifest['product_source'] == build['source'] == packages['source']
assert sha(builders / 'build-12/record.json') == manifest['build_record_sha256']
assert sha(builders / 'candidate-12/inputs.json') == manifest['package_inputs_sha256']
assert sha(builders / 'prepare_packages_12.py') == packages['producer_sha256']
assert sha(builders / 'build_candidate_12.py') == build['builder_sha256']
assert sha(builders / 'build_inside_12.py') == build['inside_sha256']
assert build['exit_code'] == 0 and build['inputs_unchanged'] and build['container_removed']
assert not build['oom_killed'] and build['stop_reason'] is None
current = {name: sha(root / name) for name in build['before']}
assert current == build['before'] == build['after']
for name, expected in current.items():
    committed = subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=root)
    assert hashlib.sha256(committed).hexdigest() == expected, name
for name, expected in manifest['guest'].items():
    assert sha(state / 'guest-1' / name) == expected, name
assert sha(state / 'run_1024.py') == manifest['runner_sha256'] == sha(root / 'tests/privileged_vm/run.py')
assert sha(root / 'crates/persistence/src/lib.rs') == manifest['schema_source_sha256']
for name, expected in manifest['runner_support'].items():
    assert sha(state / name) == expected, name
for name, facts in packages['binaries'].items():
    assert sha(builders / 'build-12/binaries' / name) == facts['sha256'], name
    assert (builders / 'build-12/binaries' / name).stat().st_size == facts['bytes']
for name, expected in packages['ui'].items():
    assert sha(root / name) == expected, name
for name, expected in packages['repository'].items():
    assert sha(builders / 'candidate-12/repository' / name) == expected, name
records = {}
for phase in ('frontend', 'package', 'vm'):
    label = 'a1-installed-recovery-' + phase + '-1'
    record = read(attempts / label / 'record.json')
    assert record['head'] == head and record['before'] == record['after'] == current
    assert record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
    assert record['guard_sha256'] == '380a78ebd9dbb3902a97bebbcdb164df1e6bfc4c069b56a45092af6eb26813d6'
    assert phase == 'vm' or record['exit_code'] == 0
    records[phase] = record
cleanup = read(state / 'cleanup.json')
assert cleanup['all_recorded_original_processes_absent']
assert all(value['absent'] for value in cleanup['vm_scratch'])
assert cleanup['build_container']['absent'] and not cleanup['matching_disposable_signer_containers']
log = (attempts / 'a1-installed-recovery-vm-1/output.log').read_text()
markers = {}
for prefix in ('A1_FAILURE', 'A1_EXECUTION_OBSERVATION'):
    values = [json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith(prefix + ' ')]
    assert len(values) <= 1
    if values:
        markers[prefix] = values[0]
diagnostics = [json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith('A1_ADMISSION_DIAGNOSTIC ')]
failure = markers.get('A1_FAILURE')
if records['vm']['exit_code']:
    assert failure is not None
    assert failure['fixture_sha256'] == manifest['guest']['p04_mounts_guest.py']
    assert failure['schema_source_sha256'] == manifest['schema_source_sha256']
    assert failure['package_version'] == packages['version']
    for name, expected in failure['binary_sha256'].items():
        assert expected == packages['binaries'][name]['sha256'], name
    accepted = False
else:
    result = read(state / 'result-1.json')
    assert failure is None
    accepted = True
out.mkdir(exist_ok=False)

def archive(name, path):
    target = out / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

for phase in records:
    label = 'a1-installed-recovery-' + phase + '-1'
    for name in ('record.json', 'output.log'):
        archive('checks/' + label + '-' + name, attempts / label / name)
for path in sorted((builders / 'build-12').iterdir()):
    if path.is_file():
        archive('build/' + path.name, path)
archive('package-inputs.json', builders / 'candidate-12/inputs.json')
for name in ('dists/stable/InRelease', 'dists/stable/Release', 'dists/stable/Release.gpg',
             'dists/stable/main/binary-amd64/Packages', 'dists/stable/main/binary-arm64/Packages',
             'limeos-archive-keyring.gpg'):
    archive('repository/' + name, builders / 'candidate-12/repository' / name)
for path in sorted(state.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.log', '.txt'):
        archive('observations/' + path.name, path)
for prefix, value in markers.items():
    (out / (prefix.lower().replace('a1_', '') + '.json')).write_text(json.dumps(value, indent=2) + '\n')
(out / 'admission-diagnostics.json').write_text(json.dumps(diagnostics, indent=2) + '\n')
sources = {'guest/' + p.name: p for p in sorted((state / 'guest-1').glob('*.py'))}
sources.update({'harness/' + p.name: p for p in sorted(state.glob('*.py'))})
sources.update({'harness/' + name: builders / name for name in
                ('build_candidate_12.py', 'build_inside_12.py', 'prepare_packages_12.py', 'detached_guard.py')})
sources['harness/guard.py'] = root / '.cache/main-consolidation/guard.py'
sources.update({'packaging/' + name: root / 'packaging' / name for name in ('build.py', 'repository.sh')})
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for name, path in sorted(sources.items()):
        data = path.read_bytes()
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
        tar.addfile(entry, io.BytesIO(data))
(out / 'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
summary = {'source': head, 'product_input_count': len(current), 'all_inputs_match_committed_source': True,
           'no_test_only_source_differences': True, 'package_version': packages['version'],
           'build': {name: build[name] for name in ('image', 'started', 'ended', 'exit_code', 'inputs_unchanged',
                    'minimum_available_bytes', 'minimum_disk_free_bytes', 'stop_reason', 'oom_killed', 'container_removed')},
           'binaries': packages['binaries'], 'ui': packages['ui'], 'packages': packages['packages'],
           'checks': {phase: {name: record[name] for name in ('started', 'ended', 'exit_code',
                    'inputs_unchanged', 'minimum_available_bytes', 'guard_triggered')} for phase, record in records.items()},
           'frontend_tests': 244, 'guest_memory_mib': 1024,
           'guest_module_count': len(manifest['guest']), 'canonical_runner_unchanged': True,
           'stage': failure.get('stage') if failure else 'complete',
           'failure_keys': sorted(failure) if failure else [],
           'admission_diagnostic_count': len(diagnostics),
           'separate_execution_observation': 'A1_EXECUTION_OBSERVATION' in markers,
           'vm_pass_lines': [line for line in log.splitlines() if line.startswith('PASS ')],
           'a1_accepted': accepted, 'installed_ui_qualified': False,
           'upgrade_return_qualified': False, 'arm64_qualified': False, 'pi_accessed': False,
           'uncertain_action_retried_or_repaired': False,
           'all_recorded_original_processes_absent': True, 'vm_scratch_removed': True,
           'private_keys_packages_binaries_and_disks_archived': False}
(out / 'source-match.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'source': head, 'inputs': len(current), 'stage': summary['stage'],
                  'vm_exit_code': records['vm']['exit_code'], 'a1_accepted': accepted,
                  'pass_lines': len(summary['vm_pass_lines']), 'markers': list(markers)}))
