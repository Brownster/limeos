"""Current committed A1 fixture; extra witnesses are observations only."""
import json
import subprocess

import p04_approved_guest as approved
import p04_mounts_guest as mounts
from namespace_census import snapshot

witness = {}
original_pre = mounts.pre_effect_refusals
original_after = mounts._after_refusal_facts

def pre_effect(*args):
    witness['before'] = snapshot()
    try:
        return original_pre(*args)
    finally:
        witness['after'] = snapshot()

def diagnostics(service):
    facts = original_after(service)
    facts['pre_effect_task_witness'] = witness
    return facts

mounts.pre_effect_refusals = pre_effect
mounts._after_refusal_facts = diagnostics
# Preserve the same single post-failure read separately if the main packet
# reaches its aggregate stdout bound. No new read or execution authority.
original_execution_snapshot = mounts.execution_failure_snapshot
def execution_snapshot(action):
    value = original_execution_snapshot(action)
    extra = dict(value)
    encoded = json.dumps(extra, sort_keys=True, separators=(',', ':'))
    if len(encoded.encode()) > 128 * 1024:
        extra.pop('target_mount_rows', None)
        extra['target_mount_rows'] = {'available': False, 'reason': 'supplemental stdout bound; original result retains the read'}
        encoded = json.dumps(extra, sort_keys=True, separators=(',', ':'))
    if len(encoded.encode()) <= 128 * 1024:
        print('A1_EXECUTION_OBSERVATION ' + encoded, flush=True)
    else:
        print('A1_EXECUTION_OBSERVATION ' + json.dumps({'available': False, 'reason': 'supplemental stdout bound', 'action': action}), flush=True)
    return value
mounts.execution_failure_snapshot = execution_snapshot

try:
    approved.main(package_version='0.4.12+gateabort.1', qualify_upgrade=False)
except Exception:
    result = subprocess.run(['journalctl', '-u', mounts.UNIT, '--no-pager', '-n', '80', '-o', 'cat'], text=True, capture_output=True, timeout=5)
    count = 0
    for line in result.stdout[-65536:].splitlines():
        if len(line.encode()) >= 2048:
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if value.get('event') in ('storage_mount_consumer_tasks_changed', 'storage_mount_consumer_collection_changed', 'storage_mount_capacity_refused'):
            print('A1_ADMISSION_DIAGNOSTIC ' + json.dumps(value), flush=True)
            count += 1
            if count == 8:
                break
    print('A1_ADMISSION_DIAGNOSTIC_RECORDS=' + str(count), flush=True)
    raise
