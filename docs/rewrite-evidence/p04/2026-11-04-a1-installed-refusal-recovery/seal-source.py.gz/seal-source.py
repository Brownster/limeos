# /// script
# dependencies = []
# ///
"""Check this completed packet, then seal all its public evidence bytes."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-installed-recovery-qualification'
out = root / 'docs/rewrite-evidence/p04/2026-11-04-a1-installed-refusal-recovery'
assert not (out / 'SHA256SUMS').exists()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

build = json.loads((root / '.cache/stack-installed-qualification/build-12/record.json').read_text())
current = {name: sha(root / name) for name in build['before']}
assert current == build['before'] == build['after']
summary = json.loads((out / 'source-match.json').read_text())
failure = json.loads((out / 'failure.json').read_text())
diagnostics = json.loads((out / 'admission-diagnostics.json').read_text())
assert summary['source'] == build['source']
assert not summary['a1_accepted'] and summary['stage'] == failure['stage'] == 'human_plan_approval_queue'
assert len(summary['vm_pass_lines']) == 50
assert failure['authority_schema'] == 14 and failure['package_version'] == '0.4.12+gateabort.1'
assert all(key not in failure for key in ('action', 'job', 'queue_requested_action', 'execution_after_failure'))
assert len(failure['pre_effect']['cases']) == 3 and all(case['no_effect'] for case in failure['pre_effect']['cases'])
assert len(diagnostics) == 1
change = diagnostics[0]
assert change['event'] == 'storage_mount_consumer_tasks_changed' and change['phase'] == 'scan.recheck.user_tasks'
assert change['removed_count'] == 0 and change['added_count'] == 1
assert change['added'][0] == {'pid': 7055, 'tid': 8386, 'start': 27194, 'namespace': [4, 4026531841]}
assert change['added'][0]['pid'] == failure['docker']['peer']['pid']
startup = failure['fixture_docker_startup']
assert startup['read_passes'] == 4 and startup['quiet_observations'] == 40
assert startup['quiet_seconds'] >= 3 and startup['elapsed_seconds'] < 15
assert not startup['service_stopped_or_modified']
session = failure['last_api_session']
assert session['attempted_requests'] == session['successful_requests'] == 1 and session['reconnects'] == 0
assert session['socket_inode'] == 34006

commands = [[sys.executable, 'scripts/check_repository.py'], ['git', 'diff', '--check']]
checks = []
for command in commands:
    result = subprocess.run(command, cwd=root, text=True, capture_output=True)
    checks.append({'command': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0, checks[-1]
documents = [out / 'README.md', root / 'docs/p04-a1-gated-refusal-recovery-handoff.md',
             root / 'docs/p04-a1-namespace-budget-handoff.md', root / 'docs/rewrite-evidence/p04/2026-10-05-execution-tracker.md']
links = []
for document in documents:
    for target in re.findall(r'\]\(([^)]+)\)', document.read_text()):
        if '://' in target or target.startswith('#'):
            continue
        target = target.partition('#')[0]
        assert (document.parent / target).exists(), (document, target)
        links.append({'document': str(document.relative_to(root)), 'target': target})
for path in out.rglob('*.gz'):
    gzip.decompress(path.read_bytes())
with tarfile.open(out / 'reproduction-sources.tar.gz', mode='r:gz') as archive:
    names = archive.getnames()
    assert len([name for name in names if name.startswith('guest/')]) == 31
    assert all(not name.startswith('/') and '..' not in Path(name).parts for name in names)
    assert not any('signing-12/' in name or Path(name).suffix in ('.deb', '.qcow2', '.iso') for name in names)
    def embedded_sha(name):
        return hashlib.sha256(archive.extractfile(name).read()).hexdigest()
    assert embedded_sha('harness/guard.py') == '380a78ebd9dbb3902a97bebbcdb164df1e6bfc4c069b56a45092af6eb26813d6'
    manifest = json.loads((state / 'inputs-1.json').read_text())
    for name, expected in manifest['guest'].items():
        assert embedded_sha('guest/' + name) == expected
    assert embedded_sha('harness/run_1024.py') == manifest['runner_sha256']
verification = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source': summary['source'],
                'current_product_inputs_match': len(current), 'commands': checks,
                'relative_document_links_checked': len(links), 'links': links,
                'archive_members': len(names), 'all_gzip_files_readable': True,
                'actual_failure_and_source_joins_checked': True, 'sealer_sha256': sha(Path(__file__))}
(out / 'final-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
(out / 'seal-source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
paths = sorted(path for path in out.rglob('*') if path.is_file())
(out / 'SHA256SUMS').write_text(''.join(sha(path) + '  ' + str(path.relative_to(out)) + '\n' for path in paths))
for line in (out / 'SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    assert sha(out / name) == expected
assert current == {name: sha(root / name) for name in current}
print(json.dumps({'source': summary['source'], 'checksums_verified': len(paths),
                  'product_inputs': len(current), 'relative_links': len(links),
                  'actual_failure_joins_checked': True, 'repository_checks_passed': True}))
