"""Read-only kernel/profile diagnostic for an isolated AMD64 Debian guest."""
import ctypes
import json
import os
import platform
import sys
from pathlib import Path

assert platform.machine() == "x86_64"

class OpenHow(ctypes.Structure):
    _fields_ = [("flags", ctypes.c_uint64), ("mode", ctypes.c_uint64), ("resolve", ctypes.c_uint64)]

libc = ctypes.CDLL(None, use_errno=True)
libc.syscall.restype = ctypes.c_long
how = OpenHow(os.O_PATH | os.O_NOFOLLOW | os.O_CLOEXEC, 0, 0x02 | 0x04)
fd = libc.syscall(ctypes.c_long(437), ctypes.c_int(-100), ctypes.c_char_p(b"/etc/passwd"), ctypes.byref(how), ctypes.c_size_t(ctypes.sizeof(how)))
result = {"openat2_errno": ctypes.get_errno() if fd < 0 else 0}
if fd >= 0:
    os.close(fd)

def root_mount(path):
    with open(path, "r") as stream:
        text = stream.read(65537)
    assert len(text) <= 65536
    rows = [line.split() for line in text.splitlines()]
    roots = [int(row[0]) for row in rows if len(row) >= 10 and row[4] == "/"]
    assert len(roots) == 1 and roots[0] > 0
    return roots[0]

result["mount_root_ids"] = {"current": root_mount("/proc/self/mountinfo"), "pid1": root_mount("/proc/1/mountinfo")}
for name, path in (("current_namespace", "/proc/self/ns/mnt"), ("pid1_namespace", "/proc/1/ns/mnt")):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
        try:
            stat = os.fstat(fd)
            result[name] = {"device": stat.st_dev, "inode": stat.st_ino}
        finally:
            os.close(fd)
    except OSError as error:
        result[name] = {"errno": error.errno}
result["status"] = {line.split(":", 1)[0]: line.split(":", 1)[1].strip() for line in Path("/proc/self/status").read_text().splitlines() if line.startswith(("CapEff:", "CapBnd:", "NoNewPrivs:", "Seccomp:"))}
Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + "\n")
