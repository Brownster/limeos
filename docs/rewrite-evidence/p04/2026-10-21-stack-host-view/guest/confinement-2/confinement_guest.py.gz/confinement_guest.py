"""Compare exact reader confinement controls; no app or production activation."""
import errno
import grp
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from profile import UNIT

def run(*args):
    result = subprocess.run(args, text=True, capture_output=True, check=False, timeout=30)
    if result.returncode:
        raise RuntimeError(f"{args!r}: {result.returncode}: {result.stderr[-3000:]}")
    return result.stdout

assert os.geteuid() == 0 and Path("/etc/hostname").read_text().strip() == "limeos-p01-test"
output = Path(sys.argv[2])
evidence = {"scope": "Disposable AMD64 confinement diagnostic; no application qualification", "unit_sha256": hashlib.sha256(UNIT.encode()).hexdigest(), "variants": {}, "versions": run("systemd", "--version")}
units = []
try:
    # The package is deliberately not installed in this kernel diagnostic.
    # Supply only its fixed service group in the disposable guest.
    try:
        grp.getgrnam("limeos-host-access")
    except KeyError:
        run("groupadd", "--system", "limeos-host-access")
    run("python3", "/root/probe.py", "/root/probe-outside.json")
    evidence["outside_unit"] = json.loads(Path("/root/probe-outside.json").read_text())
    assert evidence["outside_unit"]["openat2_errno"] == 0
    for name, suid, explicit in (("baseline", True, False), ("no-suid", False, False), ("explicit-openat2", True, True), ("both", False, True)):
        result = Path("/root/probe-" + name + ".json")
        text = UNIT.replace("ExecStart=/usr/lib/limeos/limeos-executor /etc/limeos/system-policy/storage.json /run/limeos-storage-reader/executor.sock storage", "ExecStart=/usr/bin/python3 /root/probe.py " + str(result))
        text = text.replace("RuntimeDirectory=limeos-storage-reader", "RuntimeDirectory=limeos-confinement-probe-" + name)
        if not suid:
            text = text.replace("RestrictSUIDSGID=yes", "RestrictSUIDSGID=no")
        if explicit:
            text = text.replace("SystemCallFilter=@system-service", "SystemCallFilter=@system-service openat2")
        unit = "limeos-confinement-probe-" + name + ".service"
        path = Path("/etc/systemd/system") / unit
        path.write_text(text)
        units.append((unit, path))
        run("systemctl", "daemon-reload")
        run("systemctl", "start", unit)
        deadline = time.monotonic() + 10
        while not result.exists() and time.monotonic() < deadline:
            time.sleep(0.05)
        value = json.loads(result.read_text())
        assert value["status"]["CapEff"] == "0000000000000000"
        assert value["status"]["CapBnd"] == "0000000000000000"
        assert value["status"]["NoNewPrivs"] == "1"
        assert value["mount_root_ids"]["current"] == value["mount_root_ids"]["pid1"]
        assert value["pid1_namespace"]["errno"] == errno.EACCES
        evidence["variants"][name] = {"unit": text, "probe": value, "show": run("systemctl", "show", unit, "-p", "Result", "-p", "ExecMainStatus", "-p", "RestrictSUIDSGID", "-p", "SystemCallFilter", "-p", "MemoryMax", "-p", "TasksMax", "-p", "LimitNOFILE")}
        print("PROBE " + name + " openat2_errno=" + str(value["openat2_errno"]), flush=True)
    run("unshare", "--mount", "--propagation", "private", "--", "python3", "/root/probe.py", "/root/probe-private.json")
    evidence["private_namespace"] = json.loads(Path("/root/probe-private.json").read_text())
    private = evidence["private_namespace"]["mount_root_ids"]
    assert private["current"] != private["pid1"]
    assert evidence["variants"]["baseline"]["probe"]["openat2_errno"] == errno.ENOSYS
    assert evidence["variants"]["explicit-openat2"]["probe"]["openat2_errno"] == errno.ENOSYS
    assert evidence["variants"]["both"]["probe"]["openat2_errno"] == 0
    evidence["status"] = "passed diagnostic"
except BaseException as error:
    evidence["status"] = "failed diagnostic"
    evidence["error"] = repr(error)
    evidence["journal"] = run("journalctl", "--no-pager", "-n", "60", *[arg for unit, _ in units for arg in ("-u", unit)])
    print("CONFINEMENT_FAILURE=" + json.dumps(evidence), flush=True)
    raise
finally:
    for unit, path in units:
        subprocess.run(["systemctl", "stop", unit], capture_output=True, check=False)
        path.unlink(missing_ok=True)
    run("systemctl", "daemon-reload")
    output.write_text(json.dumps(evidence, indent=2) + "\n")
