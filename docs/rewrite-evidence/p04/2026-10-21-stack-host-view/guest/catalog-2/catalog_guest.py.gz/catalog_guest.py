"""Qualify genuine catalog host-view proof; Engine/B2 acceptance stays open."""
import hashlib
import http.client
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import guest as foundation

VERSION = "0.4.5+stack.2"
UNIT = "limeos-storage-reader"
CATALOG = Path("/etc/limeos/management-catalog.json")

def run(*args, input=None, check=True):
    result = subprocess.run(args, input=input, text=True, capture_output=True, check=False, timeout=180)
    if check and result.returncode:
        raise RuntimeError(f"{args!r}: {result.returncode}: {result.stdout[-2000:]} {result.stderr[-2000:]}")
    return result

def api(cookie=None, method="GET", path="/api/v1/deployment/stacks", body=None):
    conn = http.client.HTTPConnection("127.0.0.1", 8003, timeout=12)
    try:
        headers = {"Origin": "https://localhost", "Content-Type": "application/json"}
        if cookie:
            headers["Cookie"] = cookie
        conn.request(method, path, None if body is None else json.dumps(body), headers)
        response = conn.getresponse()
        data = response.read(65537)
        assert len(data) <= 65536
        return response.status, dict(response.getheaders()), json.loads(data) if data else None
    finally:
        conn.close()

def eventually(test):
    deadline = time.monotonic() + 50
    while True:
        value = test()
        if value:
            return value
        if time.monotonic() >= deadline:
            raise AssertionError("condition deadline")
        time.sleep(0.2)

def rpc(account):
    reply = run("runuser", "-u", account, "-g", "limeos-host-access", "--", "python3", "-c", foundation.executor_probe_code(), "/run/limeos-storage-reader/executor.sock", json.dumps({"version": 1, "operation": "stack_inventory"})).stdout
    return reply

def metrics():
    group = run("systemctl", "show", UNIT, "-p", "ControlGroup", "--value").stdout.strip()
    directory = Path("/sys/fs/cgroup") / group.lstrip("/")
    return {name: (directory / name).read_text().strip() for name in ("memory.current", "memory.peak", "memory.max", "memory.events", "pids.current", "pids.max", "pids.events") if (directory / name).exists()}

assert os.geteuid() == 0 and Path("/etc/hostname").read_text().strip() == "limeos-p01-test"
repo, output = map(Path, sys.argv[1:])
evidence = {"scope": "Installed AMD64 catalog host-view correction, not complete stack acceptance", "version": VERSION, "passed": [], "states": {}, "limitations": ["Engine remains unavailable under unchanged RestrictSUIDSGID", "No ARM64/Pi or whole-service maximum-layout acceptance", "No installed browser or worker-death/deadline fault matrix"]}
dropin = Path("/etc/systemd/system/limeos-storage-reader.service.d/90-private-namespace-fixture.conf")

def passed(message):
    evidence["passed"].append(message)
    print("PASS " + message, flush=True)

try:
    run("install", "-m", "0644", str(repo / "limeos-archive-keyring.gpg"), "/usr/share/keyrings/limeos-test.gpg")
    Path("/etc/apt/sources.list.d/limeos-test.list").write_text("deb [signed-by=/usr/share/keyrings/limeos-test.gpg] file:" + str(repo) + " stable main\n")
    run("apt-get", "update")
    run("apt-get", "install", "-y", "limeos=" + VERSION)
    assert run("systemctl", "is-active", UNIT, check=False).returncode != 0
    evidence["binaries"] = {name: hashlib.sha256((Path("/usr/lib/limeos") / name).read_bytes()).hexdigest() for name in ("limeos-core", "limeos-executor", "limeos-stack-read-worker", "limeos-password-worker", "limeosctl")}
    token = json.loads(run("/usr/lib/limeos/limeosctl", "bootstrap").stdout)["token"]
    run("/usr/lib/limeos/limeosctl", "enroll", input=json.dumps({"token": token, "username": "reader", "password": "disposable-catalog-read-password"}))
    status, headers, _ = api(method="POST", path="/api/v1/auth/login", body={"username": "reader", "password": "disposable-catalog-read-password"})
    assert status == 200
    cookie = headers["set-cookie"].split(";", 1)[0]
    assert api()[0] == 401
    root = Path("/opt/catalog-read-fixture/Media")
    root.mkdir(parents=True, mode=0o755)
    operator = root / "compose.yaml"
    operator.write_text("services:\n  web:\n    image: fixture\n")
    operator.chmod(0o644)
    CATALOG.write_text(json.dumps({"version": 1, "engine_id": "engine-a", "stacks": [{"stack": "media", "project": "media", "working_directory": str(root), "operator": {"name": "compose.yaml", "sha256": hashlib.sha256(operator.read_bytes()).hexdigest()}, "managed": {"state": "absent"}, "services": ["web"]}]}) + "\n")
    CATALOG.chmod(0o644)
    run("systemctl", "start", UNIT)

    def catalog(state):
        status, _, value = api(cookie)
        evidence["states"]["last"] = value
        return value if status == 200 and value["catalog"]["state"] == state and len(value["stacks"]) == 1 else None

    first = eventually(lambda: catalog("fresh"))
    assert first["engine"]["state"] == "unavailable"
    assert first["stacks"][0]["runtime"] == "unknown" and first["stacks"][0]["counts"] is None
    assert first["stacks"][0]["files"]["state"] == "not_inspected"
    evidence["states"]["fresh"] = first
    core = json.loads(rpc("limeos-core"))
    assert core["ready"] and core["stack_cohort"]["catalog_current"] and not core["stack_cohort"]["engine_current"]
    assert foundation.refused_executor_reply(rpc("nobody"), "forbidden")
    passed("genuine catalog reaches API/RPC under unchanged empty-capability profile; foreign UID refused")
    before = core["stack_cohort"]["catalog"]["sampled_at"]
    for _ in range(20):
        assert api(cookie)[0] == 200
    after = json.loads(rpc("limeos-core"))["stack_cohort"]["catalog"]["sampled_at"]
    assert before == after
    passed("API/RPC bursts do not renew the original catalog timestamp")
    pid = run("systemctl", "show", UNIT, "-p", "MainPID", "--value").stdout.strip()
    evidence["manager_status"] = (Path("/proc") / pid / "status").read_text()
    assert "CapEff:\t0000000000000000" in evidence["manager_status"]
    evidence["resources_before_restart"] = metrics()
    CATALOG.chmod(0o666)
    stale = eventually(lambda: catalog("stale"))
    assert stale["catalog"]["sampled_at"] >= first["catalog"]["sampled_at"]
    assert stale["stacks"][0]["counts"] is None
    evidence["states"]["writable_refusal"] = stale
    passed("writable catalog refuses fresh acquisition and leaves explicit stale facts")
    CATALOG.chmod(0o644)
    recovered = eventually(lambda: catalog("fresh"))
    assert recovered["catalog"]["sampled_at"] > stale["catalog"]["sampled_at"]
    passed("protected catalog recovers through a new genuine collection")
    run("systemctl", "stop", UNIT)
    dropin.parent.mkdir(parents=True, exist_ok=True)
    dropin.write_text("[Service]\nPrivateMounts=yes\n")
    run("systemctl", "daemon-reload")
    run("systemctl", "start", UNIT)

    def private_refused():
        value = json.loads(rpc("limeos-core"))
        evidence["states"]["private_rpc"] = value
        cohort = value.get("stack_cohort")
        return value if cohort is not None and not cohort["catalog_current"] else None

    eventually(private_refused)
    eventually(lambda: catalog("stale"))
    passed("a real service-private mount namespace refuses catalog collection")
    run("systemctl", "stop", UNIT)
    dropin.unlink()
    run("systemctl", "daemon-reload")
    run("systemctl", "start", UNIT)
    restored = eventually(lambda: catalog("fresh"))
    evidence["states"]["restored"] = restored
    run("systemctl", "restart", "limeos-core")
    eventually(lambda: run("/usr/lib/limeos/limeosctl", "status", check=False).returncode == 0)
    evidence["states"]["core_restart"] = eventually(lambda: catalog("fresh"))
    passed("host-view reader and Core restart recover genuine catalog data")
    resources = metrics()
    evidence["resources_final"] = resources
    assert resources["memory.max"] == str(64 * 1024**2) and resources["pids.max"] == "16"
    events = dict(line.split() for line in resources["memory.events"].splitlines())
    assert all(events[name] == "0" for name in ("max", "oom", "oom_kill"))
    evidence["status"] = "passed catalog correction only"
except BaseException as error:
    evidence["status"] = "failed"
    evidence["error"] = repr(error)
    evidence["journal"] = run("journalctl", "-u", UNIT, "-u", "limeos-core", "--no-pager", "-n", "80", check=False).stdout[-20000:]
    try:
        evidence["resources_failure"] = metrics()
    except (OSError, subprocess.SubprocessError, RuntimeError):
        pass
    print("CATALOG_FAILURE=" + json.dumps(evidence), flush=True)
    raise
finally:
    if dropin.exists():
        dropin.unlink()
    output.write_text(json.dumps(evidence, indent=2) + "\n")
