# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Bind host-view correction checks and installed evidence to their source."""
import datetime
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
state = Path(__file__).resolve().parent
out = root / "docs/rewrite-evidence/p04/2026-10-21-stack-host-view"
out.mkdir(exist_ok=False)
files = {}

def archive(path, name):
    data = path.read_bytes()
    packed = gzip.compress(data, mtime=0)
    target = out / (name + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(packed)
    files[str(target.relative_to(out))] = {"source": str(path.relative_to(root)), "sha256": hashlib.sha256(packed).hexdigest(), "original_sha256": hashlib.sha256(data).hexdigest(), "original_bytes": len(data)}

build = json.loads((state / "build-2/record.json").read_text())
assert build["exit_code"] == 0 and build["stop_reason"] is None and build["container_removed"] and build["inputs_unchanged"]
for path in sorted((state / "build-2").iterdir()):
    if path.is_file():
        archive(path, "build/" + path.name)
for name in ("inputs.json", "prepare_packages.py"):
    archive(state / "candidate-2" / name, "candidate/" + name)
for name in ("InRelease", "Release", "Release.gpg"):
    archive(state / "candidate-2/repository/dists/stable" / name, "repository/" + name)
archive(state / "candidate-2/repository/limeos-archive-keyring.gpg", "repository/limeos-archive-keyring.gpg")
labels = ["stack-confinement-probe-1", "stack-confinement-probe-2", "stack-host-view-container-1", "stack-host-view-clippy-1", "stack-host-view-packages-2", "stack-host-view-installed-1"]
attempts = {}
for label in labels:
    directory = root / ".cache/main-consolidation/attempts" / label
    record = json.loads((directory / "record.json").read_text())
    assert record.get("ended") and "exit_code" in record and record["inputs_unchanged"]
    if label != "stack-confinement-probe-1":
        assert record["exit_code"] == 0 and not record["guard_triggered"]
    attempts[label] = {k: record[k] for k in ("head", "started", "ended", "exit_code", "guard_triggered", "minimum_available_bytes", "inputs_unchanged")}
    for name in ("record.json", "output.log"):
        archive(directory / name, "attempts/" + label + "/" + name)
for group in ("confinement-1", "confinement-2", "catalog-2"):
    for path in sorted((state / group).iterdir()):
        if path.is_file():
            archive(path, "guest/" + group + "/" + path.name)
for name in ("run_768.py", "current_authority_schema.py", "archive_host_view.py"):
    archive(state / name, "inputs/" + name)
source = build["source"]
patch = subprocess.check_output(["git", "show", "--format=fuller", "--binary", source], cwd=root)
patch_path = state / "host-view-source.patch"
patch_path.write_bytes(patch)
archive(patch_path, "source.patch")
manifest = {"source": source, "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "scope": "Catalog host-view correction; Engine and full B2 acceptance remain open", "candidate": json.loads((state / "candidate-2/inputs.json").read_text()), "attempts": attempts, "files": files}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
for name, entry in files.items():
    data = (out / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == entry["sha256"]
    assert hashlib.sha256(gzip.decompress(data)).hexdigest() == entry["original_sha256"]
print(json.dumps({"packet": str(out), "source": source, "records": len(files), "attempts": attempts}))
