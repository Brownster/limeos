# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Verify source identity, actual installed payloads and every archived record."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
packet = root / "docs/rewrite-evidence/p04/2026-10-21-stack-host-view"
manifest = json.loads((packet / "manifest.json").read_text())
for name, entry in manifest["files"].items():
    packed = (packet / name).read_bytes()
    data = gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest() == entry["sha256"]
    assert hashlib.sha256(data).hexdigest() == entry["original_sha256"]
    assert len(data) == entry["original_bytes"]

def record(name):
    return json.loads(gzip.decompress((packet / name).read_bytes()))

build = record("build/record.json.gz")
assert build["source"] == manifest["source"]
assert build["before"] == build["after"] and build["inputs_unchanged"]
assert build["exit_code"] == 0 and not build["oom_killed"] and build["container_removed"]
for path, expected in build["before"].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
for label in ("stack-host-view-container-1", "stack-host-view-clippy-1"):
    native = record("attempts/" + label + "/record.json.gz")
    assert native["before"] == native["after"] == build["before"]
    assert native["exit_code"] == 0 and not native["guard_triggered"]
test_log = gzip.decompress((packet / "attempts/stack-host-view-container-1/output.log.gz").read_bytes()).decode()
assert "test result: ok. 356 passed; 0 failed" in test_log
assert "test result: ok. 17 passed; 0 failed" in test_log
candidate = manifest["candidate"]
assert candidate["source"] == build["source"]
installed = record("guest/catalog-2/result.json.gz")
assert installed["status"] == "passed catalog correction only" and len(installed["passed"]) == 6
assert installed["version"] == candidate["version"]
for name, expected in candidate["binaries"].items():
    assert installed["binaries"][name] == expected["sha256"]
for name, expected in candidate["packages"].items():
    payload = root / ".cache/stack-installed-qualification/candidate-2/packages" / name
    assert hashlib.sha256(payload.read_bytes()).hexdigest() == expected
for resources in (installed["resources_before_restart"], installed["resources_final"]):
    assert resources["memory.max"] == "67108864" and resources["pids.max"] == "16"
    events = dict(line.split() for line in resources["memory.events"].splitlines())
    assert all(events[key] == "0" for key in ("max", "oom", "oom_kill"))
probe = record("guest/confinement-2/result.json.gz")
assert probe["status"] == "passed diagnostic"
assert {key: value["probe"]["openat2_errno"] for key, value in probe["variants"].items()} == {"baseline": 38, "no-suid": 0, "explicit-openat2": 38, "both": 0}
assert probe["unit_sha256"] == build["before"]["packaging/systemd/limeos-storage-reader.service"]
for group in ("confinement-1", "confinement-2", "catalog-2"):
    name = "inputs-before.json" if group == "catalog-2" else "inputs.json"
    for path, expected in record("guest/" + group + "/" + name + ".gz").items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
paths = sorted(path for path in packet.rglob("*") if path.is_file() and path.name != "artifacts.sha256")
(packet / "artifacts.sha256").write_text("".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + str(path.relative_to(packet)) + "\n" for path in paths))
print(json.dumps({"source": manifest["source"], "compressed_records_verified": len(manifest["files"]), "packet_files_hashed": len(paths), "native_and_build_inputs_match": True, "installed_payloads_match": True, "installed_catalog_checks": len(installed["passed"])}))
