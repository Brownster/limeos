# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Identify copied failed-run diagnostics without attributing them to probe 2."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
packet = root / "docs/rewrite-evidence/p04/2026-10-21-stack-host-view"
manifest_path = packet / "manifest.json"
manifest = json.loads(manifest_path.read_text())
inherited = []
for basename in ("result-startup-console.txt", "result-vm-failure.txt"):
    original = "guest/confinement-1/" + basename + ".gz"
    copied = "guest/confinement-2/" + basename + ".gz"
    renamed = "guest/confinement-2/inherited-probe-1-" + basename + ".gz"
    data = gzip.decompress((packet / copied).read_bytes())
    assert data == gzip.decompress((packet / original).read_bytes())
    assert not (packet / renamed).exists()
    (packet / copied).rename(packet / renamed)
    entry = manifest["files"].pop(copied)
    entry["provenance_note"] = "Copied from failed probe 1 with fixture scripts; not emitted by successful probe 2"
    manifest["files"][renamed] = entry
    inherited.append({"copied_path": copied, "labelled_path": renamed, "original_path": original, "original_sha256": hashlib.sha256(data).hexdigest()})
manifest["inherited_probe_1_diagnostics"] = inherited
data = Path(__file__).read_bytes()
packed = gzip.compress(data, mtime=0)
name = "inputs/label_inherited_diagnostics.py.gz"
(packet / name).write_bytes(packed)
manifest["files"][name] = {"source": str(Path(__file__).relative_to(root)), "sha256": hashlib.sha256(packed).hexdigest(), "original_sha256": hashlib.sha256(data).hexdigest(), "original_bytes": len(data)}
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"inherited_diagnostics_labelled": len(inherited), "passing_probe_results_unchanged": True}))
