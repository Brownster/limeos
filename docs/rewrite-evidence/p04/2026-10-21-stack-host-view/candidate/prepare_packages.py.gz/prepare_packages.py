# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Assemble fresh candidate packages on host disk; sign only disposable fixtures."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/stack-installed-qualification'
BUILD = STATE / 'build-2'
OUT = STATE / 'candidate-2'
VERSION = '0.4.5+stack.2'
IMAGE = 'sha256:e0df67a00f0f3080a0d01274c4c492c1173c6e39853913864d2cf596ad726fab'
record = json.loads((BUILD / 'record.json').read_text())
assert record['exit_code']==0 and record['stop_reason'] is None and record['inputs_unchanged'] and record['container_removed']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==record['source']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for name,facts in json.loads((BUILD/'binaries.json').read_text()).items():
    assert digest(BUILD/'binaries'/name)==facts['sha256']
ui=json.loads((ROOT/'docs/rewrite-evidence/p04/2026-10-20-stack-inventory-runtime/manifest.json').read_text())['production_ui']
for name,expected in ui.items():assert digest(ROOT/name)==expected,name
OUT.mkdir(exist_ok=False)
packages=OUT/'packages';packages.mkdir()
for profile in ('standard','shadow'):
    subprocess.run(['uv','run','--offline','--no-project','--no-managed-python','packaging/build.py','--arch','amd64','--version',VERSION,'--profile',profile,'--binaries',str(BUILD/'binaries'),'--output',str(packages)],cwd=ROOT,check=True)
command=['docker','run','--rm','--network=none','--read-only','--memory=128m','--pids-limit=32','--cap-drop=ALL','--security-opt=no-new-privileges','--security-opt=label=disable','--user','1000:1000','--env','GNUPGHOME=/build/.cache/a1-namespace-review/gnupg','--env','TMPDIR=/build/.cache/stack-installed-qualification/tmp','--volume',str(ROOT)+':/build','--workdir','/build',IMAGE]
def inside(path):return '/build/'+str(path.relative_to(ROOT))
files=sorted(packages.glob('*.deb'));assert len(files)==2
observed=subprocess.check_output([*command,'sha256sum',*map(inside,files)],text=True).splitlines()
assert [line.split()[0] for line in observed]==[digest(path) for path in files], 'Immutable package handoff mismatch'
fingerprint=json.loads((ROOT/'.cache/a1-namespace-review/inputs.json').read_text())['signing_fingerprint']
subprocess.run([*command,'packaging/repository.sh',inside(OUT/'repository'),fingerprint,*map(inside,files)],check=True,cwd=ROOT)
inputs={'source':record['source'],'version':VERSION,'scope':'fresh standard and shadow packages; all five Debian binaries from one frozen source','packages':{p.name:digest(p) for p in files},'binaries':json.loads((BUILD/'binaries.json').read_text()),'ui':ui,'packaging_sha256':digest(ROOT/'packaging/build.py'),'repository_tool_image':IMAGE,'package_handoff':observed}
(OUT/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print(json.dumps({'source':inputs['source'],'version':VERSION,'packages':inputs['packages']}))
