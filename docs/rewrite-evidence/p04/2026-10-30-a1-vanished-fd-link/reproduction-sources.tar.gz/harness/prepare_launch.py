# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Prepare one frozen runtime-fix candidate and launch its detached guarded VM."""
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/stack-installed-qualification'
GUARD = ROOT / '.cache/main-consolidation/guard.py'
steps = [
    ('fd-owner-ui-10', [sys.executable, str(GUARD), 'a1-fd-owner-ui-build-1', 'npm', '--prefix', 'frontend', 'run', 'build']),
    ('fd-owner-packages-10', [sys.executable, str(GUARD), 'a1-fd-owner-packages-1', sys.executable, str(STATE / 'prepare_packages_10.py')]),
    ('fd-owner-guest-10', [sys.executable, str(STATE / 'prepare_fd_owner_guest.py')]),
    ('fd-owner-launch-10', [sys.executable, str(STATE / 'launch_fd_owner_vm.py')]),
]
assert not [v for v in subprocess.check_output(['ps', '-eo', 'comm'], text=True).splitlines()
            if v.strip() in ('cargo', 'rustc', 'rustdoc')]
for label, command in steps:
    with (STATE / (label + '-console.log')).open('xb') as stream:
        status = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT).returncode
    print(label, status, flush=True)
    if status:
        raise SystemExit(status)
print('VM launched; acceptance requires the original guard terminal record and installed result', flush=True)
