# /// script
# dependencies = []
# ///
"""Seal existing terminal observations; never start a VM or modify evidence inputs."""

import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import tarfile

ROOT = Path('/home/marc/Documents/github/lime-os')
OUT = ROOT / 'docs/rewrite-evidence/p04/2026-11-05-b2-installed-stack-ui'
STATE = Path(__file__).parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    data = (OUT / name).read_bytes()
    return json.loads(gzip.decompress(data) if name.endswith('.gz') else data)


assert not (OUT / 'SHA256SUMS').exists()
manifest = read('observations/inputs-2.json.gz')
package = read('package-inputs.json.gz')
result = read('installed-result.json')
source = read('source-match.json')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == manifest['fixture_source'] == source['fixture_source']
assert len(manifest['fixture_inputs']) == 752 and len(package['package_inputs']) == 749
assert sha(gzip.decompress((OUT / 'package-inputs.json.gz').read_bytes())) == manifest['package_inputs_sha256']
assert sha(gzip.decompress((OUT / 'original-build-record.json.gz').read_bytes())) == manifest['build_record_sha256']
for name, expected in manifest['fixture_inputs'].items():
    assert sha((ROOT / name).read_bytes()) == expected
    assert sha(subprocess.check_output(['git', 'show', manifest['fixture_source'] + ':' + name], cwd=ROOT)) == expected
changes = {name: {'before': value, 'after': manifest['fixture_inputs'][name]} for name, value in package['package_inputs'].items() if manifest['fixture_inputs'][name] != value}
additions = {name: value for name, value in manifest['fixture_inputs'].items() if name not in package['package_inputs']}
assert changes == manifest['test_only_changes_between_package_and_fixture'] and len(changes) == 2
assert additions == manifest['test_only_additions_since_package'] and len(additions) == 3
assert all(name.startswith('tests/') for name in changes.keys() | additions.keys())
assert manifest['package_source'] == manifest['ui_source'] == package['source'] == package['ui_source']
assert manifest['binary_source'] == package['binary_source']
assert sha((ROOT / 'tests/privileged_vm/run.py').read_bytes()) == manifest['runner_sha256']
assert manifest['guest_memory_mib'] == 1024
for phase in ('reference-1', 'reference-2', 'vm-1', 'vm-2'):
    row = read('checks/b2-installed-stack-' + phase + '-record.json.gz')
    assert row['ended'] and row['inputs_unchanged'] and not row['guard_triggered']
    assert row['exit_code'] == (1 if phase == 'vm-1' else 0)
    assert row['before'] == row['after'] and row['minimum_available_bytes'] >= row['memory_floor_bytes'] == 3 * 1024**3
    assert row['guard_sha256'] == '380a78ebd9dbb3902a97bebbcdb164df1e6bfc4c069b56a45092af6eb26813d6'
    if phase.endswith('-2'):
        assert row['before'] == manifest['fixture_inputs']
assert read('checks/b2-installed-stack-reference-2-record.json.gz')['head'].startswith('45a5181')
assert read('checks/b2-installed-stack-vm-2-record.json.gz')['head'] == manifest['fixture_source']
assert all(row['exit_code'] == 0 for row in read('observations/reference-2-checks.json.gz'))
failure = read('observations/failure-1.json.gz')
assert failure['stage'] == 'mixed_layout' and failure['error_type'] == 'OperationalError'
assert 'no such table: approvals' in gzip.decompress((OUT / 'checks/b2-installed-stack-vm-1-output.log.gz').read_bytes()).decode()
with tarfile.open(fileobj=io.BytesIO((OUT / 'reproduction-sources.tar.gz').read_bytes()), mode='r:gz') as archive:
    members = archive.getmembers()
    assert all(row.isfile() and not PurePosixPath(row.name).is_absolute() and '..' not in PurePosixPath(row.name).parts for row in members)
    for number in (1, 2):
        frozen = read(f'observations/inputs-{number}.json.gz')
        assert len(frozen['guest']) == 36
        for name, expected in frozen['guest'].items():
            assert sha(archive.extractfile(f'guest-{number}/' + name).read()) == expected
        for name, expected in frozen['runner_support'].items():
            assert sha(archive.extractfile('harness/' + name).read()) == expected
    assert sha(archive.extractfile('harness/run_1024.py').read()) == manifest['runner_sha256']
    assert sha(archive.extractfile('harness/guard.py').read()) == '380a78ebd9dbb3902a97bebbcdb164df1e6bfc4c069b56a45092af6eb26813d6'
assert result['summary'] == 'pass' and result['stage'] == 'complete' and len(result['passed']) == 4
assert result['package_version'] == package['version'] == '0.4.14+healthui.1'
assert result['packages'] == package['packages']
assert result['binaries'] == {name: row['sha256'] for name, row in package['binaries'].items()}
assert {'frontend/dist/' + name: value for name, value in result['ui'].items()} == package['ui']
assert result['fixture_sha256'] == manifest['guest']['p04_stacks_browser_guest.py']
assert result['authority_schema'] == 14 and len(result['authority_final']) == 12 and not any(result['authority_final'].values())
assert result['immutable_before'] == result['immutable_after'] and result['source_before'] == result['source_after']
assert result['oom_before'] == result['oom_after'] == {'oom_kill': 0}
assert result['core_restart']['before_pid'] != int(result['core_restart']['after']['MainPID'])
assert result['reader_restart']['before'] != result['reader_restart']['after']
members = result['members']
assert len(members) == 16 and len({row['id'] for row in members}) == 16
assert sum(row['running'] for row in members) == 8 and sum(row['stack'] is None for row in members) == 1
assert all(re.fullmatch('[0-9a-f]{64}', row['id']) for row in members)


def counts(rows):
    return dict(ordinary=sum(not r['one_off'] for r in rows), running=sum(r['running'] and not r['one_off'] for r in rows), one_offs=sum(r['one_off'] for r in rows), one_off_running=sum(r['running'] and r['one_off'] for r in rows))


for state in ('empty', 'mixed', 'maximum', 'recovered', 'core_restarted', 'reader_restarted'):
    value = result['states'][state]
    assert value['catalog']['state'] == value['engine']['state'] == 'fresh' and value['engine_matches_catalog'] is True
    assert len(value['stacks']) == 8 and not value['other_projects']
    assert value['standalone_containers'] == (0 if state == 'empty' else 1)
    by_id = {row['stack']: row for row in value['stacks']}
    assert set(by_id) == {'fixture' + str(index) for index in range(8)}
    for index in range(8):
        key = 'fixture' + str(index)
        row = by_id[key]
        declared = {'web', 'worker', *('missing' + str(n) for n in range(14))} if state not in ('empty', 'mixed') else ({'web', 'worker'} if index == 5 else {'web'})
        expected = [member for member in members if member['stack'] == key] if state != 'empty' else []
        extra = {member['service'] for member in expected} - declared
        missing = len(declared - {member['service'] for member in expected if not member['one_off']})
        total = counts(expected)
        runtime = 'no_containers' if not total['ordinary'] else 'stopped' if not total['running'] else 'running' if total['running'] == total['ordinary'] and not missing and not extra else 'partial'
        assert row['project'] == key and row['working_directory'] == '/opt/limeos-b2-fixture/Stack' + str(index)
        assert row['config_files'] == [row['working_directory'] + '/compose.yaml'] and row['files'] == {'state': 'not_inspected'}
        assert row['counts'] == total and row['missing_services'] == missing and row['runtime'] == runtime
        assert row['issues'] == (['undeclared_services'] if extra else [])
        assert {service['name'] for service in row['services']} == declared | {member['service'] for member in expected}
        for service in row['services']:
            expected_service = [member for member in expected if member['service'] == service['name']]
            assert service['counts'] == counts(expected_service) and service['declared'] == (service['name'] in declared)
            assert {item['container']['resource']: (item['container']['running'], item['one_off']) for item in service['members']} == {'container:' + item['id']: (item['running'], item['one_off']) for item in expected_service}
refused = result['states']['refused']
assert refused['catalog']['state'] == 'stale' and refused['engine']['state'] == 'fresh' and refused['engine_matches_catalog'] is None
assert refused['catalog']['sampled_at'] == result['states']['maximum']['catalog']['sampled_at'] < result['states']['recovered']['catalog']['sampled_at']
assert len(refused['stacks']) == 8
for row in refused['stacks']:
    assert row['counts'] is None and row['missing_services'] is None and row['runtime'] == 'unknown'
    assert all(service['counts'] is None and service['runtime'] == 'unknown' for service in row['services'])
resources = result['resources']
assert resources['samples'] == 11912 and resources['memory_peak'] == 6250496 and not resources['errors']
assert resources['memory_peak'] < 64 * 1024**2 and resources['tasks_maximum'] == 5 and resources['sampled_fd_maximum'] == 18
assert {'manager', 'guardian', 'worker'} == {row['role'] for row in resources['processes'].values()}
for row in resources['processes'].values():
    expected_image = 'limeos-executor' if row['role'] == 'manager' else 'limeos-stack-read-worker'
    assert row['sha256'] == result['binaries'][expected_image]
    assert row['status']['Uid'].split() == ['0'] * 4 and row['status']['NoNewPrivs'] == '1'
    assert all(int(row['status'][key], 16) == 0 for key in ('CapEff', 'CapPrm', 'CapBnd'))
assert resources['last_cgroup']['memory.max'] == str(64 * 1024**2) and resources['last_cgroup']['pids.max'] == '16'
for key in ('memory.events', 'pids.events'):
    assert all(line.split()[1] == '0' for line in resources['last_cgroup'][key].splitlines())
effects = [row for row in result['http'] if row['method'] != 'GET']
assert effects == [dict(method='POST', path='/api/v1/auth/login', status=200), dict(method='POST', path='/api/v1/auth/logout', status=204), dict(method='POST', path='/api/v1/auth/login', status=200)]
assert all(set(row) == {'method', 'path', 'status'} and '?' not in row['path'] for row in result['http'])
assert len(result['screenshots']) == 5
for shot in result['screenshots'].values():
    data = (OUT / shot['file']).read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n' and sha(data) == shot['sha256']
    width, height = struct.unpack('!II', data[16:24])
    assert (width, height) == (shot['width'], shot['height'])
    assert abs(width - shot['geometry']['target_width']) <= 1 and abs(height - shot['geometry']['target_height']) <= 1
    assert shot['geometry']['page_width'] <= shot['geometry']['viewport_width'] + 1
assert read('visual-review.json')['mobile_visual_acceptance'] is False
cleanup = read('observations/cleanup-2.json.gz')
assert cleanup['unique_pids'] == 10 and cleanup['all_recorded_original_processes_absent'] and not cleanup['unrelated_processes_stopped']
assert all(row['absent'] for row in cleanup['processes'] + cleanup['vm_scratch'])
for name, expected in package['repository'].items():
    path = OUT / ('repository/' + name + '.gz')
    if path.exists():
        assert sha(gzip.decompress(path.read_bytes())) == expected
for path in OUT.rglob('*.gz'):
    gzip.decompress(path.read_bytes())
for path in (OUT / 'README.md', ROOT / 'docs/p04-stack-inventory-runtime-handoff.md', ROOT / 'docs/rewrite-evidence/p04/2026-10-05-execution-tracker.md'):
    for link in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        if '://' not in link and not link.startswith('#'):
            assert (path.parent / link.split('#')[0]).exists(), (path, link)
verification = dict(source=manifest['fixture_source'], package_source=package['source'], binary_source=package['binary_source'], source_inputs_checked=752, native_cases=26, installed_checkpoint_groups=4, first_fixture_failure_preserved=True, current_read_flow_passed=True, mobile_visual_acceptance=False, full_b2_p04_cutover_qualified=False, original_processes_absent=10, owned_vm_scratch_removed=2, source_and_observation_checks='pass')
(OUT / 'final-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
(OUT / 'seal-source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
files = sorted(path for path in OUT.rglob('*') if path.is_file())
(OUT / 'SHA256SUMS').write_text(''.join(sha(path.read_bytes()) + '  ' + str(path.relative_to(OUT)) + '\n' for path in files))
subprocess.run(['sha256sum', '--check', '--quiet', 'SHA256SUMS'], cwd=OUT, check=True)
print(json.dumps(dict(sealed_files=len(files), **verification)))
