# /// script
# dependencies = []
# ///
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
builders=root/'.cache/stack-installed-qualification'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
packages=json.loads((builders/'candidate-14/inputs.json').read_text())
build=json.loads((builders/'build-12/record.json').read_text())
native=json.loads((root/'.cache/main-consolidation/attempts/b2-installed-stack-reference-1/record.json').read_text())
assert native['exit_code']==0 and native['inputs_unchanged'] and not native['guard_triggered'] and native['ended']
assert native['before']==native['after']
current=native['before'];original=packages['package_inputs']
assert set(original).issubset(current)
changes={name:dict(before=expected,after=current[name]) for name,expected in original.items() if current[name]!=expected}
additions={name:value for name,value in current.items() if name not in original}
assert set(changes)=={'tests/privileged_vm/p04_automation_browser_guest.py','tests/reference/test_p04_automation_browser_guest.py'}
assert set(additions)=={'tests/privileged_vm/p04_stacks_browser_guest.py','tests/privileged_vm/p04_reader_resources.py','tests/reference/test_p04_stacks_browser_guest.py'}
assert len(current)==752 and build['source']==packages['binary_source'] and build['exit_code']==0 and build['inputs_unchanged'] and build['container_removed']
for name,expected in current.items():
 assert sha(root/name)==expected
 assert hashlib.sha256(subprocess.check_output(['git','show',f'{head}:{name}'],cwd=root)).hexdigest()==expected
for name,expected in packages['repository'].items():assert sha(builders/'candidate-14/repository'/name)==expected
for name,expected in packages['ui'].items():assert sha(root/name)==expected
guest=state/'guest-1';guest.mkdir(exist_ok=False)
for path in sorted((root/'tests/privileged_vm').glob('*.py')):shutil.copyfile(path,guest/path.name)
(guest/'installed_guest.py').write_text('import p04_stacks_browser_guest as guest\nguest.main(package_version='+repr(packages['version'])+')\n')
for name,original_name in [('run_1024.py','run.py'),('current_authority_schema.py','current_authority_schema.py')]:shutil.copyfile(root/'tests/privileged_vm'/original_name,state/name)
manifest=dict(fixture_source=head,package_source=packages['source'],ui_source=packages['ui_source'],binary_source=packages['binary_source'],fixture_inputs=current,
 package_inputs_sha256=sha(builders/'candidate-14/inputs.json'),build_record_sha256=sha(builders/'build-12/record.json'),native_record_sha256=sha(root/'.cache/main-consolidation/attempts/b2-installed-stack-reference-1/record.json'),schema_source_sha256=sha(root/'crates/persistence/src/lib.rs'),
 test_only_changes_between_package_and_fixture=changes,test_only_additions_since_package=additions,application_and_package_bytes_unchanged=True,
 guest_memory_mib=1024,runner_sha256=sha(state/'run_1024.py'),runner_support={'current_authority_schema.py':sha(state/'current_authority_schema.py')},guest={path.name:sha(path) for path in sorted(guest.glob('*.py'))},scope='Current installed AMD64 Stack maximum-layout API/UI and cgroup observations; not full B2/P04/Pi/cutover')
with (state/'inputs-1.json').open('x') as stream:stream.write(json.dumps(manifest,indent=2)+'\n')
old=root/'.cache/b1-status-panel-qualification'
for source,target in [('launch_vm.py','launch_vm.py'),('observe_vm.py','observe_vm.py')]:
 value=(old/source).read_text().replace('b1-status-panel','b2-installed-stack')
 with (state/target).open('x') as stream:stream.write(value)
print(json.dumps(dict(fixture=head,package=packages['source'],ui=packages['ui_source'],binary=packages['binary_source'],fixture_inputs=len(current),guest_modules=len(manifest['guest']))))
