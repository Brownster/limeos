# /// script
# dependencies = []
# ///
from pathlib import Path
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
old=root/'.cache/b1-status-panel-qualification'
(state/'launch.py').write_text((old/'launch.py').read_text().replace('b1-status-panel','b2-installed-stack'))
value=(old/'check_reference.py').read_text()
value=value.replace("'test_p04_automation_browser_guest.py'", "'test_p04_stacks_browser_guest.py'")
value=value.replace("files = ['tests/privileged_vm/p04_automation_browser_guest.py', 'tests/reference/test_p04_automation_browser_guest.py']", "files = ['tests/privileged_vm/p04_automation_browser_guest.py', 'tests/privileged_vm/p04_stacks_browser_guest.py', 'tests/privileged_vm/p04_reader_resources.py', 'tests/reference/test_p04_stacks_browser_guest.py']")
# Retain the existing capture helper's eight native boundary cases separately.
value=value.replace('commands = [', "commands = [\n [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_p04_automation_browser_guest.py', '-v'],")
(state/'check_reference.py').write_text(value)
