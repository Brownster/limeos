# /// script
# dependencies = []
# ///
import datetime
import json
from pathlib import Path
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
prior=json.loads((state/'cleanup.json').read_text())
records=[json.loads((root/'.cache/main-consolidation/attempts'/('b2-installed-stack-'+phase)/'record.json').read_text()) for phase in ('reference-2','vm-2')]
assert all(row.get('ended') and row['inputs_unchanged'] and not row['guard_triggered'] for row in records)
launches=[json.loads((state/name).read_text()) for name in ('reference-2-launch.json','guard-launch-2.json')]
observed=json.loads((state/'vm-process-observation-2.json').read_text())
assert len(observed['qemu'])==1
qemu=observed['qemu'][0]
pids=sorted({row['pid'] for row in records+launches+[qemu,observed['runner']]+prior['processes']})
processes=[dict(pid=pid,absent=not (Path('/proc')/str(pid)).exists()) for pid in pids]
assert all(row['absent'] for row in processes)
arg=next(arg for arg in qemu['command'] if arg.startswith('file=') and '/disk.qcow2,format=' in arg)
scratch=Path(arg.removeprefix('file=').split(',',1)[0]).parent
assert scratch.parent==root/'.cache/main-consolidation/tmp' and scratch.name.startswith('limeos-p01-vm-')
paths=[Path(row['path']) for row in prior['vm_scratch']]+[scratch]
assert all(not path.exists() for path in paths)
value=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=processes,unique_pids=len(pids),all_recorded_original_processes_absent=True,vm_scratch=[dict(path=str(path),absent=True) for path in paths],unrelated_processes_stopped=False)
with (state/'cleanup-2.json').open('x') as stream:stream.write(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
