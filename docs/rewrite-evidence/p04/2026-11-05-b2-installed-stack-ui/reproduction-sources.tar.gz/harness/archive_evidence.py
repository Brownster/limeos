# /// script
# dependencies = []
# ///
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import tarfile
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
builders=root/'.cache/stack-installed-qualification'
out=root/'docs/rewrite-evidence/p04/2026-11-05-b2-installed-stack-ui'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
manifest=read(state/'inputs-2.json');packages=read(builders/'candidate-14/inputs.json')
result=read(state/'result-2.json');cleanup=read(state/'cleanup-2.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head==manifest['fixture_source'] and packages['source']==manifest['package_source']
assert packages['ui_source']==manifest['ui_source'] and packages['binary_source']==manifest['binary_source']
assert sha(builders/'candidate-14/inputs.json')==manifest['package_inputs_sha256']
records={phase:read(root/'.cache/main-consolidation/attempts'/('b2-installed-stack-'+phase)/'record.json') for phase in ('reference-1','reference-2','vm-1','vm-2')}
for phase,record in records.items():
 assert record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
 assert record['exit_code']==(1 if phase=='vm-1' else 0)
for phase in ('reference-2','vm-2'):assert records[phase]['before']==records[phase]['after']==manifest['fixture_inputs']
for name,expected in manifest['fixture_inputs'].items():
 assert sha(root/name)==expected
 assert hashlib.sha256(subprocess.check_output(['git','show',f'{head}:{name}'],cwd=root)).hexdigest()==expected
assert len(manifest['fixture_inputs'])==752 and len(packages['package_inputs'])==749
assert result['summary']=='pass' and result['stage']=='complete' and len(result['passed'])==4
assert result['package_version']=='0.4.14+healthui.1' and result['authority_schema']==14
assert result['fixture_sha256']==manifest['guest']['p04_stacks_browser_guest.py']
assert result['packages']==packages['packages'] and result['binaries']=={name:row['sha256'] for name,row in packages['binaries'].items()}
assert {'frontend/dist/'+name:value for name,value in result['ui'].items()}==packages['ui']
assert result['immutable_before']==result['immutable_after'] and result['source_before']==result['source_after']
assert all(value==0 for value in result['authority_final'].values())
assert result['oom_before']==result['oom_after']=={'oom_kill':0}
assert len(result['members'])==16 and sum(row['running'] for row in result['members'])==8
assert sum(row['stack'] is None for row in result['members'])==1
assert len(result['states']['maximum']['stacks'])==8
assert all(sum(service['declared'] for service in stack['services'])==16 for stack in result['states']['maximum']['stacks'])
assert len(next(row for row in result['states']['maximum']['stacks'] if row['stack']=='fixture6')['services'])==17
resources=result['resources']
assert resources['samples']>0 and not resources['errors'] and resources['memory_peak']<64*1024**2 and resources['tasks_maximum']<=16 and resources['sampled_fd_maximum']<=256
assert {'manager','guardian','worker'}.issubset({row['role'] for row in resources['processes'].values()})
assert cleanup['unique_pids']==10 and cleanup['all_recorded_original_processes_absent'] and all(row['absent'] for row in cleanup['vm_scratch'])
for name,expected in packages['repository'].items():assert sha(builders/'candidate-14/repository'/name)==expected
for n in (1,2):
 frozen=read(state/f'inputs-{n}.json')
 for name,expected in frozen['guest'].items():assert sha(state/f'guest-{n}'/name)==expected
assert sha(state/'run_1024.py')==manifest['runner_sha256']==sha(root/'tests/privileged_vm/run.py')
out.mkdir(exist_ok=False)
def archive(name,path):
 target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for phase in records:
 for name in ('record.json','output.log'):archive('checks/b2-installed-stack-'+phase+'-'+name,root/'.cache/main-consolidation/attempts'/('b2-installed-stack-'+phase)/name)
for path in sorted(state.iterdir()):
 if path.is_file() and path.suffix in ('.json','.log','.txt'):archive('observations/'+path.name,path)
archive('package-inputs.json',builders/'candidate-14/inputs.json')
archive('original-build-record.json',builders/'build-12/record.json')
for name in ('dists/stable/InRelease','dists/stable/Release','dists/stable/Release.gpg','dists/stable/main/binary-amd64/Packages','limeos-archive-keyring.gpg'):archive('repository/'+name,builders/'candidate-14/repository'/name)
sources={f'guest-{n}/'+path.name:path for n in (1,2) for path in sorted((state/f'guest-{n}').glob('*.py'))}
sources.update({'harness/'+path.name:path for path in sorted(state.glob('*.py'))})
sources['harness/guard.py']=root/'.cache/main-consolidation/guard.py'
sources['harness/detached_guard.py']=builders/'detached_guard.py'
sources['reference/test_p04_stacks_browser_guest.py']=root/'tests/reference/test_p04_stacks_browser_guest.py'
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
 for name,path in sorted(sources.items()):
  data=path.read_bytes();item=tarfile.TarInfo(name);item.size,item.mode,item.mtime=len(data),0o644,0
  tar.addfile(item,io.BytesIO(data))
(out/'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
(out/'screenshots').mkdir();shots={}
assert len(result['screenshots'])==5
for name,value in result['screenshots'].items():
 data=base64.b64decode(value['png_base64'],validate=True);width,height=struct.unpack('!II',data[16:24]);geometry=value['geometry']
 assert data[:8]==b'\x89PNG\r\n\x1a\n' and hashlib.sha256(data).hexdigest()==value['sha256']
 assert abs(width-geometry['target_width'])<=1 and abs(height-geometry['target_height'])<=1
 assert geometry['page_width']<=geometry['viewport_width']+1
 (out/'screenshots'/f'{name}.png').write_bytes(data)
 shots[name]={key:value[key] for key in ('selector','geometry','sha256')}
 shots[name].update(width=width,height=height,file=f'screenshots/{name}.png')
(out/'installed-result.json').write_text(json.dumps({**result,'screenshots':shots},indent=2)+'\n')
summary=dict(fixture_source=head,package_source=packages['source'],ui_source=packages['ui_source'],binary_source=packages['binary_source'],fixture_inputs=752,package_inputs=749,
 test_only_changes_between_package_and_fixture=manifest['test_only_changes_between_package_and_fixture'],test_only_additions_since_package=manifest['test_only_additions_since_package'],
 native_reference_cases=26,earlier_native_cases=25,canonical_runner_unchanged=True,guest_modules_per_attempt=36,
 checks={phase:{key:row[key] for key in ('started','ended','exit_code','minimum_available_bytes','guard_triggered','inputs_unchanged')} for phase,row in records.items()},
 covered_stack_api_ui_layout_flow_passed=True,full_b2_p04_cutover_qualified=False,original_native_pids_absent=10,owned_vm_scratch_removed=2)
(out/'source-match.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(source=head,resources={key:resources[key] for key in ('samples','memory_peak','tasks_maximum','sampled_fd_maximum')},screenshots=shots)))
