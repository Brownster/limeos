# /// script
# dependencies = []
# ///
import hashlib
import json
from pathlib import Path
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
log=root/'.cache/main-consolidation/attempts/b2-installed-stack-vm-1/output.log'
lines=[line.removeprefix('B2_STACK_FAILURE ') for line in log.read_text().splitlines() if line.startswith('B2_STACK_FAILURE ')]
assert len(lines)==1
failure=json.loads(lines[0]);assert failure['summary']=='fail'
with (state/'failure-1.json').open('x') as stream:stream.write(lines[0]+'\n')
print(json.dumps(dict(stage=failure['stage'],error_type=failure['error_type'],passed=failure['passed'],resource_errors=failure.get('resources',{}).get('errors'),memory_peak=failure.get('resources',{}).get('memory_peak'),last_catalog=failure.get('last_api',{}).get('catalog'),source_log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())))
value=(state/'check_reference.py').read_text().replace('reference-step-','reference-2-step-').replace('reference-checks.json','reference-2-checks.json')
(state/'check_reference_2.py').write_text(value)
value=(state/'launch.py').read_text().replace("'reference-1':", "'reference-2':").replace("state/'check_reference.py'", "state/'check_reference_2.py'")
(state/'launch_reference_2.py').write_text(value)
