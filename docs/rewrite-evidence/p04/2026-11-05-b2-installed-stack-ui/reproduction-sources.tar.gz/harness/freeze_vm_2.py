# /// script
# dependencies = []
# ///
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
native_path=root/'.cache/main-consolidation/attempts/b2-installed-stack-reference-2/record.json'
native=json.loads(native_path.read_text())
assert native['exit_code']==0 and native['inputs_unchanged'] and not native['guard_triggered'] and native['ended']
assert native['before']==native['after']
packages=json.loads((root/'.cache/stack-installed-qualification/candidate-14/inputs.json').read_text())
current=native['before'];original=packages['package_inputs']
changes={name:dict(before=expected,after=current[name]) for name,expected in original.items() if current[name]!=expected}
additions={name:expected for name,expected in current.items() if name not in original}
assert len(current)==752
assert set(changes)=={'tests/privileged_vm/p04_automation_browser_guest.py','tests/reference/test_p04_automation_browser_guest.py'}
assert set(additions)=={'tests/privileged_vm/p04_stacks_browser_guest.py','tests/privileged_vm/p04_reader_resources.py','tests/reference/test_p04_stacks_browser_guest.py'}
for name,expected in current.items():
 assert sha(root/name)==expected
 assert hashlib.sha256(subprocess.check_output(['git','show',f'{head}:{name}'],cwd=root)).hexdigest()==expected
for name,expected in packages['repository'].items():assert sha(root/'.cache/stack-installed-qualification/candidate-14/repository'/name)==expected
guest=state/'guest-2';guest.mkdir(exist_ok=False)
for path in sorted((root/'tests/privileged_vm').glob('*.py')):shutil.copyfile(path,guest/path.name)
(guest/'installed_guest.py').write_text('import p04_stacks_browser_guest as guest\nguest.main(package_version='+repr(packages['version'])+')\n')
manifest=json.loads((state/'inputs-1.json').read_text())
assert sha(state/'run_1024.py')==manifest['runner_sha256']==sha(root/'tests/privileged_vm/run.py')
manifest.update(fixture_source=head,fixture_inputs=current,native_record_sha256=sha(native_path),test_only_changes_between_package_and_fixture=changes,test_only_additions_since_package=additions,guest={path.name:sha(path) for path in sorted(guest.glob('*.py'))})
with (state/'inputs-2.json').open('x') as stream:stream.write(json.dumps(manifest,indent=2)+'\n')
for source,target in [('launch_vm.py','launch_vm_2.py'),('observe_vm.py','observe_vm_2.py')]:
 value=(state/source).read_text()
 for before,after in [('vm-1','vm-2'),('guest-1','guest-2'),('inputs-1.json','inputs-2.json'),('result-1','result-2'),('admission-1','admission-2'),('guard-console-1','guard-console-2'),('guard-launch-1','guard-launch-2')]:value=value.replace(before,after)
 with (state/target).open('x') as stream:stream.write(value)
print(json.dumps(dict(fixture=head,package=packages['source'],inputs=len(current),guest_modules=len(manifest['guest']))))
