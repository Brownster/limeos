import p04_stacks_browser_guest as guest
guest.main(package_version='0.4.14+healthui.1')
