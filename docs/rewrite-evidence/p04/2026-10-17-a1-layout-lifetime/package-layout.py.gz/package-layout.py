# /// script
# dependencies = []
# ///
"""Record the cleanup-phase correction without rewriting the original packet."""

import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/a1-ui"
packet = root / "docs/rewrite-evidence/p04/2026-10-17-a1-layout-lifetime"
old = root / "docs/rewrite-evidence/p04/2026-10-17-a1-ui-lifetime"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
subprocess.run(["git", "diff", "--exit-code", "HEAD", "--", "frontend"], check=True)
inputs = [
    line.split("  ", 1) for line in (old / "inputs.sha256").read_text().splitlines()
]
changed = [path for sha, path in inputs if digest(root / path) != sha]
assert changed == ["frontend/src/storage/StorageMounts.tsx"], changed
(packet / "inputs.sha256").write_text(
    "".join(f"{digest(root / path)}  {path}\n" for _, path in inputs)
)
dependencies = [
    root.parents[1] / "frontend/node_modules" / path
    for path in [
        "react-dom/package.json",
        "react-dom/cjs/react-dom.development.js",
        "react-dom/cjs/react-dom.production.min.js",
    ]
]
(packet / "dependencies.sha256").write_text(
    "".join(f"{digest(path)}  {path}\n" for path in dependencies)
)
results = json.loads((cache / "frontend-results.json").read_text())
assert results["tests"] == 129
assert "built in" in (cache / "layout-production-build.log").read_text()
assert not (root / "frontend/node_modules").exists()
for path in (root / "frontend/dist").rglob("*"):
    if path.is_file():
        dest = packet / "production-ui" / path.relative_to(root / "frontend/dist")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
for path in sorted(cache.iterdir()):
    if path.name.startswith("frontend-") or path.name in {
        "layout-frontend-summary.log",
        "layout-production-build.log",
        "package-layout.py",
        "check-frontend.py",
    }:
        (packet / (path.name + ".gz")).write_bytes(
            gzip.compress(path.read_bytes(), mtime=0)
        )
(packet / "metadata.json").write_text(
    json.dumps(
        {
            "source": source,
            "previous_product": "7bdc36b4bd297ce80e4837c72ac96c07e9938ddd",
            "input_count": len(inputs),
            "changed_inputs": changed,
            "frontend": results,
            "new_cases": 0,
            "source_review": "Pinned React DOM 18.3.1 layout destruction versus passive flush",
            "commands": [
                "uv run --offline --no-project .cache/a1-ui/check-frontend.py",
                "npm run build (frontend)",
            ],
            "browser_tests": "unrun; prior packet records unavailable browser surface",
            "limitations": "No new runtime, browser, installed, physical mount or recovery acceptance",
        },
        indent=2,
    )
    + "\n"
)
artifacts = sorted(
    path
    for path in packet.rglob("*")
    if path.is_file() and path.name != "artifacts.sha256"
)
(packet / "artifacts.sha256").write_text(
    "".join(f"{digest(path)}  {path.relative_to(packet)}\n" for path in artifacts)
)
print(
    json.dumps({"source": source, "inputs": len(inputs), "artifacts": len(artifacts)})
)
