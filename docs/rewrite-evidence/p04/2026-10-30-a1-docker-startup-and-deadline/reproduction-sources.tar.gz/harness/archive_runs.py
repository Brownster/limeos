# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Seal both original, continuously guarded candidate-11 failures."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-fd-context-qualification'
BUILDERS = ROOT / '.cache/stack-installed-qualification'
OUT = ROOT / 'docs/rewrite-evidence/p04/2026-10-30-a1-docker-startup-and-deadline'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def archive(name, path):
    target = OUT / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
build = json.loads((BUILDERS / 'build-11/record.json').read_text())
packages = json.loads((BUILDERS / 'candidate-11/inputs.json').read_text())
assert head == build['source'] == packages['source']
assert build['exit_code'] == 0 and build['inputs_unchanged'] and build['container_removed']
assert not build['oom_killed'] and build['stop_reason'] is None
for name, expected in build['before'].items():
    assert sha(ROOT / name) == expected, name
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=ROOT)).hexdigest() == expected, name
for name, expected in packages['repository'].items():
    assert sha(BUILDERS / 'candidate-11/repository' / name) == expected, name
for name, expected in json.loads((STATE / 'preserved-attempt-1.json').read_text())['files'].items():
    assert sha(ROOT / name) == expected, name

runs = []
fixtures = []
for number, ram, runner in ((1, 384, 'run_384.py'), (2, 1024, 'run_1024.py')):
    fixture = json.loads((STATE / f'inputs-{number}.json').read_text())
    fixtures.append(fixture)
    assert fixture['product_source'] == head and fixture['guest_memory_mib'] == ram
    for name, expected in fixture['guest'].items():
        assert sha(STATE / 'guest-1' / name) == expected, name
    for name, expected in fixture['runner_support'].items():
        assert sha(STATE / name) == expected, name
    assert sha(STATE / runner) == fixture['runner_sha256']
    attempt = ROOT / f'.cache/main-consolidation/attempts/a1-fd-context-vm-{number}'
    record = json.loads((attempt / 'record.json').read_text())
    assert record['head'] == head and record['before'] == record['after'] == build['before']
    assert record['exit_code'] == 1 and record['ended'] and record['inputs_unchanged']
    assert not record['guard_triggered']
    log = (attempt / 'output.log').read_text()
    failure = next(json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith('A1_FAILURE '))
    assert failure['authority_schema'] == 12 and failure['package_version'] == packages['version']
    assert failure['schema_source_sha256'] == fixture['schema_source_sha256']
    assert failure['fixture_sha256'] == fixture['guest']['p04_mounts_guest.py']
    for name, expected in failure['binary_sha256'].items():
        assert packages['binaries'][name]['sha256'] == expected, name
    scratch = set(re.findall(r'/home/marc/Documents/github/lime-os/\.cache/main-consolidation/tmp/limeos-p01-vm-[a-z0-9_]+', log))
    assert len(scratch) == 1 and all(not Path(path).exists() for path in scratch)
    if number == 1:
        assert failure['stage'] == 'await_terminal_receipt' and failure['job']['state'] == 'needs_intervention'
        assert '"phase":"recheck.configuration.before","failure":"TimedOut"' in failure['unit_diagnostics']
        assert 'A1_ADMISSION_DIAGNOSTIC_RECORDS=0' in log
        actual = 'original configuration lifetime expired; Core job needs_intervention'
    else:
        assert failure['stage'] == 'pre_effect_api_refusals'
        assert 'action' not in failure and 'job' not in failure
        diagnostics = [json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith('A1_ADMISSION_DIAGNOSTIC ')]
        assert len(diagnostics) == 1
        event = diagnostics[0]
        assert event['event'] == 'storage_mount_consumer_tasks_changed'
        assert event['phase'] == 'scan.recheck.user_tasks' and event['removed_count'] == 0 and event['added_count'] == 1
        added = event['added'][0]
        assert added == {'pid': 7043, 'tid': 7420, 'start': 23684, 'namespace': [4, 4026531841]}
        assert added['pid'] == failure['docker']['peer']['pid']
        actual = 'authenticated fixture Docker daemon added task 7043/7420, start 23684, namespace (4,4026531841)'
    runs.append({key: record[key] for key in ('started', 'ended', 'exit_code', 'minimum_available_bytes', 'inputs_unchanged', 'guard_triggered')}
                | {'guest_memory_mib': ram, 'stage': failure['stage'], 'actual_refusal': actual,
                   'vm_scratch_removed': True, 'a1_accepted': False})
assert fixtures[0]['guest'] == fixtures[1]['guest']
assert fixtures[1]['comparison_parent_inputs_sha256'] == sha(STATE / 'inputs-1.json')
assert fixtures[1]['preserved_parent_attempt_sha256'] == sha(STATE / 'preserved-attempt-1.json')
assert sha(STATE / 'run_1024.py') == sha(ROOT / 'tests/privileged_vm/run.py')
OUT.mkdir(exist_ok=False)
for name in ('record.json', 'output.log', 'binaries.json', 'source-before.log', 'source-after.log'):
    archive('build/' + name, BUILDERS / 'build-11' / name)
for label in ('a1-fd-context-ui-build-1', 'a1-fd-context-packages-1', 'a1-fd-context-vm-1', 'a1-fd-context-vm-2'):
    for name in ('record.json', 'output.log'):
        archive('checks/' + label + '-' + name, ROOT / '.cache/main-consolidation/attempts' / label / name)
archive('package-inputs.json', BUILDERS / 'candidate-11/inputs.json')
for number in (1, 2):
    for name in (f'inputs-{number}.json', f'admission-{number}.json', f'guard-launch-{number}.json',
                 f'guard-console-{number}.log', f'result-{number}-vm-failure.txt', f'result-{number}-startup-console.txt'):
        archive(name, STATE / name)
archive('preserved-attempt-1.json', STATE / 'preserved-attempt-1.json')
files = {'guest/' + p.name: p for p in sorted((STATE / 'guest-1').glob('*.py'))}
files.update({'runner/' + n: STATE / n for n in ('run_384.py', 'run_1024.py', 'current_authority_schema.py')})
files.update({'harness/' + n: BUILDERS / n for n in ('build_candidate_11.py', 'build_inside.py', 'prepare_packages_11.py',
    'prepare_fd_context_guest.py', 'launch_fd_context_vm.py', 'launch_fd_context_vm_2.py',
    'detached_guard.py', 'prepare_launch_fd_context_vm.py')})
files.update({'harness/' + n: STATE / n for n in ('archive_runs.py', 'prepare_canonical_guest_2.py')})
files['harness/guard.py'] = ROOT / '.cache/main-consolidation/guard.py'
for name in ('bins/executor/src/main.rs', 'bins/executor/src/storage_mount_admission.rs', 'bins/executor/src/storage_runtime.rs',
             'crates/persistence/src/lib.rs', 'crates/executor-storage/src/mount_admission/host_consumers.rs'):
    files['source/' + name] = ROOT / name
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        tar.addfile(info, io.BytesIO(data))
(OUT / 'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
summary = {'source': head, 'recorded_inputs_match_commit': len(build['before']), 'runs': runs,
           'guest_modules_unchanged': len(fixtures[0]['guest']), 'packages': packages['packages'],
           'binaries': packages['binaries'], 'a1_accepted': False, 'causal_memory_conclusion': False,
           'earlier_unknown_fd_owners_identified': False, 'installed_ui_qualification': False,
           'upgrade_qualification': False, 'production_pi_accessed': False}
(OUT / 'source-match.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'source': head, 'runs': runs, 'a1_accepted': False}))
