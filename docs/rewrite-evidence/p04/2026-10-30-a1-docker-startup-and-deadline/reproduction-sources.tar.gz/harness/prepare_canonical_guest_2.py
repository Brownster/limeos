# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Freeze the original one-GiB runner while preserving the failed small guest."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-fd-context-qualification'
VM = ROOT / '.cache/main-consolidation/attempts/a1-fd-context-vm-1'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
assert not (STATE / 'inputs-2.json').exists()
record = json.loads((VM / 'record.json').read_text())
original = json.loads((STATE / 'inputs-1.json').read_text())
assert record['exit_code'] == 1 and record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
assert record['before'] == record['after']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == original['product_source'] == record['head']
for name, expected in record['before'].items():
    assert sha(ROOT / name) == expected, name
for name, expected in original['guest'].items():
    assert sha(STATE / 'guest-1' / name) == expected, name
failure = next(json.loads(line.partition(' ')[2]) for line in (VM / 'output.log').read_text().splitlines() if line.startswith('A1_FAILURE '))
assert failure['stage'] == 'await_terminal_receipt' and failure['job']['state'] == 'needs_intervention'
assert '"phase":"recheck.configuration.before","failure":"TimedOut"' in failure['unit_diagnostics']
files = {str(path.relative_to(ROOT)): sha(path) for path in
         [VM / 'record.json', VM / 'output.log', STATE / 'inputs-1.json',
          STATE / 'admission-1.json', STATE / 'guard-launch-1.json', STATE / 'guard-console-1.log',
          STATE / 'result-1-vm-failure.txt', STATE / 'result-1-startup-console.txt']}
preserved = {'source': original['product_source'], 'files': files,
             'failure_stage': failure['stage'], 'job_state': failure['job']['state'],
             'action': failure['action'], 'result_accepted': False,
             'operation_replay_permitted': False}
(STATE / 'preserved-attempt-1.json').write_text(json.dumps(preserved, indent=2) + '\n')
canonical = ROOT / 'tests/privileged_vm/run.py'
assert sha(canonical) == original['guest']['run.py']
runner = STATE / 'run_1024.py'
assert not runner.exists()
runner.write_bytes(canonical.read_bytes())
manifest = dict(original)
manifest.update(guest_memory_mib=1024, runner_sha256=sha(runner),
                only_runner_change='none: exact committed canonical runner, 1024-MiB non-build guest',
                comparison_parent_inputs_sha256=sha(STATE / 'inputs-1.json'),
                preserved_parent_attempt_sha256=sha(STATE / 'preserved-attempt-1.json'),
                comparison_preparer_sha256=sha(Path(__file__)),
                controlled_fixture_change='guest RAM 384 to canonical 1024 MiB; product, 31 guest modules, packages, service limits and deadlines unchanged',
                causal_memory_conclusion=False, operation_replay=False)
(STATE / 'inputs-2.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'source': original['product_source'], 'guest_memory_mib': 1024,
                  'runner_exactly_matches_committed_source': True, 'guest_modules_unchanged': len(original['guest']),
                  'previous_failure_preserved': True, 'earlier_action_replayed': False}))
