# /// script
# dependencies = []
# ///
import hashlib
import json
from pathlib import Path
state = Path(__file__).parent
manifest = json.loads((state / 'inputs-2.json').read_text())
assert all(hashlib.sha256((state / 'guest-2' / name).read_bytes()).hexdigest() == expected for name,expected in manifest['guest'].items())
for source, destination in [('launch_vm.py','launch_vm_2.py'), ('observe_vm.py','observe_vm_2.py')]:
 value = (state / source).read_text()
 for before,after in [('vm-1','vm-2'),('guest-1','guest-2'),('inputs-1.json','inputs-2.json'),('result-1','result-2'),('admission-1','admission-2'),('guard-console-1','guard-console-2'),('guard-launch-1','guard-launch-2')]: value=value.replace(before,after)
 with (state / destination).open('x') as stream: stream.write(value)
print('Completed attempt2 launch helpers without recreating frozen inputs or guest files')
