# /// script
# dependencies = []
# ///
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

root=Path('/home/marc/Documents/github/lime-os')
state=Path(__file__).parent
out=root/'docs/rewrite-evidence/p04/2026-11-05-b1-installed-browser'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert not (out/'SHA256SUMS').exists()
manifest=json.loads((state/'inputs-2.json').read_text())
assert all(sha(root/name)==expected for name,expected in manifest['fixture_inputs'].items())
result=json.loads((out/'installed-result.json').read_text())
assert result['summary']=='pass' and result['stage']=='complete'
assert result['immutable_before']==result['immutable_after']
assert result['before_restart']==result['after_restart']
assert result['oom_before']==result['oom_after']=={'oom_kill':0}
schedule=result['schedule_id']; opening=result['opening']; recovery=result['recovery']
assert opening['event']['key']==recovery['event']['key']=='container:'+result['container_id']
assert opening['event']['event']=='incident' and recovery['event']['event']=='recovery'
assert opening['event']['generation']==recovery['event']['generation']==1
assert all(row['channel']=='in_app' and row['attempts']==1 and row['delivery']['state']=='delivered' for row in (opening,recovery))
for path,expected in {
 '/api/v1/auth/login':[200,200], '/api/v1/auth/capabilities/observe-health/enable':[200],
 '/api/v1/automation/health-policy':[200], '/api/v1/automation/schedules':[403,201],
 '/api/v1/automation/notifications/'+opening['id']+'/acknowledgment':[200],
 '/api/v1/automation/schedules/'+schedule+'/pause':[200]}.items():
 assert [row['status'] for row in result['http'] if row['path']==path and row['method']=='POST']==expected
assert all(set(row)=={'method','path','status'} for row in result['http'])
assert len(result['restarts'])==2
pids=[result['restarts'][0]['before_pid'],int(result['restarts'][0]['after']['MainPID']),int(result['restarts'][1]['after']['MainPID'])]
assert len(set(pids))==3 and result['restarts'][1]['before_pid']==pids[1]
assert all(sha(out/value['file'])==value['sha256'] for value in result['screenshots'].values())
checks=[]
for command in ([sys.executable,'scripts/check_repository.py'],['git','diff','--check']):
 value=subprocess.run(command,cwd=root,text=True,capture_output=True)
 checks.append(dict(command=command,exit_code=value.returncode,stdout=value.stdout,stderr=value.stderr))
 assert value.returncode==0
links=[]
for document in (out/'README.md',root/'docs/p04-b1-observation-supervisor-handoff.md',root/'docs/rewrite-evidence/p04/2026-10-05-execution-tracker.md'):
 for target in re.findall(r'\]\(([^)]+)\)',document.read_text()):
  if '://' in target or target.startswith('#'): continue
  assert (document.parent/target.partition('#')[0]).exists(),(document,target)
  links.append(dict(document=str(document.relative_to(root)),target=target))
for path in out.rglob('*.gz'): gzip.decompress(path.read_bytes())
with tarfile.open(out/'reproduction-sources.tar.gz','r:gz') as archive:
 names=archive.getnames()
 assert all(not name.startswith('/') and '..' not in Path(name).parts for name in names)
 for n in (1,2):
  frozen=json.loads((state/f'inputs-{n}.json').read_text())
  assert len([name for name in names if name.startswith(f'guest-{n}/')])==34
  for name,expected in frozen['guest'].items(): assert hashlib.sha256(archive.extractfile(f'guest-{n}/'+name).read()).hexdigest()==expected
verification=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),current_fixture_inputs_match=749,commands=checks,relative_links_checked=len(links),links=links,gzip_files_readable=True,reproduction_members=len(names),installed_browser_http_restart_and_provenance_joins_verified=True,core_pids=pids,sealer_sha256=sha(Path(__file__)))
(out/'final-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(out/'seal-source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
files=sorted(path for path in out.rglob('*') if path.is_file())
(out/'SHA256SUMS').write_text(''.join(sha(path)+'  '+str(path.relative_to(out))+'\n' for path in files))
for line in (out/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1)
 assert sha(out/name)==expected
print(json.dumps(dict(verified_files=len(files),inputs=749,relative_links=len(links),installed_browser_flow_verified=True)))
