# /// script
# dependencies = []
# ///
from pathlib import Path
state = Path(__file__).parent
for source, destination in [('check_reference_3.py', 'check_reference_4.py'), ('launch_reference_3.py', 'launch_reference_4.py')]:
 value = (state / source).read_text().replace('reference-3', 'reference-4').replace('reference_3', 'reference_4')
 (state / destination).write_text(value)
