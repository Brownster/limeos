# /// script
# dependencies = []
# ///
import datetime
import json
from pathlib import Path
import subprocess
import sys
root = Path('/home/marc/Documents/github/lime-os')
state = Path(__file__).parent
files = ['tests/privileged_vm/p04_automation_browser_guest.py', 'tests/reference/test_p04_automation_browser_guest.py']
commands = [
 [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_p04_automation_browser_guest.py', '-v'],
 [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_p04_automation_guest.py', '-v'],
 [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_core_reader_profile.py', '-v'],
 ['uv', 'run', '--offline', '--no-project', '--cache-dir', '.cache/uv', '--with', 'ruff', 'ruff', 'check', *files],
 ['uv', 'run', '--offline', '--no-project', '--cache-dir', '.cache/uv', '--with', 'ruff', 'ruff', 'format', '--check', *files],
 [sys.executable, 'scripts/check_repository.py'], ['git', 'diff', '--check']]
results = []
for index, command in enumerate(commands, 1):
 started = datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (state / f'reference-2-step-{index}.log').open('xb') as log:
  value = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
 results.append(dict(command=command, started=started, ended=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=value.returncode))
 (state / 'reference-2-checks.json').write_text(json.dumps(results, indent=2) + '\n')
 print(json.dumps(results[-1]), flush=True)
 if value.returncode:
  print((state / f'reference-2-step-{index}.log').read_text()[-6000:], flush=True)
  raise SystemExit(value.returncode)
