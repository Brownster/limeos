# /// script
# dependencies = []
# ///
"""Record only this guard's original owned runner/QEMU identities."""
import datetime
import json
import os
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-installed-browser-qualification'
attempt = root / '.cache/main-consolidation/attempts/b1-installed-browser-vm-1'
launch = json.loads((state / 'guard-launch-1.json').read_text())
record = json.loads((attempt / 'record.json').read_text())

def identity(pid):
    directory = Path('/proc') / str(pid)
    try:
        raw = (directory / 'stat').read_text()
        fields = raw[raw.rindex(')') + 1:].split()
        command = (directory / 'cmdline').read_bytes().rstrip(b'\0').split(b'\0')
        return {'pid': pid, 'start_ticks': int(fields[19]), 'state': fields[0],
                'parent': int(fields[1]), 'session': os.getsid(pid),
                'process_group': os.getpgid(pid),
                'command': [part.decode(errors='replace') for part in command],
                'children': [int(x) for x in (directory / 'task' / str(pid) / 'children').read_text().split()]}
    except (FileNotFoundError, ProcessLookupError):
        return {'pid': pid, 'absent': True}

wrapper = identity(launch['pid'])
runner = identity(record['pid'])
assert wrapper.get('absent') or wrapper['start_ticks'] == launch['start_ticks']
qemu = []
for pid in runner.get('children', []):
    child = identity(pid)
    command = child.get('command', [])
    if command and Path(command[0]).name == 'qemu-system-x86_64':
        assert child['parent'] == runner['pid']
        # The immutable guard creates a second session for the runner.
        assert runner['session'] == runner['process_group'] == runner['pid']
        assert child['session'] == runner['session']
        assert command[command.index('-m') + 1] == '1024'
        assert any(str(root / '.cache/main-consolidation/tmp/limeos-p01-vm-') in arg for arg in command)
        qemu.append(child)
value = {'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'wrapper': wrapper, 'runner': runner, 'qemu': qemu,
         'guard_ended': record.get('ended'), 'guard_exit_code': record.get('exit_code')}
output = state / ('vm-process-observation-' + str(len(list(state.glob('vm-process-observation-*.json'))) + 1) + '.json')
with output.open('x') as stream:
    json.dump(value, stream, indent=2)
    stream.write('\n')
print(json.dumps(value))
