# /// script
# dependencies = []
# ///
from pathlib import Path
state = Path(__file__).parent
for source, destination in [('check_reference_2.py', 'check_reference_3.py'), ('launch_reference_2.py', 'launch_reference_3.py')]:
 value = (state / source).read_text().replace('reference-2', 'reference-3').replace('reference_2', 'reference_3')
 (state / destination).write_text(value)
