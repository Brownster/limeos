# /// script
# dependencies = []
# ///
import datetime
import json
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = Path(__file__).parent
attempts = root / '.cache/main-consolidation/attempts'
records = [json.loads((attempts / ('b1-installed-browser-reference-' + str(n)) / 'record.json').read_text()) for n in range(1,5)]
records.append(json.loads((attempts / 'b1-installed-browser-vm-1/record.json').read_text()))
assert all(row.get('ended') and row['inputs_unchanged'] and not row['guard_triggered'] for row in records)
identities = []
for n in range(1,5):
 name = 'reference-launch.json' if n == 1 else 'reference-' + str(n) + '-launch.json'
 identities.append(json.loads((state / name).read_text()))
identities.append(json.loads((state / 'guard-launch-1.json').read_text()))
observed = json.loads((state / 'vm-process-observation-1.json').read_text())
identities += [observed['runner'], *observed['qemu']]
pids = sorted({row['pid'] for row in identities} | {row['pid'] for row in records})
absent = [{'pid':pid, 'absent':not (Path('/proc') / str(pid)).exists()} for pid in pids]
scratch = root / '.cache/main-consolidation/tmp/limeos-p01-vm-n38o_kk0'
assert all(row['absent'] for row in absent)
assert not scratch.exists()
value = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(), processes=absent, unique_pids=len(pids), all_recorded_original_processes_absent=True, vm_scratch=[dict(path=str(scratch),absent=True)], unrelated_processes_stopped=False)
with (state / 'cleanup-1.json').open('x') as stream: stream.write(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
