# /// script
# dependencies = []
# ///
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path('/home/marc/Documents/github/lime-os')
state = Path(__file__).parent
builders = root / '.cache/stack-installed-qualification'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
native = json.loads((root / '.cache/main-consolidation/attempts/b1-installed-browser-reference-4/record.json').read_text())
package_native = json.loads((root / '.cache/main-consolidation/attempts/b1-core-reader-fix-package-1/record.json').read_text())
packages = json.loads((builders / 'candidate-13/inputs.json').read_text())
build = json.loads((builders / 'build-12/record.json').read_text())
for record in [native, package_native]:
 assert record['exit_code'] == 0 and record['inputs_unchanged'] and not record['guard_triggered']
 assert record['before'] == record['after']
assert build['exit_code'] == 0 and build['inputs_unchanged'] and build['container_removed']
assert build['source'] == packages['binary_source']
assert set(native['before']) - set(package_native['before']) == {'tests/privileged_vm/p04_automation_browser_guest.py', 'tests/reference/test_p04_automation_browser_guest.py'}
for name, expected in package_native['before'].items(): assert native['before'][name] == expected
for name, expected in native['before'].items():
 assert sha(root / name) == expected
 assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=root)).hexdigest() == expected
for name, expected in build['before'].items():
 change = packages['production_changes_since_binary_build'].get(name)
 assert native['before'][name] == (change['after'] if change else expected)
 if change: assert change['before'] == expected
assert set(packages['production_changes_since_binary_build']) == {'packaging/systemd/limeos-core.service'}
for name, expected in packages['repository'].items(): assert sha(builders / 'candidate-13/repository' / name) == expected
guest = state / 'guest-1'
guest.mkdir(exist_ok=False)
for path in sorted((root / 'tests/privileged_vm').glob('*.py')): shutil.copyfile(path, guest / path.name)
(guest / 'installed_guest.py').write_text('import p04_automation_browser_guest as guest\nguest.main(package_version=' + repr(packages['version']) + ')\n')
for name, original in [('run_1024.py', 'run.py'), ('current_authority_schema.py', 'current_authority_schema.py')]: shutil.copyfile(root / 'tests/privileged_vm' / original, state / name)
manifest = dict(fixture_source=head, package_source=packages['source'], binary_source=packages['binary_source'], ui_source=packages['binary_source'], fixture_inputs=native['before'],
 package_inputs_sha256=sha(builders / 'candidate-13/inputs.json'), build_record_sha256=sha(builders / 'build-12/record.json'), native_record_sha256=sha(root / '.cache/main-consolidation/attempts/b1-installed-browser-reference-4/record.json'),
 test_only_additions_since_current_package={name:native['before'][name] for name in sorted(set(native['before']) - set(package_native['before']))},
 test_only_additions_since_binary_build={name:native['before'][name] for name in sorted(set(native['before']) - set(build['before']))},
 production_changes_since_binary_build=packages['production_changes_since_binary_build'], guest_memory_mib=1024, runner_sha256=sha(state / 'run_1024.py'),
 runner_support={'current_authority_schema.py':sha(state / 'current_authority_schema.py')}, schema_source_sha256=sha(root / 'crates/persistence/src/lib.rs'),
 guest={p.name:sha(p) for p in sorted(guest.glob('*.py'))}, scope='Installed AMD64 B1 browser journey with actual package UI/API/runtime; partial health coverage and inaccurate availability copy remain open')
with (state / 'inputs-1.json').open('x') as stream: stream.write(json.dumps(manifest, indent=2) + '\n')
old = root / '.cache/b1-core-reader-fix-qualification'
value = (old / 'launch_vm.py').read_text().replace('b1-core-reader-fix', 'b1-installed-browser')
start = value.index("for name, expected in build['before'].items():")
end = value.index("for name, expected in manifest['guest'].items():", start)
value = value[:start] + "for name, expected in manifest['fixture_inputs'].items(): assert sha(root / name) == expected\n" + value[end:]
with (state / 'launch_vm.py').open('x') as stream: stream.write(value)
with (state / 'observe_vm.py').open('x') as stream: stream.write((old / 'observe_vm.py').read_text().replace('b1-core-reader-fix', 'b1-installed-browser'))
print(json.dumps(dict(fixture_source=head, package_source=packages['source'], binary_source=packages['binary_source'], fixture_inputs=len(native['before']), package_inputs=len(package_native['before']), guest_modules=len(manifest['guest']))))
