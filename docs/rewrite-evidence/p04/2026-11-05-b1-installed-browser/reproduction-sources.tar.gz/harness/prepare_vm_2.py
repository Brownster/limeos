# /// script
# dependencies = []
# ///
from pathlib import Path
import subprocess
import sys
state = Path(__file__).parent
value = (state / 'freeze_vm.py').read_text().replace('reference-4', 'reference-5').replace('guest-1', 'guest-2').replace('inputs-1.json', 'inputs-2.json').replace('launch_vm.py', 'launch_vm_2.py').replace('observe_vm.py', 'observe_vm_2.py')
# Generate distinct one-shot launch and observation helpers; preserve attempt1.
value = value.replace(".replace('b1-core-reader-fix', 'b1-installed-browser')", ".replace('b1-core-reader-fix', 'b1-installed-browser').replace('vm-1', 'vm-2').replace('guest-1', 'guest-2').replace('inputs-1.json', 'inputs-2.json').replace('result-1', 'result-2').replace('admission-1', 'admission-2').replace('guard-console-1', 'guard-console-2').replace('guard-launch-1', 'guard-launch-2')")
value = value.replace(".replace('b1-core-reader-fix', 'b1-installed-browser'))", ".replace('b1-core-reader-fix', 'b1-installed-browser').replace('vm-1', 'vm-2').replace('guard-launch-1', 'guard-launch-2'))")
(state / 'freeze_vm_2.py').write_text(value)
subprocess.run([sys.executable, str(state / 'freeze_vm_2.py')], check=True)
