# /// script
# dependencies = []
# ///
from pathlib import Path
state = Path(__file__).parent
value = (state / 'check_reference.py').read_text().replace('reference-step-', 'reference-2-step-').replace('reference-checks.json', 'reference-2-checks.json')
(state / 'check_reference_2.py').write_text(value)
value = (state / 'launch_reference.py').read_text().replace('reference-1', 'reference-2').replace('check_reference.py', 'check_reference_2.py').replace('reference-admission.json', 'reference-2-admission.json').replace('reference-console.log', 'reference-2-console.log').replace('reference-launch.json', 'reference-2-launch.json')
(state / 'launch_reference_2.py').write_text(value)
