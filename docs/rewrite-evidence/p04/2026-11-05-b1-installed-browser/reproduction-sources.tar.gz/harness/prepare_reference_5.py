# /// script
# dependencies = []
# ///
from pathlib import Path
state = Path(__file__).parent
for source, destination in [('check_reference_4.py', 'check_reference_5.py'), ('launch_reference_4.py', 'launch_reference_5.py')]:
 value = (state / source).read_text().replace('reference-4', 'reference-5').replace('reference_4', 'reference_5')
 (state / destination).write_text(value)
