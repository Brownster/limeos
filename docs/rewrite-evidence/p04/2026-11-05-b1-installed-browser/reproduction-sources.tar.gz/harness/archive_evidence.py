# /// script
# dependencies = []
# ///
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import tarfile

root = Path('/home/marc/Documents/github/lime-os')
state = Path(__file__).parent
builders = root / '.cache/stack-installed-qualification'
attempts = root / '.cache/main-consolidation/attempts'
out = root / 'docs/rewrite-evidence/p04/2026-11-05-b1-installed-browser'
def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
manifest = read(state / 'inputs-2.json')
packages = read(builders / 'candidate-13/inputs.json')
build = read(builders / 'build-12/record.json')
result = read(state / 'result-2.json')
cleanup = read(state / 'cleanup-final.json')
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head == manifest['fixture_source']
assert packages['source'] == manifest['package_source']
assert packages['binary_source'] == packages['ui_source'] == manifest['binary_source'] == manifest['ui_source'] == build['source']
assert sha(builders / 'candidate-13/inputs.json') == manifest['package_inputs_sha256']
assert sha(builders / 'build-12/record.json') == manifest['build_record_sha256']
native = read(attempts / 'b1-installed-browser-reference-5/record.json')
vm = read(attempts / 'b1-installed-browser-vm-2/record.json')
for record in (native,vm):
 assert record['exit_code'] == 0 and record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
 assert record['before'] == record['after'] == manifest['fixture_inputs']
for name,expected in manifest['fixture_inputs'].items():
 assert sha(root / name) == expected
 assert hashlib.sha256(subprocess.check_output(['git','show',f'{head}:{name}'],cwd=root)).hexdigest() == expected
assert len(manifest['fixture_inputs']) == 749 and len(packages['package_inputs']) == 747
assert set(manifest['test_only_additions_since_current_package']) == {'tests/privileged_vm/p04_automation_browser_guest.py','tests/reference/test_p04_automation_browser_guest.py'}
for name,expected in packages['package_inputs'].items(): assert manifest['fixture_inputs'][name] == expected
assert result['summary'] == 'pass' and result['stage'] == 'complete' and len(result['passed']) == 3
assert result['package_version'] == packages['version'] and result['authority_schema'] == 14
assert result['fixture_sha256'] == manifest['guest']['p04_automation_browser_guest.py']
assert result['package_sha256'] == packages['packages']
for name,expected in result['binary_sha256'].items(): assert expected == packages['binaries'][name]['sha256']
assert {'frontend/dist/'+name:expected for name,expected in result['ui_sha256'].items()} == packages['ui']
assert result['immutable_before'] == result['immutable_after']
assert result['oom_before'] == result['oom_after'] == {'oom_kill':0}
assert result['before_restart'] == result['after_restart']
assert len(result['restarts']) == 2
assert result['opening']['event']['generation'] == result['recovery']['event']['generation'] == 1
assert result['opening']['delivery']['state'] == result['recovery']['delivery']['state'] == 'delivered'
history = result['final_history']
assert {key:len(value) for key,value in history.items()} == {'schedules':1,'occurrences':2,'jobs':2,'results':2,'alerts':1,'notifications':2}
assert history['schedules'][0][0] == result['schedule_id'] and history['schedules'][0][1:3] == [2,1]
assert len({tuple(row[:3]) for row in history['occurrences']}) == 2
assert history['occurrences'][1][2] - history['occurrences'][0][2] == 60
assert {row[3] for row in history['occurrences']} == {row[0] for row in history['jobs']} == {row[0] for row in history['results']}
assert all(row[1] == 'succeeded' for row in history['jobs'])
assert all(row[1:3] == ['succeeded','observed'] and row[4] == 0 for row in history['results'])
notes=[json.loads(row[2]) for row in history['notifications']]
assert [row for row in notes if row['id'] == result['opening']['id']][0]['acknowledged_at'] is not None
assert cleanup['all_recorded_original_processes_absent'] and all(row['absent'] for row in cleanup['vm_scratch'])
for name,expected in packages['repository'].items(): assert sha(builders / 'candidate-13/repository' / name) == expected
for n in (1,2):
 frozen=read(state / f'inputs-{n}.json')
 for name,expected in frozen['guest'].items(): assert sha(state / f'guest-{n}' / name) == expected
assert sha(state / 'run_1024.py') == manifest['runner_sha256'] == sha(root / 'tests/privileged_vm/run.py')
out.mkdir(exist_ok=False)
def archive(name,path):
 target=out/(name+'.gz'); target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
labels=['b1-installed-browser-reference-'+str(n) for n in range(1,6)] + ['b1-installed-browser-vm-'+str(n) for n in (1,2)]
for label in labels:
 for name in ('record.json','output.log'): archive('checks/'+label+'-'+name,attempts / label / name)
for path in sorted(state.iterdir()):
 if path.is_file() and path.suffix in ('.json','.log','.txt') and path.name != 'result-2.json': archive('observations/'+path.name,path)
archive('original-result-2.json',state / 'result-2.json')
archive('package-inputs.json',builders / 'candidate-13/inputs.json')
archive('original-build-record.json',builders / 'build-12/record.json')
for name in ('dists/stable/InRelease','dists/stable/Release','dists/stable/Release.gpg','dists/stable/main/binary-amd64/Packages','limeos-archive-keyring.gpg'): archive('repository/'+name,builders / 'candidate-13/repository' / name)
sources={f'guest-{n}/'+p.name:p for n in (1,2) for p in sorted((state/f'guest-{n}').glob('*.py'))}
sources.update({'harness/'+p.name:p for p in sorted(state.glob('*.py'))})
sources['harness/guard.py']=root/'.cache/main-consolidation/guard.py'
sources['harness/detached_guard.py']=builders/'detached_guard.py'
sources['reference/test_p04_automation_browser_guest.py']=root/'tests/reference/test_p04_automation_browser_guest.py'
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
 for name,path in sorted(sources.items()):
  data=path.read_bytes(); item=tarfile.TarInfo(name)
  item.size,item.mode,item.mtime=len(data),0o644,0
  tar.addfile(item,io.BytesIO(data))
(out/'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
shots={}
(out/'screenshots').mkdir()
for name,value in result['screenshots'].items():
 data=base64.b64decode(value['png_base64'],validate=True)
 assert data[:8]==b'\x89PNG\r\n\x1a\n' and hashlib.sha256(data).hexdigest()==value['sha256']
 dimensions=struct.unpack('!II',data[16:24])
 (out/'screenshots'/f'{name}.png').write_bytes(data)
 shots[name]=dict(sha256=value['sha256'],width=dimensions[0],height=dimensions[1],file=f'screenshots/{name}.png')
public={**result,'screenshots':shots}
(out/'installed-result.json').write_text(json.dumps(public,indent=2)+'\n')
summary=dict(fixture_source=head,package_source=packages['source'],binary_source=build['source'],ui_source=packages['ui_source'],fixture_input_count=749,package_input_count=747,original_binary_input_count=740,
 application_inputs_unchanged=True,test_only_additions_since_current_package=manifest['test_only_additions_since_current_package'],production_changes_since_binary_build=manifest['production_changes_since_binary_build'],
 native_reference_cases=18,canonical_runner_unchanged=True,guest_modules_per_attempt=34,installed_browser_control_flow_passed=True,truthful_status_copy_complete=False,b1_complete=False,arm64_pi_upgrade_return_soak_qualified=False,
 checks={name:{key:record[key] for key in ('started','ended','exit_code','minimum_available_bytes','guard_triggered','inputs_unchanged')} for name,record in [('reference5',native),('vm2',vm)]},
 original_native_pids_absent=cleanup['unique_pids'],owned_vm_scratch_removed=len(cleanup['vm_scratch']))
(out/'source-match.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(sources=head,screenshots=shots,final_counts={key:len(value) for key,value in history.items()})))
