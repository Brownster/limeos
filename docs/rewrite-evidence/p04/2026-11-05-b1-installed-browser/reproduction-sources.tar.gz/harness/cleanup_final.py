# /// script
# dependencies = []
# ///
import datetime
import json
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = Path(__file__).parent
attempts = root / '.cache/main-consolidation/attempts'
records = [json.loads((attempts / ('b1-installed-browser-reference-' + str(n)) / 'record.json').read_text()) for n in range(1,6)]
records += [json.loads((attempts / ('b1-installed-browser-vm-' + str(n)) / 'record.json').read_text()) for n in (1,2)]
assert all(row.get('ended') and row['inputs_unchanged'] and not row['guard_triggered'] for row in records)
identities = []
for name in ['reference-launch.json', *['reference-' + str(n) + '-launch.json' for n in range(2,6)], 'guard-launch-1.json', 'guard-launch-2.json']:
 identities.append(json.loads((state / name).read_text()))
scratch = set()
for path in sorted(state.glob('vm-process-observation-*.json')):
 observed = json.loads(path.read_text())
 identities += [observed['runner'], *observed['qemu']]
 for qemu in observed['qemu']:
  for arg in qemu['command']:
   if arg.startswith('file=') and '/disk.qcow2,format=' in arg:
    path = Path(arg.removeprefix('file=').split(',',1)[0]).parent
    assert path.parent == root / '.cache/main-consolidation/tmp' and path.name.startswith('limeos-p01-vm-')
    scratch.add(path)
assert len(scratch) == 2
pids = sorted({row['pid'] for row in identities} | {row['pid'] for row in records})
absent = [{'pid':pid, 'absent':not (Path('/proc') / str(pid)).exists()} for pid in pids]
assert all(row['absent'] for row in absent)
assert all(not path.exists() for path in scratch)
value = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(), processes=absent, unique_pids=len(pids), all_recorded_original_processes_absent=True, vm_scratch=[dict(path=str(path),absent=True) for path in sorted(scratch)], unrelated_processes_stopped=False)
with (state / 'cleanup-final.json').open('x') as stream: stream.write(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
