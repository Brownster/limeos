#!/usr/bin/env -S uv run --offline
# /// script
# dependencies = []
# ///
"""Create synthetic image metadata with independent hashlib content hashes."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
destination = root / "tests/fixtures/deployment/images"
destination.mkdir(parents=True, exist_ok=True)
hashes = {}


def write(name, value):
    data = (json.dumps(value, separators=(",", ":")) + "\n").encode()
    (destination / name).write_bytes(data)
    digest = "sha256:" + hashlib.sha256(data).hexdigest()
    hashes[name] = {"digest": digest, "size": len(data)}
    return {"digest": digest, "size": len(data)}


for family in ["oci", "docker"]:
    manifest_type = "application/vnd.oci.image.manifest.v1+json" if family == "oci" else "application/vnd.docker.distribution.manifest.v2+json"
    config_type = "application/vnd.oci.image.config.v1+json" if family == "oci" else "application/vnd.docker.container.image.v1+json"
    layer_type = "application/vnd.oci.image.layer.v1.tar+gzip" if family == "oci" else "application/vnd.docker.image.rootfs.diff.tar.gzip"
    entries = []
    for architecture in ["arm64", "amd64"]:
        config = {
            "architecture": architecture, "os": "linux",
            "config": {"Env": ["IMAGE_PRIVATE_VALUE=never-log-fixture"], "User": "1234:5678"},
            "rootfs": {"type": "layers", "diff_ids": ["sha256:" + "e" * 64, "sha256:" + "f" * 64]},
        }
        if architecture == "arm64":
            config["variant"] = "v8"
        configuration = write(f"{family}-{architecture}-config.json", config)
        manifest = {
            "schemaVersion": 2, "mediaType": manifest_type,
            "config": {"mediaType": config_type, **configuration},
            "layers": [{"mediaType": layer_type, "size": size, "digest": "sha256:" + letter * 64} for size, letter in [(1024, "c"), (2048, "d")]],
        }
        descriptor = write(f"{family}-{architecture}-manifest.json", manifest)
        platform = {"architecture": architecture, "os": "linux"}
        if architecture == "arm64":
            platform["variant"] = "v8"
        entries.append({"mediaType": manifest_type, **descriptor, "platform": platform})
    entries.append({"mediaType": manifest_type, "digest": "sha256:" + "a" * 64, "size": 100, "platform": {"architecture": "unknown", "os": "unknown"}, "annotations": {"vnd.docker.reference.type": "attestation-manifest"}})
    index_type = "application/vnd.oci.image.index.v1+json" if family == "oci" else "application/vnd.docker.distribution.manifest.list.v2+json"
    write(f"{family}-index.json", {"schemaVersion": 2, "mediaType": index_type, "manifests": entries})
(destination / "hashes.json").write_text(json.dumps(hashes, indent=2) + "\n")
print(f"Created {len(hashes)} synthetic metadata documents with hashlib SHA-256 sizes/digests")
