#!/usr/bin/env -S uv run --offline
# /// script
# dependencies = []
# ///
"""Package completed media leaf checks; never execute the frozen reference."""

import gzip
import hashlib
import json
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / ".cache/media-library-leaf"
PACKET = ROOT / "docs/rewrite-evidence/p04/2026-10-15-media-library-planning"
CODE = "5379d57bb2fd2b94e319ab17dc251405cc6fa0c1"
FROZEN = "80593b29443ea9b81eb60ed4e5c3c3ac7a236204"
REFERENCE = Path("/home/marc/Documents/github/pi-health")


def run(*args: str, cwd: Path = ROOT) -> bytes:
    return subprocess.check_output(args, cwd=cwd)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


assert run("git", "rev-parse", "HEAD").decode().strip() == CODE
files = (
    run(
        "git",
        "ls-files",
        "Cargo.toml",
        "Cargo.lock",
        "crates/domain",
        "crates/executor-container/Cargo.toml",
        "crates/executor-container/src/deployment/mod.rs",
        "crates/executor-container/src/deployment/media.rs",
        "crates/executor-container/src/deployment/media",
        "tests/fixtures/deployment/media",
        "tests/fixtures/deployment/catalog",
        "tests/fixtures/deployment/discovery",
        "tests/fixtures/storage-contracts.json",
    )
    .decode()
    .splitlines()
)
sources = {}
for name in files:
    data = (ROOT / name).read_bytes()
    assert data == run("git", "show", f"{CODE}:{name}"), name
    sources[name] = sha(data)
reference = {}
for name in [
    "media_seed_service.py",
    "media_layout.py",
    "storage_compatibility.py",
    "arr_client.py",
    "catalog/sonarr.yaml",
    "catalog/radarr.yaml",
    "catalog/lidarr.yaml",
    "catalog/jellyfin.yaml",
    "tests/test_media_seed_service.py",
    "tests/test_media_layout.py",
]:
    data = run("git", "show", f"{FROZEN}:{name}", cwd=REFERENCE)
    assert data == (REFERENCE / name).read_bytes(), name
    reference[name] = sha(data)
test = (CACHE / "test-final.log").read_text()
assert (
    "10 passed; 0 failed" in test
    and "53 passed; 0 failed" in test
    and "FAILED" not in test
)
assert "Finished `dev`" in (CACHE / "clippy.log").read_text()
assert "error:" not in (CACHE / "clippy.log").read_text()
assert (CACHE / "rustfmt.log").read_bytes() == b""
assert "All checks passed!" in (CACHE / "ruff.log").read_text()
assert "already formatted" in (CACHE / "ruff-format.log").read_text()
assert "FAILED" in (CACHE / "template-red.log").read_text()
for name in [
    "Cargo.toml",
    "Cargo.lock",
    "domain/Cargo.toml",
    "domain/lib.rs",
    "adapter/Cargo.toml",
    "adapter/lib.rs",
]:
    target = PACKET / "harness" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(CACHE / name, target)
for path in sorted(CACHE.glob("*.log")):
    (PACKET / f"{path.name}.gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for name in ["template-red-source.rs.gz", "template-red-tests.rs.gz"]:
    shutil.copyfile(CACHE / name, PACKET / name)
for name in ["cargo-metadata.json", "package-evidence.py"]:
    (PACKET / f"{name}.gz").write_bytes(
        gzip.compress((CACHE / name).read_bytes(), mtime=0)
    )
commands = [
    (
        "cargo test --offline --locked --manifest-path .cache/media-library-leaf/Cargo.toml",
        "test-final.log.gz",
    ),
    (
        "cargo clippy --offline --locked --manifest-path .cache/media-library-leaf/Cargo.toml --all-targets -- -D warnings",
        "clippy.log.gz",
    ),
    (
        "rustfmt --check --edition 2024 crates/domain/src/deployment/mod.rs crates/executor-container/src/deployment/mod.rs",
        "rustfmt.log.gz",
    ),
    (
        "uv run --offline --no-project --with ruff==0.17.0 ruff check tests/fixtures/deployment/media/check-leaves.py",
        "ruff.log.gz",
    ),
    (
        "uv run --offline --no-project --with ruff==0.17.0 ruff format --check tests/fixtures/deployment/media/check-leaves.py",
        "ruff-format.log.gz",
    ),
]
metadata = {
    "recorded_at_utc": datetime.now(UTC).isoformat(),
    "source_commit": CODE,
    "base_commit": run("git", "rev-parse", "c712486").decode().strip(),
    "branch": "engineer/p04-media-library-planning",
    "source_files_sha256": sources,
    "frozen_reference": {
        "commit": FROZEN,
        "files_sha256": reference,
        "execution": "Read/hash only; never imported or executed",
    },
    "tests": {
        "media_domain": 21,
        "decoder": 10,
        "catalog": 20,
        "b2_domain": 12,
        "total": 63,
        "filtered": 0,
    },
    "fixtures": {
        "synthetic_response_documents": 2,
        "existing_storage_contract_profiles": 3,
        "live_service_captures": 0,
    },
    "tool_versions": {
        "rustc": (CACHE / "rustc.txt").read_text().strip(),
        "cargo": (CACHE / "cargo.txt").read_text().strip(),
        "clippy": run("cargo", "clippy", "--version").decode().strip(),
        "rustfmt": run("rustfmt", "--version").decode().strip(),
        "uv": run("uv", "--version").decode().strip(),
        "ruff": "0.17.0 (explicit cached uv pin)",
    },
    "environment": {
        "CARGO_BUILD_JOBS": "1",
        "CARGO_INCREMENTAL": "0",
        "RUST_TEST_THREADS": "2 for tests",
        "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
        "cargo_suites": "Sequential; previous process completion observed before each next invocation",
    },
    "checks": [
        {"command": command, "exit_code": 0, "log": log} for command, log in commands
    ],
    "diagnostics": [
        "template-red reproduced the new planner accepting unresolved download-root syntax; final media admission validates both selected roots without changing the shared storage schema",
        "template-red-source/tests preserve the intermediate domain implementation and exact tests, not a separate complete qualified checkout",
        "initial and bounds logs retain earlier 60/62-test passes; final log qualifies all 63 cases",
    ],
    "registration": {
        "runtime": False,
        "api_ui": False,
        "protected_collector": False,
        "shared_roots_modified": False,
        "production_manifests_lock_modified": False,
        "stream_a_files_modified": False,
        "host_effects": False,
    },
    "limits": [
        "Initial Sonarr/Radarr/Lidarr/Jellyfin library preview only; other media seeding/quickstart/activity rows remain pending",
        "Plain observations/declarations, never endpoint/source/authority, live numeric ownership, mounted-state or hardlink proof",
        "Removal candidates are review suggestions, never DELETE plans; all six execution gates remain unresolved",
        "No HTTP/credential or service/Engine/physical collection, API/UI/browser, whole-worker budgets, writes or installed recovery acceptance",
        "No original-domain unit suite or B2 reader/API/UI rerun; no package/ARM64/Pi/performance/soak/cutover qualification",
        "No registered milestone/phase closure; A and central ownership unchanged",
    ],
}
(PACKET / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
artifacts = [
    p for p in sorted(PACKET.rglob("*")) if p.is_file() and p.name != "SHA256SUMS"
]
(PACKET / "SHA256SUMS").write_text(
    "".join(f"{sha(p.read_bytes())}  {p.relative_to(PACKET)}\n" for p in artifacts)
)
print(
    f"Bound {len(sources)} committed source inputs and {len(artifacts)} packet artifacts"
)
