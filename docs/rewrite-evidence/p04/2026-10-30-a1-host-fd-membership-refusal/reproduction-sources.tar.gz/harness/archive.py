# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Preserve the host FD-table refusal without claiming journal execution."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-journal-budget-qualification'
BUILDERS = ROOT / '.cache/stack-installed-qualification'
OUT = ROOT / 'docs/rewrite-evidence/p04/2026-10-30-a1-host-fd-membership-refusal'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
OUT.mkdir(exist_ok=False)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def archive(name, path):
    target = OUT / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

build = json.loads((BUILDERS / 'build-9/record.json').read_text())
packages = json.loads((BUILDERS / 'candidate-9/inputs.json').read_text())
fixture = json.loads((STATE / 'inputs-1.json').read_text())
assert head == build['source'] == packages['source'] == fixture['product_source']
assert build['exit_code'] == 0 and build['inputs_unchanged'] and build['container_removed']
assert build['stop_reason'] is None and not build['oom_killed']
for name, expected in build['before'].items():
    assert digest(ROOT / name) == expected, name
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=ROOT)).hexdigest() == expected, name
for name, expected in packages['repository'].items():
    assert digest(BUILDERS / 'candidate-9/repository' / name) == expected, name
for name, expected in fixture['guest'].items():
    assert digest(STATE / 'guest-1' / name) == expected, name
for name, expected in fixture['runner_support'].items():
    assert digest(STATE / name) == expected, name
assert digest(STATE / 'run_384.py') == fixture['runner_sha256']
vm = ROOT / '.cache/main-consolidation/attempts/a1-journal-budget-vm-1'
record = json.loads((vm / 'record.json').read_text())
assert record['head'] == head and record['before'] == build['before'] == record['after']
assert record['exit_code'] == 1 and record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
log = (vm / 'output.log').read_text()
failure = next(json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith('A1_FAILURE '))
assert failure['summary'] == 'fail' and failure['stage'] == 'human_plan_approval_queue'
assert 'action' not in failure and 'job' not in failure
assert failure['authority_schema'] == 12 and failure['package_version'] == packages['version']
assert failure['schema_source_sha256'] == fixture['schema_source_sha256']
assert failure['fixture_sha256'] == fixture['guest']['p04_mounts_guest.py']
for name, expected in failure['binary_sha256'].items():
    assert expected == packages['binaries'][name]['sha256'], name
assert 'A1_ADMISSION_DIAGNOSTIC_RECORDS=0' in log
assert '"phase":"scan.fds","failure":"Conflict"' in failure['unit_diagnostics']
assert '"phase":"scan.recheck.collection","failure":"Conflict"' in failure['unit_diagnostics']
assert not (ROOT / '.cache/main-consolidation/tmp/limeos-p01-vm-le0ghds2').exists()
for name in ('record.json', 'output.log', 'binaries.json', 'source-before.log', 'source-after.log'):
    archive('build/' + name, BUILDERS / 'build-9' / name)
for label in ('a1-journal-budget-ui-build-1', 'a1-journal-budget-packages-1', 'a1-journal-budget-vm-1'):
    for name in ('record.json', 'output.log'):
        archive('checks/' + label + '-' + name, ROOT / '.cache/main-consolidation/attempts' / label / name)
archive('package-inputs.json', BUILDERS / 'candidate-9/inputs.json')
archive('fixture-inputs.json', STATE / 'inputs-1.json')
for name in ('admission-1.json', 'guard-launch-1.json', 'guard-console-1.log',
             'result-1-vm-failure.txt', 'result-1-startup-console.txt'):
    archive(name, STATE / name)
(OUT / 'a1-failure.json.gz').write_bytes(gzip.compress((json.dumps(failure, indent=2) + '\n').encode(), mtime=0))
files = {('guest/' + p.name): p for p in sorted((STATE / 'guest-1').glob('*.py'))}
files.update({'runner/' + name: STATE / name for name in ('run_384.py', 'current_authority_schema.py')})
files.update({'harness/' + name: BUILDERS / source for name, source in {
    'build_candidate.py': 'build_candidate_9.py', 'build_inside.py': 'build_inside.py',
    'prepare_packages.py': 'prepare_packages_9.py', 'prepare_guest.py': 'prepare_journal_budget_guest.py',
    'launch_vm.py': 'launch_journal_budget_vm.py', 'detached_guard.py': 'detached_guard.py',
    'prepare_launch.py': 'prepare_launch_journal_vm.py',
}.items()})
files.update({'harness/guard.py': ROOT / '.cache/main-consolidation/guard.py', 'harness/archive.py': Path(__file__)})
for name in ('bins/executor/src/main.rs', 'bins/executor/src/storage_mount_admission.rs',
             'bins/executor/src/storage_runtime.rs', 'crates/persistence/src/lib.rs',
             'crates/executor-storage/src/mount_admission/host_consumers.rs'):
    files['source/' + name] = ROOT / name
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        tar.addfile(info, io.BytesIO(data))
(OUT / 'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
summary = {'source': head, 'recorded_inputs_match_commit': len(build['before']),
           'a1_accepted': False, 'continuous_guard_terminal_record_present': True,
           'vm_exit_code': record['exit_code'], 'host_guard_triggered': record['guard_triggered'],
           'minimum_available_bytes': record['minimum_available_bytes'], 'inputs_unchanged': True,
           'started': record['started'], 'ended': record['ended'], 'vm_scratch_removed': True,
           'stage': failure['stage'], 'error': failure['error'], 'positive_mount_job_created': False,
           'journal_execution_profile_exercised': False, 'actual_refusal': 'scan.fds Conflict',
           'owner_and_compared_fd_numbers_recorded': False,
           'admission_diagnostic_records': 0, 'pre_effect_cases': failure['pre_effect']['cases'],
           'packages': packages['packages'], 'binaries': packages['binaries'],
           'upgrade_qualification': False, 'installed_ui_qualification': False,
           'next': 'Capture bounded owner-before identity and exact compared FD-number membership without changing predicates or retrying this failed flow'}
(OUT / 'source-match.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k:summary[k] for k in ('source','recorded_inputs_match_commit','stage','actual_refusal','a1_accepted')}))
