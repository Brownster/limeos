# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Prepare one frozen runtime-fix candidate and launch its detached guarded VM."""
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/stack-installed-qualification'
GUARD = ROOT / '.cache/main-consolidation/guard.py'
steps = [
    ('journal-ui-9', [sys.executable, str(GUARD), 'a1-journal-budget-ui-build-1', 'npm', '--prefix', 'frontend', 'run', 'build']),
    ('journal-packages-9', [sys.executable, str(GUARD), 'a1-journal-budget-packages-1', sys.executable, str(STATE / 'prepare_packages_9.py')]),
    ('journal-guest-9', [sys.executable, str(STATE / 'prepare_journal_budget_guest.py')]),
    ('journal-launch-9', [sys.executable, str(STATE / 'launch_journal_budget_vm.py')]),
]
assert not [v for v in subprocess.check_output(['ps', '-eo', 'comm'], text=True).splitlines()
            if v.strip() in ('cargo', 'rustc', 'rustdoc')]
for label, command in steps:
    with (STATE / (label + '-console.log')).open('xb') as stream:
        status = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT).returncode
    print(label, status, flush=True)
    if status:
        raise SystemExit(status)
print('VM launched; acceptance requires the original guard terminal record and installed result', flush=True)
