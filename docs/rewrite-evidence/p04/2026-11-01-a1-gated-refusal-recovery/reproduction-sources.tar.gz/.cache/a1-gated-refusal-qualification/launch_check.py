# /// script
# dependencies = []
# ///
"""Launch one serial frozen qualification phase under the unchanged memory guard."""
import argparse
import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-gated-refusal-qualification'
commands = {
    'focused': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-executor', '--lib', 'storage_mount_supervision', '--', '--nocapture'],
    'core': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-core', '--bin', 'limeos-core', 'storage_mounts'],
    'store': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-persistence', '--lib', 'storage_mounts'],
    'journal': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-executor-storage', '--lib', 'effects::tests'],
    'schema': ['cargo', 'run', '--offline', '--locked', '-p', 'limeos-schema', '--', str(STATE / 'generated')],
    'rust': ['cargo', 'test', '--offline', '--locked', '--workspace', '--features', 'limeos-executor/read-worker-probe'],
    'clippy': ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--features', 'limeos-executor/read-worker-probe', '--', '-D', 'warnings'],
    'contracts': [sys.executable, 'scripts/check_contracts.py'],
    'frontend': [sys.executable, str(STATE / 'check_frontend.py')],
    'sanity': [sys.executable, str(STATE / 'check_sanity.py')],
}

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=commands)
parser.add_argument('attempt', type=int)
args = parser.parse_args()
assert 1 <= args.attempt <= 100
command = commands[args.phase]
label = f'a1-gated-refusal-{args.phase}-{args.attempt}'
assert not (ROOT / '.cache/main-consolidation/attempts' / label).exists()
assert not (STATE / f'{args.phase}-{args.attempt}-launch.json').exists()
available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
busy = [name.strip() for name in subprocess.check_output(['ps', '-eo', 'comm'], text=True).splitlines() if name.strip() in ('cargo', 'rustc', 'rustdoc')]
admission = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'available_bytes': available, 'start_threshold_bytes': 4 * 1024**3, 'runtime_stop_floor_bytes': 3 * 1024**3, 'external_compilers': busy, 'admitted': available >= 4 * 1024**3 and not busy}
(STATE / f'{args.phase}-{args.attempt}-admission.json').write_text(json.dumps(admission, indent=2) + '\n')
print(json.dumps(admission), flush=True)
if not admission['admitted']:
    raise SystemExit(75)
wrapper = ROOT / '.cache/stack-installed-qualification/detached_guard.py'
with (STATE / f'{args.phase}-{args.attempt}-console.log').open('xb') as output:
    child = subprocess.Popen([sys.executable, str(wrapper), label, *command], cwd=ROOT, start_new_session=True, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT)
raw = (Path('/proc') / str(child.pid) / 'stat').read_text()
record = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': child.pid, 'start_ticks': int(raw[raw.rindex(')') + 1:].split()[19]), 'session': os.getsid(child.pid), 'process_group': os.getpgid(child.pid), 'phase': args.phase, 'label': label, 'command': command, 'launcher_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'guard_sha256': hashlib.sha256((ROOT / '.cache/main-consolidation/guard.py').read_bytes()).hexdigest()}
assert record['session'] == record['process_group'] == child.pid
(STATE / f'{args.phase}-{args.attempt}-launch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'pid': child.pid, 'session': record['session'], 'label': label}), flush=True)
