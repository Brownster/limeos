# /// script
# dependencies = []
# ///
"""Prepare source-bound recovery evidence tools; no product source edits."""
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-gated-refusal-qualification'
prior = root / '.cache/b1-observation-supervisor-qualification'
for name in ['install_generated.py', 'record_end.py', 'archive_evidence.py', 'seal_packet.py']:
    text = (prior / name).read_text().replace('b1-observation-supervisor', 'a1-gated-refusal')
    text = text.replace('2026-11-01-a1-gated-refusal', '2026-11-01-a1-gated-refusal-recovery')
    text = text.replace('docs/plans/2026-10-31-a1-gated-refusal-design.md', 'docs/plans/2026-11-01-a1-gated-refusal-recovery-design.md')
    if name == 'record_end.py':
        start = text.index("browser = json.loads(")
        end = text.index("for name, sha in build['ui'].items():", start)
        text = text[:start] + text[end:]
        text = text.replace('LIMEOS_CORE_OBSERVATION pid=', 'LIMEOS_MOUNT_GATE_TEST pid=')
    if name == 'archive_evidence.py':
        start = text.index("    'scope': ")
        end = text.index('\n', start)
        text = text[:start] + "    'scope': 'Native owned unprivileged process/pipe/pidfd guardian protocol tests, real isolated journal and Store recovery, and owned Core RPC with private unit credentials. No genuine installed root-image/admission/mount/API/UI journey, VM/package/return/ARM64/Pi/soak or cutover acceptance.'," + text[end:]
    (state / name).write_text(text)
