# /// script
# dependencies = []
# ///
"""Compare guarded source maps and check the original native processes are absent."""
import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/a1-gated-refusal-qualification'
labels = json.loads((STATE / 'final-checks.json').read_text())
records = {label: json.loads((ROOT / '.cache/main-consolidation/attempts' / label / 'record.json').read_text()) for label in labels}
expected = records[labels[0]]['before']
for label, record in records.items():
    assert record['ended'] and record['exit_code'] == 0, label
    assert record['inputs_unchanged'] and record['before'] == record['after'] == expected, label
    assert not record['guard_triggered'] and not record['observed_external_compilers'], label
    assert record['minimum_available_bytes'] >= 3 * 1024**3
for name, sha in expected.items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, name
build = json.loads((STATE / 'frontend-build.json').read_text())
for name, sha in build['ui'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha, name
pids = set()
for path in STATE.glob('*-launch.json'):
    launch = json.loads(path.read_text())
    pids.add(launch['pid'])
    record = json.loads((ROOT / '.cache/main-consolidation/attempts' / launch['label'] / 'record.json').read_text())
    assert record['ended']
    pids.add(record['pid'])
    output = (ROOT / '.cache/main-consolidation/attempts' / launch['label'] / 'output.log').read_text()
    pids.update(int(pid) for pid in re.findall(r'LIMEOS_MOUNT_GATE_TEST pid=(\d+)', output))
command = ['ps', '-p', ','.join(str(pid) for pid in sorted(pids)), '-o', 'pid,ppid,sid,stat,comm']
result = subprocess.run(command, text=True, capture_output=True, check=False)
processes = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
(STATE / 'original-process-absence.json').write_text(json.dumps(processes, indent=2) + '\n')
assert result.returncode == 1 and len(result.stdout.splitlines()) == 1, processes
summary = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'final_maps': labels, 'guarded_input_count': len(expected), 'current_source_matches': True, 'original_processes_absent': len(pids), 'minimum_available_bytes': min(record['minimum_available_bytes'] for record in records.values())}
(STATE / 'final-source-observation.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
