# /// script
# dependencies = []
# ///
"""Check formatting and unchanged repository boundaries, without building packages."""
import subprocess
commands = [
    ['cargo', 'fmt', '--all', '--', '--check'],
    ['uv', 'run', '--offline', '--no-project', '--python', '/usr/bin/python3', 'scripts/check_repository.py'],
    ['git', 'diff', '--check'],
]
for command in commands:
    print(repr(command), flush=True)
    subprocess.run(command, check=True)
