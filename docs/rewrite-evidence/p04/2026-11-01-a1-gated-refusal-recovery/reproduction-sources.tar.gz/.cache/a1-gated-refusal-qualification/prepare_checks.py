# /// script
# dependencies = []
# ///
"""Prepare serial source-frozen checks without changing the memory guard."""
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/a1-gated-refusal-qualification'
prior = root / '.cache/b1-observation-supervisor-qualification'
text = (prior / 'launch_check.py').read_text().replace('b1-observation-supervisor', 'a1-gated-refusal')
start = text.index('commands = {')
end = text.index('\nparser = ', start)
text = text[:start] + '''commands = {
    'focused': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-executor', '--lib', 'storage_mount_supervision', '--', '--nocapture'],
    'core': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-core', '--bin', 'limeos-core', 'storage_mounts'],
    'store': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-persistence', '--lib', 'storage_mounts'],
    'journal': ['cargo', 'test', '--offline', '--locked', '-p', 'limeos-executor-storage', '--lib', 'effects::tests'],
    'schema': ['cargo', 'run', '--offline', '--locked', '-p', 'limeos-schema', '--', str(STATE / 'generated')],
    'rust': ['cargo', 'test', '--offline', '--locked', '--workspace', '--features', 'limeos-executor/read-worker-probe'],
    'clippy': ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--features', 'limeos-executor/read-worker-probe', '--', '-D', 'warnings'],
    'contracts': [sys.executable, 'scripts/check_contracts.py'],
    'frontend': [sys.executable, str(STATE / 'check_frontend.py')],
    'sanity': [sys.executable, str(STATE / 'check_sanity.py')],
}
''' + text[end:]
(state / 'launch_check.py').write_text(text)
for name in ['check_frontend.py', 'check_sanity.py', 'summarize.py']:
    (state / name).write_text((prior / name).read_text().replace('b1-observation-supervisor', 'a1-gated-refusal'))
