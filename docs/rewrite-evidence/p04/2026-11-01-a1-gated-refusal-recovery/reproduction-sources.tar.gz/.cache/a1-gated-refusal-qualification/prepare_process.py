# /// script
# dependencies = []
# ///
"""Perform the explicit internal process-owner extraction once."""
from pathlib import Path

path = Path('bins/executor/src/storage_mount_supervision.rs')
text = path.read_text()
assert 'process: Process,' in text and 'owned.process.child' not in text
for field in ('child', 'input', 'output', '_pidfd', 'identity', 'action', 'digest', 'bytes'):
    text = text.replace(f'owned.{field}', f'owned.process.{field}')
text = text.replace('retained.output', 'retained.process.output')
text = text.replace('retained.bytes', 'retained.process.bytes')
text = text.replace('retained.child', 'retained.process.child')
text = text.replace('let output = child.stdout.take().ok_or_else(error)?;',
                    'let output = File::from(OwnedFd::from(child.stdout.take().ok_or_else(error)?));')
old = '''        let mut owned = Owned {
            child,
            input: Some(input),
            output,
            _pidfd: pidfd,
            _image: image,
            _admission: admission,
            identity: pending_identity,
            action: action.into(),
            digest: digest.into(),
            bytes: Vec::new(),
        };'''
new = '''        let mut owned = Owned {
            process: Process {
                child,
                input: Some(input),
                output,
                _pidfd: pidfd,
                identity: pending_identity,
                action: action.into(),
                digest: digest.into(),
                bytes: Vec::new(),
            },
            _image: image,
            _admission: admission,
        };'''
assert old in text
text = text.replace(old, new)
text = text.replace('expect("owned gated helper").identity', 'expect("owned gated helper").process.identity')
text = text.replace('output: ChildStdout,', 'output: File,')
path.write_text(text)
