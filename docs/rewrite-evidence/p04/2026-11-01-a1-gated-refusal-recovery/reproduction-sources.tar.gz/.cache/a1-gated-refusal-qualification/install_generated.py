# /// script
# dependencies = []
# ///
"""Copy only differing outputs from the actual Rust emitter."""
import hashlib
import json
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os')
state = Path(__file__).parent
record = json.loads((root / '.cache/main-consolidation/attempts/a1-gated-refusal-schema-1/record.json').read_text())
assert record['ended'] and record['exit_code'] == 0 and record['inputs_unchanged']
for name, sha in record['after'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
changes = []
for path in sorted((state / 'generated').iterdir()):
    assert path.is_file()
    target = root / 'contracts/generated' / path.name
    data = path.read_bytes()
    if not target.exists() or target.read_bytes() != data:
        target.write_bytes(data)
        changes.append({'path': str(target.relative_to(root)), 'sha256': hashlib.sha256(data).hexdigest()})
(state / 'generated-delta.json').write_text(json.dumps(changes, indent=2) + '\n')
print(json.dumps(changes, indent=2))
