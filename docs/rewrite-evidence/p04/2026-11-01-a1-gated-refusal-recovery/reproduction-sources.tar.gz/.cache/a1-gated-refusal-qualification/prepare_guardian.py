# /// script
# dependencies = []
# ///
"""Extract the unchanged bounded GO parser and add pre-spawn refusal ACKs once."""
from pathlib import Path

path = Path('bins/executor/src/storage_mount_supervision.rs')
text = path.read_text()
start = text.index('    let mut frame = Vec::new();\n    let go = loop {')
end = text.index('    let me = std::process::id();', start)
block = text[start:end]
loop_end = block.index('    check_go(&go,')
parser = block[:loop_end].replace('    let go = loop {', '    let go = loop {', 1)
parser += '''    check_go(&go, action, digest, deadline, now()?, uptime_ticks()?)?;
    Ok(go)
'''
parser = parser.replace('};\n    check_go', '};\n    check_go')
replacement = '''    let readiness = (|| {
        let go = receive_go(&mut input, &action, &digest, deadline)?;
        if parent_gone(&mut input)? {
            return Err(Error(ErrorCode::Expired));
        }
        host_namespace(namespace)?;
        Ok(go)
    })();
    let go = match readiness {
        Ok(go) => go,
        Err(_) => return acknowledge(&mut io::stdout().lock(), action, digest, MountHelperOutcome::NotStarted {}),
    };
'''
text = text[:start] + replacement + text[end:]
old = '''    check_go(&go, &action, &digest, deadline, now()?, uptime_ticks()?)?;
    if parent_gone(&mut input)? {
        return Err(Error(ErrorCode::Expired));
    }
    let mut child = command.spawn().map_err(|_| error())?;'''
new = '''    let final_check = (|| {
        check_go(&go, &action, &digest, deadline, now()?, uptime_ticks()?)?;
        if parent_gone(&mut input)? {
            return Err(Error(ErrorCode::Expired));
        }
        Ok(())
    })();
    if final_check.is_err() {
        return acknowledge(&mut io::stdout().lock(), action, digest, MountHelperOutcome::NotStarted {});
    }
    // From the first spawn attempt, refusal cannot claim never-started. Only
    // the actual child's exit and complete descendant cleanup may acknowledge.
    let mut child = command.spawn().map_err(|_| error())?;'''
assert old in text
text = text.replace(old, new)
start = text.index('    let ack = serde_json::to_vec(&Ack {\n', text.index('pub fn guardian()'))
end = text.index('\nfn env_number(', start)
old = text[start:end]
assert old.endswith('\n}')
new = '''    acknowledge(&mut io::stdout().lock(), action, digest, outcome)
}

fn receive_go(input: &mut impl Read, action: &str, digest: &str, deadline: u64) -> Result<Go> {
''' + parser + '''}

fn acknowledge(output: &mut impl Write, action: String, digest: String, outcome: MountHelperOutcome) -> Result<()> {
    let ack = serde_json::to_vec(&Ack { action, digest, outcome }).map_err(|_| error())?;
    if ack.len() > MAX_FRAME - 4 {
        return Err(error());
    }
    output.write_all(&(ack.len() as u32).to_be_bytes())
        .and_then(|()| output.write_all(&ack))
        .and_then(|()| output.flush())
        .map_err(|_| error())
}
'''
text = text[:start] + new + text[end:]
path.write_text(text)
