# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Repeat the consolidation ancestry and preservation audit without deleting drafts."""
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = root / ".cache/main-consolidation/recheck-2026-10-21"
out.mkdir()

def git(*args, cwd=root):
    return subprocess.check_output(["git", *args], cwd=cwd)

head = git("rev-parse", "main").decode().strip()
assert git("branch", "--show-current").strip() == b"main"
assert not git("status", "--porcelain=v1", "--untracked-files=all").strip()
assert not git("for-each-ref", "--no-merged=main", "--format=%(refname)", "refs/heads", "refs/remotes").strip()
remote = git("ls-remote", "--heads", "origin").decode()
for line in remote.splitlines():
    tip, _name = line.split()
    subprocess.run(["git", "merge-base", "--is-ancestor", tip, "main"], cwd=root, check=True)
(out / "live-remote-refs.txt").write_text(remote)
trees = []
for block in git("worktree", "list", "--porcelain").decode().strip().split("\n\n"):
    fields = dict(row.split(" ", 1) for row in block.splitlines() if " " in row)
    path = Path(fields["worktree"])
    subprocess.run(["git", "merge-base", "--is-ancestor", fields["HEAD"], "main"], cwd=root, check=True)
    status = git("status", "--porcelain=v1", "-z", "--untracked-files=all", cwd=path)
    item = {**fields, "merged": True, "dirty": bool(status)}
    if path != root:
        assert status, f"Clean merged worktree remains: {path}"
        prior = root / ".cache/main-consolidation/final-audit/recovery" / path.name
        assert status == (prior / "status.z").read_bytes()
        assert git("diff", "HEAD", "--binary", cwd=path) == (prior / "diff-head.patch").read_bytes()
        for entry in json.loads((prior / "untracked.json").read_text()):
            if "sha256" in entry:
                assert hashlib.sha256((path / entry["path"]).read_bytes()).hexdigest() == entry["sha256"]
        item["unchanged_since_preserved_recovery"] = True
    trees.append(item)
result = {"head": head, "main_clean": True, "all_local_and_live_remote_tips_merged": True, "trees": trees,
          "other_engineer": {"schedules_contracts": git("rev-parse", "ca13ffb").decode().strip(), "abi_fix": git("rev-parse", "4baf338").decode().strip()},
          "push_performed": False, "deletions_needed": 0}
(out / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"head": head, "merged": True, "dirty_worktrees_retained": len(trees)-1, "unchanged_recovery": True}))
