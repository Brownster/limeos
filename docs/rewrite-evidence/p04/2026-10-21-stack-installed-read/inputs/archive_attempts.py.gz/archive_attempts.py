# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Archive terminal installed-read evidence without payloads or private signing keys."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
state = Path(__file__).resolve().parent
dest = root / "docs/rewrite-evidence/p04/2026-10-21-stack-installed-read"
dest.mkdir(exist_ok=False)
files = {}

def archive(source, relative):
    assert source.is_file(), source
    data = source.read_bytes()
    target = dest / (relative + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(data, mtime=0))
    files[str(target.relative_to(dest))] = {
        "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "original_sha256": hashlib.sha256(data).hexdigest(),
        "original_bytes": len(data),
        "source": str(source.relative_to(root)),
    }

for path in sorted((state / "build-1").iterdir()):
    if path.is_file():
        archive(path, "build/" + path.name)
for name in ("inputs.json", "prepare_packages.py"):
    archive(state / "candidate-1" / name, "candidate/" + name)
for path in sorted((state / "candidate-1/repository").rglob("*")):
    if path.is_file() and not path.name.endswith(".deb"):
        archive(path, "repository/" + str(path.relative_to(state / "candidate-1/repository")))
attempts = [
    ("stack-installed-vm-1", None),
    ("stack-installed-vm-2", "vm-2"),
    ("stack-installed-vm-3-trace", "vm-3"),
    ("stack-installed-vm-4-file-trace", "vm-4"),
]
results = {}
for label, guest in attempts:
    attempt = root / ".cache/main-consolidation/attempts" / label
    record = json.loads((attempt / "record.json").read_text())
    assert record.get("ended") and "exit_code" in record
    assert record["inputs_unchanged"]
    results[label] = {k: record[k] for k in (
        "head", "started", "ended", "exit_code", "guard_triggered", "minimum_available_bytes", "inputs_unchanged",
    )}
    for name in ("record.json", "output.log", "failure-extracted.json"):
        path = attempt / name
        if path.exists():
            archive(path, "attempts/" + label + "/" + name)
    if guest:
        for path in sorted((state / guest).glob("*.txt")):
            archive(path, "attempts/" + label + "/" + path.name)
for group in ("vm-2-guest", "vm-3-guest", "vm-4-inputs"):
    for path in sorted((state / group).rglob("*")):
        if path.is_file():
            archive(path, "inputs/" + group + "/" + str(path.relative_to(state / group)))
for name in ("run_768.py", "prepare_vm.py", "vm-2-inputs.json", "freeze_vm_inputs.py", "inspect_failure.py", "archive_attempts.py"):
    archive(state / name, "inputs/" + name)
for name in ("audit.json", "live-remote-refs.txt"):
    archive(root / ".cache/main-consolidation/recheck-2026-10-21" / name, "consolidation/" + name)
archive(root / ".cache/main-consolidation/recheck-current.py", "consolidation/recheck-current.py")
manifest = {
    "source": "54022bb2b9fe3a2f7570e4f00b9de07a1e9e334f",
    "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "Fresh AMD64 Debian build and signed installation; stack collection refuses",
    "candidate": json.loads((state / "candidate-1/inputs.json").read_text()),
    "attempts": results,
    "files": files,
    "limits": [
        "No successful installed stack collection or complete resource acceptance",
        "Trace diagnostics preserve selected syscall lines and bounded tails, not a full syscall trace",
        "VM 1 was stopped by the host guard; its exact cache-only guest script was not separately frozen",
        "VM 2 and 3 guest scripts were preserved after those terminal runs; VM 4 inputs were hashed before execution",
        "Host-memory sampling covers the build and VM supervisors, not the low-memory package assembly command",
        "Only standard package installed; shadow was assembled and hashed",
        "No ARM64, Pi, lifecycle, source inspection, recovery or cutover credit",
    ],
}
(dest / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
for name, facts in files.items():
    packed = (dest / name).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == facts["sha256"]
    assert hashlib.sha256(gzip.decompress(packed)).hexdigest() == facts["original_sha256"]
print(json.dumps({"packet": str(dest), "archived_files": len(files), "attempts": results}))
