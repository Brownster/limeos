# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Freeze the exact ignored diagnostic inputs before a guarded VM run."""
import hashlib
import json
import shutil
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
state = Path(__file__).resolve().parent
label = sys.argv[1]
dest = state / (label + "-inputs")
dest.mkdir()
inputs = [
    root / "tests/privileged_vm/run.py",
    state / "run_768.py",
    state / "current_authority_schema.py",
    state / "candidate-1/inputs.json",
    *sorted((state / "guest").glob("*.py")),
]
record = {}
for path in inputs:
    data = path.read_bytes()
    relative = path.relative_to(root)
    copy = dest / relative
    copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, copy)
    record[str(relative)] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
(dest / "inputs.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"snapshot": str(dest), "files": len(record)}))
