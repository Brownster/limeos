# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Verify the archived terminal evidence and write the final packet checksum list."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
packet = root / "docs/rewrite-evidence/p04/2026-10-21-stack-installed-read"
manifest = json.loads((packet / "manifest.json").read_text())
for name, entry in manifest["files"].items():
    packed = (packet / name).read_bytes()
    raw = gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest() == entry["sha256"]
    assert hashlib.sha256(raw).hexdigest() == entry["original_sha256"]
    assert len(raw) == entry["original_bytes"]

def read_json(relative):
    return json.loads(gzip.decompress((packet / relative).read_bytes()))

build = read_json("build/record.json.gz")
assert build["source"] == manifest["source"]
assert build["before"] == build["after"]
assert build["exit_code"] == 0 and not build["oom_killed"]
assert build["stop_reason"] is None and build["container_removed"]
assert build["minimum_available_bytes"] == 3689598976
assert hashlib.sha256(gzip.decompress((packet / "build/build_candidate.py.gz").read_bytes())).hexdigest() == build["builder_sha256"]
assert hashlib.sha256(gzip.decompress((packet / "build/build_inside.py.gz").read_bytes())).hexdigest() == build["inside_sha256"]
for name, expected in build["before"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
for name, expected in manifest["candidate"]["packages"].items():
    actual = root / ".cache/stack-installed-qualification/candidate-1/packages" / name
    assert hashlib.sha256(actual.read_bytes()).hexdigest() == expected
for name, entry in manifest["candidate"]["binaries"].items():
    actual = root / ".cache/stack-installed-qualification/build-1/binaries" / name
    assert hashlib.sha256(actual.read_bytes()).hexdigest() == entry["sha256"]
for label, attempt in manifest["attempts"].items():
    record = read_json("attempts/" + label + "/record.json.gz")
    assert record["head"] == manifest["source"] and record["inputs_unchanged"]
    assert record["before"] == record["after"]
    assert record["exit_code"] == attempt["exit_code"]
    assert record.get("ended")
failure = read_json("attempts/stack-installed-vm-4-file-trace/failure-extracted.json.gz")
refusals = failure["strace_refusals"]
assert sum('"/proc/1/ns/mnt"' in line and "EACCES" in line for line in refusals) == 2
assert sum('"/run/docker.sock"' in line and "ENOSYS" in line for line in refusals) == 2
audit = read_json("consolidation/audit.json.gz")
assert audit["head"] == manifest["source"] and audit["all_local_and_live_remote_tips_merged"]
assert len(audit["trees"]) == 9
assert all(tree.get("unchanged_since_preserved_recovery") for tree in audit["trees"][1:])
for label in ("schedules_contracts", "abi_fix"):
    subprocess.run(["git", "merge-base", "--is-ancestor", audit["other_engineer"][label], "main"], cwd=root, check=True)
files = sorted(p for p in packet.rglob("*") if p.is_file() and p.name != "artifacts.sha256")
(packet / "artifacts.sha256").write_text("".join(
    hashlib.sha256(path.read_bytes()).hexdigest() + "  " + str(path.relative_to(packet)) + "\n"
    for path in files
))
print(json.dumps({"source": manifest["source"], "compressed_records_verified": len(manifest["files"]), "packet_files_hashed": len(files), "refusals_confirmed": True, "consolidation_audit_verified": True}))
