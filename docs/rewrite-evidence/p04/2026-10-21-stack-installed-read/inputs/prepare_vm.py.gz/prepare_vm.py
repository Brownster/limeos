# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Freeze guest inputs and select less disposable-VM RAM without changing tests."""
import hashlib
import json
import shutil
from pathlib import Path

root=Path('/home/marc/Documents/github/lime-os')
state=root/'.cache/stack-installed-qualification'
source=root/'tests/privileged_vm/run.py'
text=source.read_text()
needle='"2048" if args.build_bundle else "1024"'
assert text.count(needle)==1
runner=state/'run_768.py'
assert not runner.exists()
runner.write_text(text.replace(needle,'"2048" if args.build_bundle else "768"'))
shutil.copyfile(root/'tests/privileged_vm/current_authority_schema.py',state/'current_authority_schema.py')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
record={'original_runner_sha256':digest(source),'selected_runner_sha256':digest(runner),'sole_runner_change':'non-build disposable guest RAM 1024 to 768 MiB; all service limits and assertions unchanged','guest':{p.name:digest(p) for p in sorted((state/'guest').glob('*.py'))},'candidate_inputs_sha256':digest(state/'candidate-1/inputs.json')}
(state/'vm-2-inputs.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
