# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Extract bounded guest diagnostics from the original terminal tool log."""
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
for label in sys.argv[1:]:
    directory = root / ".cache/main-consolidation/attempts" / label
    record = json.loads((directory / "record.json").read_text())
    print(json.dumps({key: record[key] for key in ("exit_code", "guard_triggered", "minimum_available_bytes", "inputs_unchanged")}))
    log = (directory / "output.log").read_text()
    lines = [line for line in log.splitlines() if line.startswith("STACK_FAILURE=")]
    if not lines:
        print("No completed guest diagnostic")
        continue
    value = json.loads(lines[-1].split("=", 1)[1])
    (directory / "failure-extracted.json").write_text(json.dumps(value, indent=2) + "\n")
    print(json.dumps({"error": value.get("error"), "passed": value.get("passed"), "refusals": value.get("strace_refusals")}))
