"""Genuine installed stack reads in a disposable VM; no storage effects."""

import hashlib
import http.client
import io
import json
import os
import signal
import subprocess
import sys
import tarfile
import threading
import time
from pathlib import Path

import guest as foundation
import p04_mounts_guest as engine_fixture

VERSION = "0.4.5+stack.1"
UNIT = "limeos-storage-reader"
CATALOG = Path("/etc/limeos/management-catalog.json")
ROOT = Path("/opt/stack-read-fixture/Media")
GROUP = None


def run(*args, input=None, check=True, timeout=90):
    result = subprocess.run(
        args, input=input, text=True, capture_output=True, timeout=timeout, check=False
    )
    if check and result.returncode:
        raise RuntimeError(
            f"{args!r}: {result.returncode}: {result.stdout[-2000:]} {result.stderr[-2000:]}"
        )
    return result


def api(path, method="GET", body=None, cookie=None):
    conn = http.client.HTTPConnection("127.0.0.1", 8003, timeout=12)
    headers = {"Origin": "https://localhost", "Content-Type": "application/json"}
    if cookie:
        headers["Cookie"] = cookie
    try:
        conn.request(method, path, None if body is None else json.dumps(body), headers)
        response = conn.getresponse()
        data = response.read(65_537)
        assert len(data) <= 65_536
        return (
            response.status,
            dict(response.getheaders()),
            json.loads(data) if data else None,
        )
    finally:
        conn.close()


def eventually(test, limit=50):
    deadline = time.monotonic() + limit
    while True:
        result = test()
        if result:
            return result
        if time.monotonic() >= deadline:
            raise AssertionError("condition deadline")
        time.sleep(0.2)


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rpc(account):
    request = json.dumps({"version": 1, "operation": "stack_inventory"})
    result = run(
        "runuser",
        "-u",
        account,
        "-g",
        "limeos-host-access",
        "--",
        "python3",
        "-c",
        foundation.executor_probe_code(),
        "/run/limeos-storage-reader/executor.sock",
        request,
    )
    return result.stdout


def metrics():
    global GROUP
    if GROUP is None:
        GROUP = run(
            "systemctl", "show", UNIT, "-p", "ControlGroup", "--value"
        ).stdout.strip()
    group = GROUP
    directory = Path("/sys/fs/cgroup") / group.lstrip("/")
    result = {"group": group}
    for name in (
        "memory.current",
        "memory.peak",
        "memory.max",
        "memory.events",
        "pids.current",
        "pids.max",
        "pids.events",
    ):
        path = directory / name
        result[name] = path.read_text().strip() if path.exists() else None
    return result


def main():
    assert (
        os.geteuid() == 0
        and Path("/etc/hostname").read_text().strip() == "limeos-p01-test"
    )
    repo, output = map(Path, sys.argv[1:])
    evidence = {
        "scope": "disposable AMD64 installed stack reader",
        "version": VERSION,
        "passed": [],
        "states": {},
        "resources": {},
        "limitations": [
            "No ARM64 or Pi execution",
            "Socket-activated PID1 Engine peer excluded",
            "No Compose source-inspection or lifecycle acceptance",
            "Sampled process descriptors/tasks; kernel memory.peak where present",
            "Fault matrix and installed browser ownership replacement remain open",
        ],
    }

    def passed(name):
        evidence["passed"].append(name)
        print("PASS " + name, flush=True)

    stop = threading.Event()
    samples = []
    maxima = {"memory": 0, "tasks": 0, "fds": 0, "processes": {}}

    def observe():
        while not stop.wait(0.02):
            try:
                current = metrics()
                # Keep sampled maxima rather than an unbounded time series.
                samples.append(current)
                maxima["memory"] = max(maxima["memory"], int(current["memory.current"]))
                maxima["tasks"] = max(maxima["tasks"], int(current["pids.current"]))
                directory = Path("/sys/fs/cgroup") / current["group"].lstrip("/")
                for pid in (directory / "cgroup.procs").read_text().split():
                    proc = Path("/proc") / pid
                    try:
                        command = (
                            (proc / "cmdline")
                            .read_bytes()[:512]
                            .replace(b"\0", b" ")
                            .decode(errors="replace")
                        )
                        descriptors = len(list((proc / "fd").iterdir()))
                        maxima["fds"] = max(maxima["fds"], descriptors)
                        if pid not in maxima["processes"]:
                            maxima["processes"][pid] = {
                                "command": command,
                                "limits": (proc / "limits").read_text()[:4096],
                                "status": (proc / "status").read_text()[:4096],
                            }
                    except (FileNotFoundError, ProcessLookupError):
                        pass
                if len(samples) > 250:
                    samples.pop(0)
            except (OSError, subprocess.SubprocessError):
                pass

    observer = None
    trace = None
    try:
        run(
            "install",
            "-m",
            "0644",
            str(repo / "limeos-archive-keyring.gpg"),
            "/usr/share/keyrings/limeos-test.gpg",
        )
        Path("/etc/apt/sources.list.d/limeos-test.list").write_text(
            "deb [signed-by=/usr/share/keyrings/limeos-test.gpg] file:"
            + str(repo)
            + " stable main\n"
        )
        run("apt-get", "update", timeout=180)
        run("apt-get", "install", "-y", "limeos=" + VERSION, timeout=180)
        assert run("systemctl", "is-active", UNIT, check=False).returncode != 0
        assert (
            json.loads(Path("/etc/limeos/system-policy/storage.json").read_text())[
                "allow_stack_read"
            ]
            is True
        )
        for name in (
            "limeos-core",
            "limeos-executor",
            "limeos-stack-read-worker",
            "limeos-password-worker",
            "limeosctl",
        ):
            path = Path("/usr/lib/limeos") / name
            assert path.stat().st_uid == 0 and path.stat().st_mode & 0o022 == 0
        evidence["binaries"] = {
            name: file_hash(Path("/usr/lib/limeos") / name)
            for name in (
                "limeos-core",
                "limeos-executor",
                "limeos-stack-read-worker",
                "limeos-password-worker",
                "limeosctl",
            )
        }
        passed("signed fresh package includes immutable worker; reader stays dormant")
        issued = json.loads(run("/usr/lib/limeos/limeosctl", "bootstrap").stdout)
        run(
            "/usr/lib/limeos/limeosctl",
            "enroll",
            input=json.dumps(
                {
                    "token": issued["token"],
                    "username": "reader",
                    "password": "disposable-stack-read-password",
                }
            ),
        )
        status, headers, _session = api(
            "/api/v1/auth/login",
            "POST",
            {"username": "reader", "password": "disposable-stack-read-password"},
        )
        assert status == 200
        cookie = headers["set-cookie"].split(";", 1)[0]
        assert api("/api/v1/deployment/stacks")[0] == 401
        evidence["engine"] = engine_fixture.actual_docker()
        ROOT.mkdir(parents=True, mode=0o755)
        operator = ROOT / "compose.yaml"
        operator.write_text("services:\n  web:\n    image: fixture\n")
        operator.chmod(0o644)
        catalog = {
            "version": 1,
            "engine_id": evidence["engine"]["id"],
            "stacks": [
                {
                    "stack": "media",
                    "project": "media",
                    "working_directory": str(ROOT),
                    "operator": {"name": "compose.yaml", "sha256": file_hash(operator)},
                    "managed": {"state": "absent"},
                    "services": ["web"],
                }
            ],
        }
        CATALOG.write_text(json.dumps(catalog) + "\n")
        CATALOG.chmod(0o644)
        run("apt-get", "install", "-y", "strace", timeout=120)
        run("systemctl", "start", UNIT)
        observer = threading.Thread(target=observe, daemon=True)
        observer.start()
        pid = run("systemctl", "show", UNIT, "-p", "MainPID", "--value").stdout.strip()
        trace = subprocess.Popen(
            [
                "strace",
                "-f",
                "-tt",
                "-s",
                "128",
                "-e",
                "trace=%process,memfd_create,fcntl,prlimit64,prctl,openat",
                "-p",
                pid,
                "-o",
                "/root/stack-reader.strace",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        def fresh(expected):
            status, _, value = api("/api/v1/deployment/stacks", cookie=cookie)
            evidence["states"]["last"] = value
            return (
                value
                if status == 200
                and value["catalog"]["state"] == "fresh"
                and value["engine"]["state"] == "fresh"
                and len(value["stacks"]) == 1
                and value["stacks"][0]["runtime"] == expected
                else None
            )

        empty = eventually(lambda: fresh("no_containers"))
        assert (
            empty["stacks"][0]["counts"]["ordinary"] == 0
            and empty["stacks"][0]["missing_services"] == 1
        )
        assert empty["stacks"][0]["files"]["state"] == "not_inspected"
        evidence["states"]["empty"] = empty
        authorized = json.loads(rpc("limeos-core"))
        assert (
            authorized["ready"]
            and authorized["stack_cohort"]["catalog_current"]
            and authorized["stack_cohort"]["engine_current"]
        )
        assert foundation.refused_executor_reply(rpc("nobody"), "forbidden")
        passed(
            "genuine protected catalog and fixed-root Engine produce a registered empty stack; same RPC rejects foreign UID"
        )
        before = authorized["stack_cohort"]
        for _ in range(20):
            status, _, _value = api("/api/v1/deployment/stacks", cookie=cookie)
            assert status == 200
        after = json.loads(rpc("limeos-core"))["stack_cohort"]
        assert (
            before["catalog"]["sampled_at"] == after["catalog"]["sampled_at"]
            and before["engine"]["sampled_at"] == after["engine"]["sampled_at"]
        )
        passed("RPC and API read bursts retain original sample timestamps")
        run("apt-get", "install", "-y", "busybox-static", timeout=120)
        archive = io.BytesIO()
        with tarfile.open(fileobj=archive, mode="w") as tar:
            tar.add("/bin/busybox", arcname="busybox")
        result = subprocess.run(
            ["docker", "import", "-", "limeos-stack-read:fixture"],
            input=archive.getvalue(),
            capture_output=True,
            check=True,
        )
        image = result.stdout.decode().strip()
        assert image.startswith("sha256:")
        labels = [
            "--label",
            "com.docker.compose.project=media",
            "--label",
            "com.docker.compose.service=web",
            "--label",
            "com.docker.compose.project.working_dir=" + str(ROOT),
            "--label",
            "com.docker.compose.project.config_files=" + str(operator),
        ]
        ids = []
        for index, oneoff in enumerate(("False", "False", "True")):
            ids.append(
                run(
                    "docker",
                    "run",
                    "-d",
                    "--network=none",
                    *labels,
                    "--label",
                    "com.docker.compose.oneoff=" + oneoff,
                    "--name",
                    "stack-read-" + str(index),
                    image,
                    "/busybox",
                    "sleep",
                    "600",
                ).stdout.strip()
            )
        run("docker", "stop", "--time", "1", ids[1])
        mixed = eventually(lambda: fresh("partial"))
        stack = mixed["stacks"][0]
        assert stack["counts"] == {
            "ordinary": 2,
            "running": 1,
            "one_offs": 1,
            "one_off_running": 1,
        }
        assert {
            row["container"]["resource"] for row in stack["services"][0]["members"]
        } == {"container:" + name for name in ids}
        evidence["states"]["mixed"] = mixed
        passed("real running/stopped replicas and one-off reach the actual Core/API")
        CATALOG.chmod(0o666)

        def refused_source():
            status, _, value = api("/api/v1/deployment/stacks", cookie=cookie)
            evidence["states"]["last"] = value
            return (
                value
                if status == 200
                and value["catalog"]["state"] == "stale"
                and value["engine"]["state"] == "fresh"
                else None
            )

        refused = eventually(refused_source)
        assert (
            refused["stacks"][0]["counts"] is None
            and refused["catalog"]["sampled_at"] == mixed["catalog"]["sampled_at"]
        )
        evidence["states"]["catalog_refused"] = refused
        CATALOG.chmod(0o644)
        restored = eventually(lambda: fresh("partial"))
        assert restored["catalog"]["sampled_at"] > mixed["catalog"]["sampled_at"]
        passed(
            "genuine writable-catalog refusal retains stale facts and recovery requires a new sample"
        )
        run("systemctl", "restart", "limeos-core")
        eventually(
            lambda: (
                run("/usr/lib/limeos/limeosctl", "status", check=False).returncode == 0
            )
        )
        restored = eventually(lambda: fresh("partial"))
        evidence["states"]["core_restarted"] = restored
        passed("Core restart recovers cache through the installed read-only path")
        evidence["resources"]["final"] = metrics()
        assert evidence["resources"]["final"]["memory.max"] == str(64 * 1024**2)
        assert evidence["resources"]["final"]["pids.max"] == "16"
        events = dict(
            line.split()
            for line in evidence["resources"]["final"]["memory.events"].splitlines()
        )
        assert (
            events["oom"] == "0" and events["oom_kill"] == "0" and events["max"] == "0"
        )
        if evidence["resources"]["final"]["memory.peak"] is not None:
            assert int(evidence["resources"]["final"]["memory.peak"]) < 64 * 1024**2
        evidence["resources"]["observed_maxima"] = maxima
        passed(
            "unchanged whole-service memory/task limits hold across collection and refusal"
        )
        evidence["status"] = "passed"
    except BaseException as error:
        evidence["status"] = "failed"
        evidence["error"] = repr(error)
        evidence["resources"]["observed_maxima"] = maxima
        if Path("/root/stack-reader.strace").exists():
            evidence["strace_tail"] = Path("/root/stack-reader.strace").read_text()[
                -18000:
            ]
        evidence["journal"] = run(
            "journalctl",
            "-u",
            UNIT,
            "-u",
            "limeos-core",
            "--no-pager",
            "-n",
            "80",
            check=False,
        ).stdout[-18000:]
        try:
            evidence["resources"]["failure"] = metrics()
        except (OSError, subprocess.SubprocessError):
            pass
        print("STACK_FAILURE=" + json.dumps(evidence), flush=True)
        raise
    finally:
        stop.set()
        if observer:
            observer.join(timeout=2)
        evidence["resources"]["observed_maxima"] = maxima
        output.write_text(json.dumps(evidence, indent=2) + "\n")


if __name__ == "__main__":
    main()
