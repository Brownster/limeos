#!/usr/bin/env -S uv run --offline
# /// script
# dependencies = []
# ///
"""Package local media configuration checks without rerunning passing suites."""

import gzip
import hashlib
import json
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/media-local-config"
output = root / "docs/rewrite-evidence/p04/2026-10-15-media-local-config"
output.mkdir(parents=True, exist_ok=True)
source = (cache / "source.txt").read_text().strip()
assert source == "ee83fefc99468000afd509d79b9e769fd187535a"
assert not (cache / "source-status.log").read_text().strip()
assert (
    "109 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out"
    in (cache / "test-reviewed.log").read_text()
)
assert "Finished" in (cache / "clippy.log").read_text()
assert not (cache / "rustfmt.log").read_text()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


paths = (cache / "input-paths.txt").read_text().splitlines()
paths.append("tests/fixtures/storage-contracts.json")
paths = sorted(set(paths))
(output / "inputs.sha256").write_text(
    "".join(f"{digest(root / name)}  {name}\n" for name in paths)
)
reference = Path("/home/marc/Documents/github/pi-health")
reference_paths = [
    "media_seed_service.py",
    "tests/test_media_seed_service.py",
    "catalog/transmission.yaml",
    "catalog/sabnzbd.yaml",
]
(output / "frozen-inputs.sha256").write_text(
    "".join(
        f"{digest(reference / name)}  {reference / name}\n" for name in reference_paths
    )
)
files = {
    "test.log": "test-reviewed.log",
    "clippy.log": "clippy.log",
    "rustfmt.log": "rustfmt.log",
    "prepare.log": "prepare.log",
    "cargo-metadata.json": "cargo-metadata.json",
    "rustc-version.log": "rustc-version.log",
    "cargo-version.log": "cargo-version.log",
    "test-initial.log": "test-initial.log",
    "collision-red.log": "collision-red.log",
    "ini-collision-red.rs": "ini-collision-red.rs",
    "tests-collision-red.rs": "tests-collision-red.rs",
    "source-status.log": "source-status.log",
    "package-evidence.py": "package-evidence.py",
    "ruff.log": "ruff.log",
    "ruff-format.log": "ruff-format.log",
}
for name, original in files.items():
    (output / f"{name}.gz").write_bytes(
        gzip.compress((cache / original).read_bytes(), mtime=0)
    )
harness = output / "harness"
harness.mkdir(exist_ok=True)
for name in ["Cargo.toml", "Cargo.lock", "lib.rs"]:
    (harness / name).write_bytes((root / ".cache/catalog-leaf" / name).read_bytes())
metadata = {
    "source": source,
    "base": "25c9cbe",
    "product_committed_after_checks_without_intervening_changes": True,
    "cases": {
        "local_config": 24,
        "catalog_and_namespace": 37,
        "media": 21,
        "activity": 15,
        "discovery": 12,
    },
    "total": 109,
    "bounds": {
        "input_bytes": 65536,
        "output_bytes": 65536,
        "path_bytes": 512,
        "fields": 128,
        "ini_lines": 2048,
        "depth": 32,
    },
    "input_count": len(paths),
    "frozen_source": "80593b29443ea9b81eb60ed4e5c3c3ac7a236204",
    "frozen_input_count": len(reference_paths),
    "commands": [
        "uv run --offline --no-project tests/fixtures/deployment/catalog/check-leaf.py",
        "cargo test --offline --locked --manifest-path .cache/catalog-leaf/Cargo.toml",
        "cargo clippy --offline --locked --manifest-path .cache/catalog-leaf/Cargo.toml --all-targets -- -D warnings",
        "rustfmt --edition 2024 --check crates/domain/src/deployment/mod.rs crates/domain/src/deployment/local_config.rs crates/domain/src/deployment/local_config/json.rs crates/domain/src/deployment/local_config/ini.rs crates/domain/src/deployment/local_config/tests.rs",
    ],
    "environment": {
        "CARGO_BUILD_JOBS": "1",
        "CARGO_INCREMENTAL": "0",
        "RUST_TEST_THREADS": "2",
        "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
    },
    "limits": "Pure local domain/harness checks; no registration, execution, API/UI, ARM64 or host acceptance",
}
(output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
artifacts = sorted(
    path
    for path in output.rglob("*")
    if path.is_file() and path.name != "artifacts.sha256"
)
(output / "artifacts.sha256").write_text(
    "".join(f"{digest(path)}  {path.relative_to(output)}\n" for path in artifacts)
)
print(
    json.dumps(
        {
            "source": source,
            "inputs": len(paths),
            "artifacts": len(artifacts),
            "tests": 109,
        }
    )
)
