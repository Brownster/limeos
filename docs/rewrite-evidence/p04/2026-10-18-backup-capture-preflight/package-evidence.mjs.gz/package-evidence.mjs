import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, readdirSync, statSync } from "node:fs";
import { gzipSync } from "node:zlib";
const scratch=".cache/capture-preflight";
const packet="docs/rewrite-evidence/p04/2026-10-18-backup-capture-preflight";
const sha=data=>createHash("sha256").update(data).digest("hex");
const source=readFileSync(`${scratch}/tested-source.txt`,"utf8").trim();
assert.equal(source,"bf9a90959924617b36fe37022f22dde8ef7dad00");
const paths=readFileSync(`${scratch}/input-paths.txt`,"utf8").trim().split("\n").sort();
writeFileSync(`${packet}/inputs.sha256`,paths.map(path=>`${sha(readFileSync(path))}  ${path}\n`).join(""));
const output=readFileSync(`${scratch}/archive-tests.log`,"utf8");
const results=[...output.matchAll(/^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;/gm)].map(match=>({passed:Number(match[1]),failed:Number(match[2]),ignored:Number(match[3]),measured:Number(match[4]),filtered:Number(match[5])}));
assert.deepEqual(results.map(row=>row.passed),[87,32,2,11,11,5]);
assert.ok(results.every(row=>row.failed===0&&row.ignored===0&&row.measured===0&&row.filtered===0));
const measurement=readFileSync(`${scratch}/descriptor-measurement.log`,"utf8");
assert.ok(measurement.includes("objects=256, logical_bytes=2048, added_retained_fds=258, record_bytes=152862"));
const changed=readFileSync(`${scratch}/changed-paths.txt`,"utf8").trim().split("\n");
assert.equal(changed.length,4);
assert.ok(changed.every(path=>path.includes("crates/backup-archive/src/before_images")||path.endsWith("docs/plans/2026-10-17-backup-capture-preflight-design.md")));
const manifest={tested_source:source,base:"7df3f7530865c31b7faefd1f7b12a25aa7655860",branch:"engineer/p04-backup-capture-preflight",rustc:readFileSync(`${scratch}/rustc.txt`,"utf8"),cargo:readFileSync(`${scratch}/cargo.txt`,"utf8").trim(),packager_node:process.version,input_count:paths.length,input_bytes:paths.reduce((sum,path)=>sum+statSync(path).size,0),source_changes:changed,checks:results,passed:148,new_unit_cases:12,new_compile_fail_cases:1,baseline_filter_passed:18,descriptor_fixture:{objects:256,logical_bytes:2048,planning_added_descriptors:0,captured_retained_descriptors:258,record_bytes:152862,transient_allowance:1,transient_allowance_basis:"code-derived, not measured process peak"},environment:{CARGO_BUILD_JOBS:"1",CARGO_INCREMENTAL:"0",RUST_TEST_THREADS:"1",CARGO_TARGET_DIR:"/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",TMPDIR:"/home/marc/Documents/github/lime-os/.cache/tmp",CCACHE_DIR:"/home/marc/Documents/github/lime-os/.cache/ccache"},installed_acceptance:"UNRUN",whole_worker_admission:"Not implemented by this slice",phase_completion:"Not claimed"};
writeFileSync(`${packet}/manifest.json`,JSON.stringify(manifest,null,2)+"\n");
for(const path of [...readdirSync(scratch).filter(path=>path.endsWith(".log")),"rustc.txt","cargo.txt","changed-paths.txt","tested-source.txt","input-paths.txt","package-evidence.mjs"]){
  writeFileSync(`${packet}/${path}.gz`,gzipSync(readFileSync(`${scratch}/${path}`),{level:9}));
}
writeFileSync(`${packet}/Cargo.lock.gz`,gzipSync(readFileSync("Cargo.lock"),{level:9}));
const artifacts=readdirSync(packet).filter(path=>path!=="artifacts.sha256").sort();
writeFileSync(`${packet}/artifacts.sha256`,artifacts.map(path=>`${sha(readFileSync(`${packet}/${path}`))}  ${path}\n`).join(""));
console.log(JSON.stringify({source,inputs:paths.length,artifacts:artifacts.length,passed:148}));
