#!/usr/bin/env -S uv run --offline
# /// script
# dependencies = []
# ///
"""Bind the already completed focused checks to committed source and fixtures."""

import gzip
import hashlib
import json
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / ".cache/network-group-leaf"
PACKET = ROOT / "docs/rewrite-evidence/p04/2026-10-15-network-groups"
CODE = "c25dbe59a0c85d445061ad03b67629a7b28f9a90"
FROZEN = "80593b29443ea9b81eb60ed4e5c3c3ac7a236204"
REFERENCE = Path("/home/marc/Documents/github/pi-health")


def run(*args: str, cwd: Path = ROOT) -> bytes:
    return subprocess.check_output(args, cwd=cwd)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


assert run("git", "rev-parse", "HEAD").decode().strip() == CODE
files = (
    run(
        "git",
        "ls-files",
        "Cargo.toml",
        "Cargo.lock",
        "crates/domain",
        "crates/executor-container/Cargo.toml",
        "crates/executor-container/src/deployment/mod.rs",
        "crates/executor-container/src/deployment/networks.rs",
        "crates/executor-container/src/deployment/networks",
        "tests/fixtures/deployment/networks",
        "tests/fixtures/deployment/discovery",
    )
    .decode()
    .splitlines()
)
sources = {}
for name in files:
    data = (ROOT / name).read_bytes()
    assert data == run("git", "show", f"{CODE}:{name}"), name
    sources[name] = sha(data)
reference = {}
for name in [
    "container_helpers.py",
    "network_group_service.py",
    "tests/test_containers.py",
    "tests/test_network_group_service.py",
]:
    data = run("git", "show", f"{FROZEN}:{name}", cwd=REFERENCE)
    assert data == (REFERENCE / name).read_bytes(), name
    reference[name] = sha(data)

test = (CACHE / "test-final.log").read_text()
assert "19 passed; 0 failed" in test and "35 passed; 0 failed" in test
assert "FAILED" not in test and "filtered out" in test
assert "Finished `dev`" in (CACHE / "clippy.log").read_text()
assert "error:" not in (CACHE / "clippy.log").read_text()
assert (CACHE / "rustfmt.log").read_bytes() == b""
assert "All checks passed!" in (CACHE / "ruff.log").read_text()
assert "already formatted" in (CACHE / "ruff-format.log").read_text()
for name in ["health-red", "prefix-red", "shape-red"]:
    assert "FAILED" in (CACHE / f"{name}.log").read_text()
for name in [
    "Cargo.toml",
    "Cargo.lock",
    "domain/Cargo.toml",
    "domain/lib.rs",
    "adapter/Cargo.toml",
    "adapter/lib.rs",
]:
    target = PACKET / "harness" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(CACHE / name, target)
for path in sorted(CACHE.glob("*.log")):
    (PACKET / f"{path.name}.gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for path in sorted(CACHE.glob("*-red-source.rs.gz")):
    shutil.copyfile(path, PACKET / path.name)
for name in ["cargo-metadata.json", "package-evidence.py"]:
    (PACKET / f"{name}.gz").write_bytes(
        gzip.compress((CACHE / name).read_bytes(), mtime=0)
    )
commands = [
    (
        "cargo test --offline --locked --manifest-path .cache/network-group-leaf/Cargo.toml",
        "test-final.log.gz",
    ),
    (
        "cargo clippy --offline --locked --manifest-path .cache/network-group-leaf/Cargo.toml --all-targets -- -D warnings",
        "clippy.log.gz",
    ),
    (
        "rustfmt --check --edition 2024 crates/domain/src/deployment/mod.rs crates/executor-container/src/deployment/mod.rs",
        "rustfmt.log.gz",
    ),
    (
        "uv run --offline --no-project --with ruff==0.17.0 ruff check tests/fixtures/deployment/networks/check-leaves.py",
        "ruff.log.gz",
    ),
    (
        "uv run --offline --no-project --with ruff==0.17.0 ruff format --check tests/fixtures/deployment/networks/check-leaves.py",
        "ruff-format.log.gz",
    ),
]
metadata = {
    "recorded_at_utc": datetime.now(UTC).isoformat(),
    "source_commit": CODE,
    "base_commit": run("git", "rev-parse", "5e275ca").decode().strip(),
    "branch": "engineer/p04-network-groups",
    "source_files_sha256": sources,
    "frozen_reference": {
        "commit": FROZEN,
        "files_sha256": reference,
        "execution": "Read/hash only; never imported or executed",
    },
    "tests": {
        "network_topology": 23,
        "inspect_adapter": 19,
        "existing_b2_domain": 12,
        "total": 54,
        "filtered": 0,
    },
    "fixtures": {
        "synthetic_inspect_documents": 3,
        "synthetic_health_cases": 7,
        "live_engine_captures": 0,
    },
    "tool_versions": {
        "rustc": (CACHE / "rustc.txt").read_text().strip(),
        "cargo": (CACHE / "cargo.txt").read_text().strip(),
        "clippy": run("cargo", "clippy", "--version").decode().strip(),
        "rustfmt": run("rustfmt", "--version").decode().strip(),
        "uv": run("uv", "--version").decode().strip(),
        "ruff": "0.17.0 (explicit cached uv pin)",
    },
    "environment": {
        "CARGO_BUILD_JOBS": "1",
        "CARGO_INCREMENTAL": "0",
        "RUST_TEST_THREADS": "2 for tests",
        "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
        "cargo_suites": "Sequential, prior process completion observed before each next invocation",
    },
    "checks": [
        {"command": command, "exit_code": 0, "log": log} for command, log in commands
    ],
    "diagnostics": [
        "health-red: configured healthcheck without State.Health was incorrectly NotConfigured, now Unknown",
        "prefix-red: 1-11 character hex ID references were incorrectly MissingProvider, now UnsupportedContainerPrefix",
        "shape-red: derived healthcheck struct accepted [], now all consumed objects require maps",
        "red-source snapshots are individual intermediate files, not a complete qualified checkout",
        "initial deep-ignored-payload test expected rejection incorrectly; pinned serde_json skips iteratively within the byte cap; corrected test checks non-retention and malformed nesting",
        "test-second: earlier 51-test green before later regressions; no final acceptance beyond final log",
        "initial Ruff check found non-executable shebang; file mode corrected before passing final checks",
    ],
    "registration": {
        "runtime": False,
        "protected_collector": False,
        "shared_roots_modified": False,
        "production_manifests_lock_modified": False,
        "api_ui": False,
        "host_effects": False,
    },
    "limits": [
        "Plain configured-reference diagnostics, never namespace/VPN/health authority or execution evidence",
        "No Engine/probe/network/process/filesystem collection or mutation in these helpers",
        "No genuine protected owner/whole-worker budgets, installed lifecycle/recovery or API/UI/browser acceptance",
        "No B2 reader/API/UI suite rerun, package/ARM64/Pi/performance/soak or cutover qualification",
        "No phase/registered milestone closure; central and qualification ownership unchanged",
    ],
}
(PACKET / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
artifacts = [
    p for p in sorted(PACKET.rglob("*")) if p.is_file() and p.name != "SHA256SUMS"
]
(PACKET / "SHA256SUMS").write_text(
    "".join(f"{sha(p.read_bytes())}  {p.relative_to(PACKET)}\n" for p in artifacts)
)
print(
    f"Bound {len(sources)} committed source inputs and {len(artifacts)} packet artifacts"
)
