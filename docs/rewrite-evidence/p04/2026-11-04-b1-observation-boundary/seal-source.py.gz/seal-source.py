# /// script
# dependencies = []
# ///
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-observation-boundary-qualification'
out = root / 'docs/rewrite-evidence/p04/2026-11-04-b1-observation-boundary'
assert not (out / 'SHA256SUMS').exists()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
summary = json.loads((out / 'source-match.json').read_text())
result = json.loads((out / 'installed-result.json').read_text())
boundary = json.loads((out / 'boundary-observations.json').read_text())
manifest = json.loads((state / 'inputs-1.json').read_text())
native = json.loads((root / '.cache/main-consolidation/attempts/b1-observation-boundary-reference-1/record.json').read_text())
current = {name: sha(root / name) for name in native['before']}
assert current == native['before'] == native['after']
assert result['stage'] == 'incident' and result['summary'] == 'fail'
assert len(result['passed']) == 2 and 'Timed out' in result['error']
assert all(result['history_after_failure'][key] == [] for key in ('jobs', 'occurrences', 'results', 'alerts', 'notifications'))
assert boundary == result['boundary_observations']
assert all(boundary[key]['available'] for key in ('runtime', 'health', 'core', 'reader'))
runtime = boundary['runtime']['value']
assert runtime['partial'] is True and len(runtime['items']) == 1
view = runtime['items'][0]
assert view['status'] == 'scheduled' and view['runtime']['phase'] == 'unavailable'
assert view['runtime']['last_attempt'] == 1793833213
assert view['schedule']['id'] == result['created_schedule']['schedule']['id']
probe = boundary['health']['value']
assert probe['returncode'] == 0 and probe['client_uid'] == result['reader_policy']['core_uid'] == 104
assert probe['peer'] == {'pid': 6146, 'uid': 0, 'gid': 113}
assert 0 < probe['elapsed_seconds'] < 4
reply = probe['reply']
assert set(reply) == {'container_health', 'ready', 'version'} and reply['ready'] is True and reply['version'] == 1
cohort = reply['container_health']
assert cohort['nonce'] == probe['nonce'] and re.fullmatch('[0-9a-f]{64}', probe['nonce'])
assert cohort['engine_id'] == result['docker']['id']
assert cohort['complete'] is True and len(cohort['members']) == 1
assert cohort['sampled_at'] == 1793833213
member = cohort['members'][0]
assert member['resource'] == member['signal']['key'] == 'container:' + result['container_id']
assert member['signal']['status'] == 'failing' and member['signal']['kind'] == 'container'
assert boundary['reader']['value']['pid'] == int(boundary['reader']['value']['unit']['MainPID']) == probe['peer']['pid']
assert [int(x) for x in boundary['core']['value']['status']['Uid'].split()] == [probe['client_uid']] * 4
for key, memory, tasks, nofile in (('core', '134217728', '32', '1024'), ('reader', '67108864', '16', '256')):
    value = boundary[key]['value']
    assert value['unit']['MemoryMax'] == memory and value['unit']['TasksMax'] == tasks and value['unit']['LimitNOFILE'] == nofile
    assert value['status']['NoNewPrivs'] == '1'
    assert all(value['status'][cap] == '0000000000000000' for cap in ('CapEff', 'CapPrm', 'CapBnd'))
    memory_events = dict(line.split() for line in value['cgroup']['memory.events'].splitlines())
    assert all(memory_events[name] == '0' for name in ('max', 'oom', 'oom_kill'))
    assert value['cgroup']['pids.events'] == 'max 0\n'
checks = []
for command in ([sys.executable, 'scripts/check_repository.py'], ['git', 'diff', '--check']):
    value = subprocess.run(command, cwd=root, text=True, capture_output=True)
    checks.append({'command': command, 'exit_code': value.returncode, 'stdout': value.stdout, 'stderr': value.stderr})
    assert value.returncode == 0, checks[-1]
links = []
for document in (out / 'README.md', root / 'docs/p04-b1-observation-supervisor-handoff.md', root / 'docs/rewrite-evidence/p04/2026-10-05-execution-tracker.md', root / 'docs/plans/2026-11-04-b1-installed-observation-qualification-design.md'):
    for target in re.findall(r'\]\(([^)]+)\)', document.read_text()):
        if '://' in target or target.startswith('#'): continue
        assert (document.parent / target.partition('#')[0]).exists(), (document, target)
        links.append({'document': str(document.relative_to(root)), 'target': target})
for path in out.rglob('*.gz'): gzip.decompress(path.read_bytes())
with tarfile.open(out / 'reproduction-sources.tar.gz', 'r:gz') as archive:
    names = archive.getnames()
    assert len([name for name in names if name.startswith('guest/')]) == 30
    assert all(not name.startswith('/') and '..' not in Path(name).parts for name in names)
    for name, expected in manifest['guest'].items(): assert hashlib.sha256(archive.extractfile('guest/' + name).read()).hexdigest() == expected
    assert hashlib.sha256(archive.extractfile('harness/guard.py').read()).hexdigest() == '380a78ebd9dbb3902a97bebbcdb164df1e6bfc4c069b56a45092af6eb26813d6'
verification = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source': summary['fixture_source'],
    'current_fixture_inputs_match': len(current), 'commands': checks, 'relative_links_checked': len(links), 'links': links,
    'gzip_files_readable': True, 'reproduction_members': len(names), 'failure_and_independent_health_joins_verified': True,
    'sealer_sha256': sha(Path(__file__))}
(out / 'final-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
(out / 'seal-source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
files = sorted(path for path in out.rglob('*') if path.is_file())
(out / 'SHA256SUMS').write_text(''.join(sha(path) + '  ' + str(path.relative_to(out)) + '\n' for path in files))
for line in (out / 'SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    assert sha(out / name) == expected
print(json.dumps({'checksums_verified': len(files), 'fixture_inputs': len(current), 'relative_links': len(links), 'independent_root_health_joins_verified': True}))
