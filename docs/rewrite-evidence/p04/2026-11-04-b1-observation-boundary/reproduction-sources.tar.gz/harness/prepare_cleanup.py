# /// script
# dependencies = []
# ///
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-observation-boundary-qualification'
value = (root / '.cache/b1-installed-observation-qualification/observe_cleanup.py').read_text().replace('b1-installed-observation', 'b1-observation-boundary')
value = value.replace("'reference-launch.json', 'reference-2-launch.json', 'guard-launch-1.json'", "'reference-launch.json', 'guard-launch-1.json'")
value = value.replace("'b1-observation-boundary-reference-1', 'b1-observation-boundary-reference-2', 'b1-observation-boundary-vm-1'", "'b1-observation-boundary-reference-1', 'b1-observation-boundary-vm-1'")
with (state / 'observe_cleanup.py').open('x') as stream: stream.write(value)
