# /// script
# dependencies = []
# ///
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
old = root / '.cache/b1-installed-observation-qualification'
state = root / '.cache/b1-observation-boundary-qualification'
for name in ('check_reference.py', 'launch_reference.py'):
    value = (old / name).read_text().replace('b1-installed-observation', 'b1-observation-boundary')
    with (state / name).open('x') as stream: stream.write(value)
