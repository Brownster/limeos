# /// script
# dependencies = []
# ///
from pathlib import Path
import subprocess
import sys
root = Path('/home/marc/Documents/github/lime-os')
old = root / '.cache/b1-installed-observation-qualification'
state = root / '.cache/b1-observation-boundary-qualification'
for source, target in (('prepare_vm.py', 'freeze_vm.py'), ('launch_vm.py', 'launch_vm.py'), ('observe_vm.py', 'observe_vm.py')):
    value = (old / source).read_text().replace('b1-installed-observation', 'b1-observation-boundary')
    if source == 'prepare_vm.py': value = value.replace('reference-2', 'reference-1')
    with (state / target).open('x') as stream: stream.write(value)
subprocess.run([sys.executable, str(state / 'freeze_vm.py')], check=True, cwd=root)
