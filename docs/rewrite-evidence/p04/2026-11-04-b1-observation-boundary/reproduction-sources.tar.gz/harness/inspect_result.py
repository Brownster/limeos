# /// script
# dependencies = []
# ///
import json
from pathlib import Path
state = Path('/home/marc/Documents/github/lime-os/.cache/b1-observation-boundary-qualification')
attempt = state.parent / 'main-consolidation/attempts/b1-observation-boundary-vm-1'
values = {}
for prefix in ('B1_FAILURE', 'B1_OBSERVATION'):
    rows = [json.loads(line.partition(' ')[2]) for line in (attempt / 'output.log').read_text().splitlines() if line.startswith(prefix + ' ')]
    assert len(rows) == 1
    values[prefix] = rows[0]
with (state / 'structured-result.json').open('x') as stream: json.dump(values, stream, indent=2)
print(json.dumps({'failure': {key: values['B1_FAILURE'].get(key) for key in ('stage', 'error', 'history_after_failure')}, 'observations': values['B1_OBSERVATION']}, indent=2))
