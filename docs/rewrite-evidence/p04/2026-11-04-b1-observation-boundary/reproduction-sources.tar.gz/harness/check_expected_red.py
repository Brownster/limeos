# /// script
# dependencies = []
# ///
from pathlib import Path
import subprocess
import sys
state = Path('/home/marc/Documents/github/lime-os/.cache/b1-observation-boundary-qualification')
with (state / 'expected-red.log').open('xb') as log:
    value = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_p04_automation_guest.py', '-v'], stdout=log, stderr=subprocess.STDOUT)
print((state / 'expected-red.log').read_text())
raise SystemExit(value.returncode)
