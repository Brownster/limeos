# /// script
# dependencies = []
# ///
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-observation-boundary-qualification'
value = (root / '.cache/b1-installed-observation-qualification/archive_evidence.py').read_text().replace('b1-installed-observation', 'b1-observation-boundary')
value = value.replace("native = read(attempts / 'b1-observation-boundary-reference-2/record.json')", "native = read(attempts / 'b1-observation-boundary-reference-1/record.json')")
old = "for label in ('b1-observation-boundary-reference-1', 'b1-observation-boundary-reference-2', 'b1-observation-boundary-vm-1'):"
assert value.count(old) == 1
value = value.replace(old, "for label in ('b1-observation-boundary-red-1', 'b1-observation-boundary-reference-1', 'b1-observation-boundary-vm-1'):")
value = value.replace("'native_reference_cases': 18", "'native_reference_cases': 22")
needle = 'out.mkdir(exist_ok=False)'
assert value.count(needle) == 1
value = value.replace(needle, "observations = [json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith('B1_OBSERVATION ')]\nif not accepted:\n    assert len(observations) == 1 and observations[0] == result['boundary_observations']\n" + needle)
needle = "(out / 'source-match.json').write_text(json.dumps(summary, indent=2) + '\\n')"
assert value.count(needle) == 1
value = value.replace(needle, "summary['expected_red_tool_session'] = {'session_id': 63287, 'terminal_exit_code': 1, 'native_pid_absence_claimed': False, 'scope': 'sandbox PID namespace'}\nsummary['standalone_boundary_observation_count'] = len(observations)\nif observations:\n    (out / 'boundary-observations.json').write_text(json.dumps(observations[0], indent=2) + '\\n')\n" + needle)
with (state / 'archive_evidence.py').open('x') as stream: stream.write(value)
