# /// script
# dependencies = []
# ///
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-profile-qualification'
builders = root / '.cache/stack-installed-qualification'
attempts = root / '.cache/main-consolidation/attempts'
out = root / 'docs/rewrite-evidence/p04/2026-11-04-b1-core-profile'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text())
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
manifest = read(state / 'inputs-1.json')
packages = read(builders / 'candidate-12/inputs.json')
build = read(builders / 'build-12/record.json')
native = read(attempts / 'b1-core-profile-reference-1/record.json')
vm = read(attempts / 'b1-core-profile-vm-1/record.json')
result = read(state / 'result-1.json')
cleanup = read(state / 'cleanup.json')
assert head == manifest['fixture_source'] == vm['head']
assert manifest['product_source'] == packages['source'] == build['source']
assert sha(builders / 'candidate-12/inputs.json') == manifest['package_inputs_sha256']
assert sha(builders / 'build-12/record.json') == manifest['build_record_sha256']
assert native['before'] == native['after'] == vm['before'] == vm['after']
for name, expected in native['before'].items():
    assert sha(root / name) == expected
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=root)).hexdigest() == expected
for name, expected in build['before'].items(): assert native['before'][name] == expected
for name, expected in manifest['guest'].items(): assert sha(state / 'guest-1' / name) == expected
assert sha(state / 'run_1024.py') == manifest['runner_sha256'] == sha(root / 'tests/privileged_vm/run.py')
assert result['summary'] == 'pass' and result['stage'] == 'complete'
assert result['before'] == result['after']
assert result['before']['unit_sha256'] == sha(root / 'packaging/systemd/limeos-core.service') == sha(root / 'tests/fixtures/automation/core-profile-baseline.service')
assert result['fixture_sha256'] == manifest['guest']['p04_core_profile_guest.py']
assert result['probe_sha256'] == manifest['guest']['p04_core_lookup_probe.py']
assert result['package_sha256'] == packages['packages']
for name, expected in result['binary_sha256'].items(): assert expected == packages['binaries'][name]['sha256']
for value in (native, vm): assert value['exit_code'] == 0 and value['ended'] and value['inputs_unchanged'] and not value['guard_triggered']
assert cleanup['recorded_native_pids_absent'] == 4 and not cleanup['current_qualification_qemu']
assert all(value['timestamps_precede_this_run'] for value in cleanup['current_canonical_vm_scratch'])
assert cleanup['original_qemu_pid_captured'] is False
out.mkdir(exist_ok=False)
def archive(name, path):
    target = out / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for label in ('b1-core-profile-reference-1', 'b1-core-profile-vm-1'):
    for name in ('record.json', 'output.log'): archive('checks/' + label + '-' + name, attempts / label / name)
for path in sorted(state.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.log', '.txt'): archive('observations/' + path.name, path)
archive('package-inputs.json', builders / 'candidate-12/inputs.json')
archive('build-record.json', builders / 'build-12/record.json')
sources = {'guest/' + p.name: p for p in sorted((state / 'guest-1').glob('*.py'))}
sources.update({'harness/' + p.name: p for p in sorted(state.glob('*.py'))})
sources['harness/guard.py'] = root / '.cache/main-consolidation/guard.py'
sources['harness/detached_guard.py'] = builders / 'detached_guard.py'
sources['reference/test_core_socket_profile.py'] = root / 'tests/reference/test_core_socket_profile.py'
sources['reference/core-profile-baseline.service'] = root / 'tests/fixtures/automation/core-profile-baseline.service'
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for name, path in sorted(sources.items()):
        data = path.read_bytes()
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(data), 0o644, 0
        tar.addfile(item, io.BytesIO(data))
(out / 'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
(out / 'installed-matrix.json').write_text(json.dumps(result, indent=2) + '\n')
summary = {'fixture_source': head, 'product_source': packages['source'], 'original_product_inputs_unchanged': len(build['before']),
    'fixture_inputs_match_commit': len(native['before']), 'test_only_changes_since_package_build': manifest['test_only_changes_since_package_build'],
    'native_reference_cases': 27, 'native_precommit_head': native['head'], 'guest_modules': len(manifest['guest']), 'canonical_runner_unchanged': True,
    'vm': {k: vm[k] for k in ('started','ended','exit_code','minimum_available_bytes','guard_triggered','inputs_unchanged')},
    'matrix_errno': {name: value['probe']['openat2_errno'] for name, value in result['variants'].items()},
    'real_core_unit_pid_authority_unchanged': True, 'recorded_native_pids_absent': 4,
    'original_qemu_identity_captured': False, 'canonical_runner_returned_after_wait_and_temp_cleanup': True,
    'later_matching_qemu_inventory': [], 'older_unattributed_scratch_preserved': len(cleanup['current_canonical_vm_scratch']),
    'ordinary_timer_accepted': False, 'b1_complete': False, 'arm64_pi_qualified': False}
(out / 'source-match.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'source': head, 'matrix': summary['matrix_errno'], 'fixture_inputs': len(native['before'])}))
