# /// script
# dependencies = []
# ///
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
old = root / '.cache/b1-installed-observation-qualification'
state = root / '.cache/b1-core-profile-qualification'
value = (old / 'check_reference.py').read_text().replace('b1-installed-observation', 'b1-core-profile')
needle = 'commands = [\n'
assert value.count(needle) == 1
value = value.replace(needle, needle + "    [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_core_socket_profile.py', '-v'],\n")
old_paths = "'tests/privileged_vm/p04_automation_guest.py', 'tests/reference/test_p04_automation_guest.py'"
new_paths = "'tests/privileged_vm/p04_core_lookup_probe.py', 'tests/privileged_vm/p04_core_profile_guest.py', 'tests/reference/test_core_socket_profile.py'"
assert value.count(old_paths) == 2
value = value.replace(old_paths, new_paths)
with (state / 'check_reference.py').open('x') as stream: stream.write(value)
value = (old / 'launch_reference.py').read_text().replace('b1-installed-observation', 'b1-core-profile')
with (state / 'launch_reference.py').open('x') as stream: stream.write(value)
