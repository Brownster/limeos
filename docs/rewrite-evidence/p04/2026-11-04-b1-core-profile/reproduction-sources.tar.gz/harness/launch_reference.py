# /// script
# dependencies = []
# ///
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-profile-qualification'
label = 'b1-core-profile-reference-1'
assert not (root / '.cache/main-consolidation/attempts' / label).exists()
busy = [x for x in subprocess.check_output(['ps', '-eo', 'comm'], text=True).splitlines() if x.strip() in ('cargo', 'rustc', 'rustdoc')]
available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
admission = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'available_bytes': available, 'start_threshold_bytes': 4 * 1024**3, 'runtime_stop_floor_bytes': 3 * 1024**3, 'external_compilers': busy, 'admitted': not busy and available >= 4 * 1024**3}
(state / 'reference-admission.json').write_text(json.dumps(admission, indent=2) + '\n')
if not admission['admitted']: raise SystemExit(75)
wrapper = root / '.cache/stack-installed-qualification/detached_guard.py'
command = [sys.executable, str(wrapper), label, sys.executable, str(state / 'check_reference.py')]
with (state / 'reference-console.log').open('xb') as log:
    child = subprocess.Popen(command, cwd=root, start_new_session=True, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
raw = (Path('/proc') / str(child.pid) / 'stat').read_text()
value = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': child.pid, 'start_ticks': int(raw[raw.rindex(')') + 1:].split()[19]), 'session': os.getsid(child.pid), 'command': command, 'guard_sha256': hashlib.sha256((root / '.cache/main-consolidation/guard.py').read_bytes()).hexdigest()}
(state / 'reference-launch.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value))
