# /// script
# dependencies = []
# ///
import datetime
import json
from pathlib import Path
import subprocess
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-profile-qualification'
attempts = root / '.cache/main-consolidation/attempts'
identities = []
for name in ('reference-launch.json', 'guard-launch-1.json'):
    value = json.loads((state / name).read_text())
    identities.append({'source': name, 'pid': value['pid'], 'start_ticks': value['start_ticks']})
for name in ('b1-core-profile-reference-1', 'b1-core-profile-vm-1'):
    value = json.loads((attempts / name / 'record.json').read_text())
    assert value['ended'] and value['exit_code'] == 0
    identities.append({'source': name, 'pid': value['pid']})
for value in identities:
    value['proc_absent'] = not (Path('/proc') / str(value['pid'])).exists()
assert all(value['proc_absent'] for value in identities)
processes = subprocess.run(['ps', '-C', 'qemu-system-x86_64', '-o', 'pid,ppid,args='], text=True, capture_output=True)
assert processes.returncode in (0, 1)
matching = [line for line in processes.stdout.splitlines() if str(root / '.cache/main-consolidation/tmp/limeos-p01-vm-') in line]
vm_record = json.loads((attempts / 'b1-core-profile-vm-1/record.json').read_text())
started = datetime.datetime.fromisoformat(vm_record['started']).timestamp()
scratch = []
for path in sorted((root / '.cache/main-consolidation/tmp').glob('limeos-p01-vm-*')):
    meta = path.stat()
    scratch.append({'path': str(path), 'mtime': meta.st_mtime, 'ctime': meta.st_ctime,
                    'timestamps_precede_this_run': max(meta.st_mtime, meta.st_ctime) < started,
                    'ownership_attributed': False})
assert not matching and all(value['timestamps_precede_this_run'] for value in scratch)
value = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'recorded_original_processes': identities,
    'recorded_native_pids_absent': len(identities), 'current_qualification_qemu': matching, 'current_canonical_vm_scratch': scratch,
    'original_qemu_pid_captured': False, 'original_vm_temp_path_captured': False,
    'scope': 'Native original wrapper/command absence and independent later QEMU/scratch inventory; original QEMU identity was not observed',
    'canonical_runner_completed_with_wait_cleanup': True, 'older_unattributed_scratch_preserved': True, 'observation_only': True}
with (state / 'cleanup.json').open('x') as stream: json.dump(value, stream, indent=2)
print(json.dumps({'recorded_native_pids_absent': len(identities), 'current_qualification_qemu': len(matching), 'canonical_vm_scratch': len(scratch), 'original_qemu_identity_recorded': False}))
