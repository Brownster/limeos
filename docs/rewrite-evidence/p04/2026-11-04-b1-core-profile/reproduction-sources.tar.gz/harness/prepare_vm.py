# /// script
# dependencies = []
# ///
from pathlib import Path
import subprocess
import sys
root = Path('/home/marc/Documents/github/lime-os')
old = root / '.cache/b1-observation-boundary-qualification'
state = root / '.cache/b1-core-profile-qualification'
for source, target in (('freeze_vm.py', 'freeze_vm.py'), ('launch_vm.py', 'launch_vm.py'), ('observe_vm.py', 'observe_vm.py')):
    value = (old / source).read_text().replace('b1-observation-boundary', 'b1-core-profile')
    if source == 'freeze_vm.py':
        needle = "{'tests/privileged_vm/p04_automation_guest.py', 'tests/reference/test_p04_automation_guest.py'}"
        assert value.count(needle) == 1
        value = value.replace(needle, "{'tests/privileged_vm/p04_automation_guest.py', 'tests/reference/test_p04_automation_guest.py', 'tests/privileged_vm/p04_core_lookup_probe.py', 'tests/privileged_vm/p04_core_profile_guest.py', 'tests/reference/test_core_socket_profile.py', 'tests/fixtures/automation/core-profile-baseline.service'}")
        value = value.replace('Real installed AMD64 container-only observation API/runtime; no browser/ARM64/Pi/upgrade/return/soak acceptance', 'Disposable AMD64 fixed Core lookup profile matrix; no ordinary timer, UI, ARM64/Pi or upgrade/return/soak acceptance')
    if source == 'launch_vm.py': value = value.replace('guest-1/p04_automation_guest.py', 'guest-1/p04_core_profile_guest.py')
    with (state / target).open('x') as stream: stream.write(value)
subprocess.run([sys.executable, str(state / 'freeze_vm.py')], cwd=root, check=True)
