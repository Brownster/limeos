# /// script
# dependencies = []
# ///
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-profile-qualification'
out = root / 'docs/rewrite-evidence/p04/2026-11-04-b1-core-profile'
assert not (out / 'SHA256SUMS').exists()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
native = json.loads((root / '.cache/main-consolidation/attempts/b1-core-profile-reference-1/record.json').read_text())
current = {name: sha(root / name) for name in native['before']}
assert current == native['before'] == native['after']
result = json.loads((out / 'installed-matrix.json').read_text())
manifest = json.loads((state / 'inputs-1.json').read_text())
assert result['summary'] == 'pass' and result['before'] == result['after']
assert result['before']['unit_sha256'] == sha(root / 'packaging/systemd/limeos-core.service')
assert result['before']['core']['MainPID'] == '957'
assert result['control']['uid'] == result['core_uid'] == 104
assert result['control']['openat2_errno'] == 0 and result['control']['socket'] == result['socket']
assert {name: value['probe']['openat2_errno'] for name, value in result['variants'].items()} == {'baseline': 38, 'no-suid': 0, 'explicit': 38, 'both': 0}
baseline = result['installed_unit']
for name, row in result['variants'].items():
    changed = {a.partition('=')[0] for a,b in zip(baseline.splitlines(), row['unit'].splitlines()) if a != b}
    expected = {'ExecStart','RuntimeDirectory','Restart'}
    if name in ('no-suid','both'): expected.add('RestrictSUIDSGID')
    if name in ('explicit','both'): expected.add('SystemCallFilter')
    assert changed == expected and len(baseline.splitlines()) == len(row['unit'].splitlines())
    value = row['probe']
    assert value['uid'] == 104 and value['gid'] == result['rpc_gid'] == 112
    assert set(result['supplementary_gids']).issubset(value['groups'])
    assert value['status']['NoNewPrivs'] == '1' and value['status']['Seccomp'] == '2'
    assert all(value['status'][key] == '0000000000000000' for key in ('CapEff','CapPrm','CapBnd'))
    assert value['nofile'] == [1024,1024]
    assert row['properties']['MemoryMax'] == '134217728' and row['properties']['TasksMax'] == '32'
    if value['openat2_errno'] == 0: assert value['socket'] == result['socket']
checks = []
for command in ([sys.executable,'scripts/check_repository.py'], ['git','diff','--check']):
    value = subprocess.run(command,cwd=root,text=True,capture_output=True)
    checks.append({'command':command,'exit_code':value.returncode,'stdout':value.stdout,'stderr':value.stderr})
    assert value.returncode == 0
links = []
for document in (out / 'README.md', root / 'docs/p04-b1-observation-supervisor-handoff.md', root / 'docs/rewrite-evidence/p04/2026-10-05-execution-tracker.md', root / 'docs/plans/2026-11-04-b1-core-socket-profile-design.md'):
    for target in re.findall(r'\]\(([^)]+)\)', document.read_text()):
        if '://' in target or target.startswith('#'): continue
        assert (document.parent / target.partition('#')[0]).exists(), (document,target)
        links.append({'document':str(document.relative_to(root)),'target':target})
for path in out.rglob('*.gz'): gzip.decompress(path.read_bytes())
with tarfile.open(out / 'reproduction-sources.tar.gz','r:gz') as archive:
    names = archive.getnames()
    assert len([name for name in names if name.startswith('guest/')]) == 32
    assert all(not name.startswith('/') and '..' not in Path(name).parts for name in names)
    for name, expected in manifest['guest'].items(): assert hashlib.sha256(archive.extractfile('guest/'+name).read()).hexdigest() == expected
verification = {'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_fixture_inputs_match':len(current),
    'commands':checks,'relative_links_checked':len(links),'links':links,'gzip_files_readable':True,
    'reproduction_members':len(names),'matrix_and_preserved_profile_joins_verified':True,'sealer_sha256':sha(Path(__file__))}
(out / 'final-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(out / 'seal-source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
files = sorted(path for path in out.rglob('*') if path.is_file())
(out / 'SHA256SUMS').write_text(''.join(sha(path)+'  '+str(path.relative_to(out))+'\n' for path in files))
for line in (out / 'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    assert sha(out / name)==expected
print(json.dumps({'verified_files':len(files),'fixture_inputs':len(current),'relative_links':len(links),'matrix_verified':True}))
