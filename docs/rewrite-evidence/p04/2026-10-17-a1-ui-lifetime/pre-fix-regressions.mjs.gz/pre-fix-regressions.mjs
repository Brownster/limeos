import { readFile } from "node:fs/promises";
import test from "node:test";
import assert from "node:assert/strict";
import ts from "/home/marc/Documents/github/lime-os/frontend/node_modules/typescript/lib/typescript.js";

const source = await readFile(new URL("StorageMounts-before.tsx", import.meta.url), "utf8");
const tree = ts.createSourceFile("StorageMounts.tsx", source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
function callback(name, scope) {
  let expression;
  function visit(node) {
    if (ts.isFunctionDeclaration(node) && node.name?.text === name) expression = node;
    if (ts.isVariableDeclaration(node) && node.name.getText(tree) === name && ts.isCallExpression(node.initializer)) expression = node.initializer.arguments[0];
    ts.forEachChild(node, visit);
  }
  visit(tree); assert.ok(expression);
  const code = ts.transpileModule(`const value = ${expression.getText(tree)};`, { fileName: "callback.ts", compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
  return Function(...Object.keys(scope), `${code}\nreturn value;`)(...Object.values(scope));
}
function deferred() { let resolve; const promise = new Promise(yes => { resolve = yes; }); return { promise, resolve }; }
test("abandoned confirmation cannot queue after approval completes", async () => {
  const wait = deferred(), alive = { current: true }; let queues = 0;
  const confirm = callback("confirm", { proposal: { plan: { id: "old-plan" } }, pending: false, setPending() {}, setError() {}, submission: { current: null },
    mountApi: { approve: () => wait.promise, queue: async () => { queues++; } }, csrf: "old-csrf", crypto: { randomUUID: () => "old-key" }, alive, dialog: { current: { close() {} } }, refresh: async () => {}, message: () => "failure" });
  const pending = confirm(); alive.current = false; wait.resolve({ token: "old-approval" }); await pending; assert.equal(queues, 0);
});
test("overlapping job reads cannot overwrite the newer result", async () => {
  const first = deferred(), second = deferred(); let calls = 0, jobs = [];
  const refresh = callback("refresh", { mountApi: { jobs: () => ++calls === 1 ? first.promise : second.promise }, alive: { current: true }, setJobs(value) { jobs = value; }, setHistoryError() {}, expired() {}, ApiError: class extends Error {}, message: () => "failure" });
  const old = refresh(), current = refresh(); second.resolve([{ id: "new-job" }]); await current; first.resolve([]); await old;
  assert.deepEqual(jobs, [{ id: "new-job" }]);
});
