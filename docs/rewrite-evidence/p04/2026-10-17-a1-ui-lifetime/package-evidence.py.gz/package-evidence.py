# /// script
# dependencies = []
# ///
"""Bind the A1 frontend repair, failures and production bundle to their source."""

import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/a1-ui"
packet = root / "docs/rewrite-evidence/p04/2026-10-17-a1-ui-lifetime"


def command(*args):
    return subprocess.check_output(args, cwd=root, text=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source = command("git", "rev-parse", "HEAD").strip()
base = command("git", "rev-parse", "7df3f75").strip()
subprocess.run(
    ["git", "diff", "--exit-code", "HEAD", "--", "frontend", "crates", "bins", "tests"],
    cwd=root,
    check=True,
)
unchanged = [
    "crates",
    "bins",
    "contracts",
    "tests/frontend",
    "tests/privileged_vm",
    "tests/reference",
    "tests/fixtures",
    "Cargo.toml",
    "Cargo.lock",
    "packaging",
]
subprocess.run(
    ["git", "diff", "--exit-code", base, "HEAD", "--", *unchanged], cwd=root, check=True
)
protected = [
    "frontend/src/Dashboard.tsx",
    "frontend/src/api.ts",
    "frontend/src/style.css",
    "frontend/package.json",
    "frontend/package-lock.json",
    "frontend/tsconfig.json",
]
for path in protected:
    assert (
        command("git", "show", f"{base}:{path}").encode() == (root / path).read_bytes()
    ), path
assert (
    command("git", "show", f"{base}:frontend/src/storage/StorageMounts.tsx").encode()
    == (cache / "StorageMounts-before.tsx").read_bytes()
)
paths = command(
    "git",
    "ls-files",
    "-z",
    "frontend/src",
    "frontend/tests",
    "frontend/package.json",
    "frontend/package-lock.json",
    "frontend/tsconfig.json",
    "frontend/index.html",
    "contracts/generated",
    "tests/fixtures",
    "crates/persistence/src/storage_mounts.rs",
    "crates/domain/src/storage_operations.rs",
).split("\0")
paths = sorted(path for path in paths if path and (root / path).is_file())
packet.mkdir(parents=True, exist_ok=True)
(packet / "inputs.sha256").write_text(
    "".join(f"{digest(root / path)}  {path}\n" for path in paths)
)
results = json.loads((cache / "frontend-results.json").read_text())
assert results["tests"] == 129 and len(results["files"]) == 8
assert (
    next(
        row["tests"]
        for row in results["files"]
        if row["file"].endswith("storage-mount-lifecycle.test.mjs")
    )
    == 40
)
assert "# fail 2" in (cache / "pre-fix-regressions.log").read_text()
assert "# fail 2" in (cache / "reentrant-regressions-before.log").read_text()
assert "built in" in (cache / "production-build.log").read_text()
assert "All checks passed" in (cache / "scripts-lint.log").read_text()
assert not (root / "frontend/node_modules").exists()
installed = {}
expected = json.loads((root / "frontend/package.json").read_text())
for name, version in {
    **expected["dependencies"],
    **expected["devDependencies"],
}.items():
    path = root.parents[1] / "frontend/node_modules" / name / "package.json"
    actual = json.loads(path.read_text())["version"]
    assert actual == version, (name, actual, version)
    installed[name] = {"version": actual, "package_json_sha256": digest(path)}
for path in sorted((root / "frontend/dist").rglob("*")):
    if path.is_file():
        dest = packet / "production-ui" / path.relative_to(root / "frontend/dist")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
(cache / "source-status.log").write_text(
    command("git", "status", "--short", "--branch")
)
(cache / "source-history.log").write_text(command("git", "log", "-3", "--format=%H %s"))
metadata = {
    "source": source,
    "base": base,
    "source_committed_after_checks_without_intervening_product_changes": True,
    "frontend": results,
    "new_mount_cases": 40,
    "input_count": len(paths),
    "input_scope": "Frontend source/contracts/fixture superset plus unchanged Rust intent/replay references; no Rust test credit",
    "unchanged_groups_from_base": unchanged,
    "protected_frontend_unchanged": protected,
    "baseline_callback_source_sha256": digest(cache / "StorageMounts-before.tsx"),
    "regressions": {
        "baseline_callbacks": "Two expected failures executing actual extracted original callbacks; no browser/host/API effect",
        "intermediate_reentrant": "Two expected failures before final lifetime checks and local promise preservation",
        "final": "40 mount tests passed inside 129 frontend total",
    },
    "installed_frontend_dependencies": installed,
    "bounds": {
        "request_json_bytes": 32768,
        "catalog_plan_job_bytes": 32768,
        "approval_error_bytes": 4096,
        "history_bytes": 1048576,
        "catalog_history_rows": 32,
        "per_request_deadline_ms": 12000,
    },
    "commands": [
        "node .cache/a1-ui/pre-fix-regressions.mjs (expected red baseline)",
        "uv run --offline --no-project .cache/a1-ui/check-frontend.py",
        "npm run build (frontend; includes pinned type check)",
        "uv run --offline --no-project --with ruff==0.17.0 ruff check .cache/a1-ui/check-frontend.py .cache/a1-ui/package-evidence.py",
        "git diff --check",
    ],
    "toolchain": {
        "node": command("node", "--version"),
        "npm": command("npm", "--version"),
        "uv": command("uv", "--version"),
    },
    "environment": {
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
        "npm_config_cache": "/home/marc/Documents/github/lime-os/.cache/npm",
        "frontend_suites": "sequential, one file at a time",
    },
    "browser": json.loads((cache / "browser-availability.json").read_text()),
    "bundle_scope": "Actual production Dashboard build with existing registered StorageMounts import/props; not browser execution or performance qualification",
    "remaining": "Integrator accepts the repair onto the actual A1 candidate. Qualification owner retains browser fixture 8c5b498 and installed mount/admission/receipt/crash/replay/recovery. No shared Store/protocol/executor/package/guest files changed. No browser, Cargo, hardware/Pi, installed, performance/soak, defect/A1/Stream-A/P04 completion or cutover acceptance is claimed.",
}
(packet / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
for name in ["frontend-results.json", "browser-availability.json"]:
    shutil.copyfile(cache / name, packet / name)
for path in sorted(cache.iterdir()):
    if path.suffix in {".log", ".py", ".mjs", ".tsx", ".ts"}:
        (packet / (path.name + ".gz")).write_bytes(
            gzip.compress(path.read_bytes(), mtime=0)
        )
artifacts = sorted(
    path
    for path in packet.rglob("*")
    if path.is_file() and path.name != "artifacts.sha256"
)
(packet / "artifacts.sha256").write_text(
    "".join(f"{digest(path)}  {path.relative_to(packet)}\n" for path in artifacts)
)
print(
    json.dumps(
        {
            "source": source,
            "inputs": len(paths),
            "artifacts": len(artifacts),
            "tests": results["tests"],
        }
    )
)
