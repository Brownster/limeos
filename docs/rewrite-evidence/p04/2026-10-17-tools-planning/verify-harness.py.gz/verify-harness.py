# /// script
# dependencies = []
# ///
"""Check that regeneration preserves the tested harness and shared roots."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
generated = root / ".cache/stream-b-leaf"
paths = sorted(path for path in generated.rglob("*") if path.is_file())
paths += [
    root / path
    for path in (
        "Cargo.toml",
        "Cargo.lock",
        "crates/domain/src/lib.rs",
        "crates/api/src/lib.rs",
        "crates/persistence/src/lib.rs",
        "crates/contracts/src/lib.rs",
        "crates/executor-container/src/lib.rs",
        "crates/executor-protocol/src/lib.rs",
        "bins/core/src/main.rs",
        "bins/executor/src/main.rs",
        "frontend/src/Dashboard.tsx",
        "frontend/src/api.ts",
        "frontend/package.json",
        "frontend/package-lock.json",
    )
]


def hashes():
    return {
        str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in paths
    }


before = hashes()
subprocess.run([sys.executable, "tests/fixtures/stream-b/check-leaves.py"], check=True)
after = hashes()
(root / ".cache/tools-planning/harness-regeneration.json").write_text(
    json.dumps(
        {"before": before, "after": after, "identical": before == after}, indent=2
    )
    + "\n"
)
assert before == after, "Regeneration changed harness or shared sources"
print(f"Regeneration preserves all {len(paths)} checked files")
