# /// script
# dependencies = []
# ///
"""Archive local tools checks, source hashes and the generated leaf harness."""

import gzip
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/tools-planning"
packet = root / "docs/rewrite-evidence/p04/2026-10-17-tools-planning"
frozen = Path("/home/marc/Documents/github/pi-health")


def command(*args, cwd=root):
    return subprocess.check_output(args, cwd=cwd, text=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source = command("git", "rev-parse", "HEAD").strip()
base = command("git", "rev-parse", "53ec484").strip()
subprocess.run(
    ["git", "diff", "--exit-code", "HEAD", "--", "crates", "bins", "tests/fixtures"],
    cwd=root,
    check=True,
)
protected = [
    "Cargo.toml",
    "Cargo.lock",
    "crates/domain/src/lib.rs",
    "crates/api/src/lib.rs",
    "crates/persistence/src/lib.rs",
    "crates/executor-protocol/src/lib.rs",
    "crates/contracts/src/lib.rs",
    "bins/core/src/main.rs",
    "bins/executor/src/main.rs",
    "frontend/src/Dashboard.tsx",
    "frontend/src/api.ts",
    "frontend/package.json",
    "frontend/package-lock.json",
    "tests/fixtures/stream-b/check-leaves.py",
]
for path in protected:
    assert (
        command("git", "show", f"{base}:{path}").encode() == (root / path).read_bytes()
    ), path
old_lock = (
    root / "docs/rewrite-evidence/p04/2026-10-16-network-egress/harness/Cargo.lock"
)
assert old_lock.read_bytes() == (root / ".cache/stream-b-leaf/Cargo.lock").read_bytes()
paths = command(
    "git",
    "ls-files",
    "-z",
    "crates",
    "bins/core/src/automation",
    "bins/executor/src/updates",
    "tests/fixtures",
    "Cargo.toml",
    "Cargo.lock",
    "rust-toolchain.toml",
    ".cargo",
).split("\0")
paths = sorted(path for path in paths if path and (root / path).is_file())
packet.mkdir(parents=True, exist_ok=True)
(packet / "inputs.sha256").write_text(
    "".join(f"{digest(root / path)}  {path}\n" for path in paths)
)
frozen_paths = [
    "tools_service.py",
    "tools_manager.py",
    "pihealth_helper.py",
    "tests/test_tools_service.py",
    "tests/test_tools.py",
]
assert (
    command("git", "rev-parse", "HEAD", cwd=frozen).strip()
    == "80593b29443ea9b81eb60ed4e5c3c3ac7a236204"
)
(packet / "frozen-inputs.sha256").write_text(
    "".join(f"{digest(frozen / path)}  {path}\n" for path in frozen_paths)
)
for path in sorted((root / ".cache/stream-b-leaf").rglob("*")):
    if path.is_file():
        dest = packet / "harness" / path.relative_to(root / ".cache/stream-b-leaf")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
(cache / "source-status.log").write_text(
    command("git", "status", "--short", "--branch")
)
(cache / "source-history.log").write_text(command("git", "log", "-3", "--format=%H %s"))
(cache / "frozen-status.log").write_text(
    command("git", "status", "--short", cwd=frozen)
)
(cache / "cargo-metadata.json").write_text(
    command(
        "cargo",
        "metadata",
        "--offline",
        "--locked",
        "--format-version",
        "1",
        "--manifest-path",
        ".cache/stream-b-leaf/Cargo.toml",
    )
)
tests = (cache / "rust-tests.log").read_text()
counts = list(map(int, re.findall(r"test result: ok\. (\d+) passed; 0 failed", tests)))
assert counts[:4] == [137, 35, 321, 6] and not any(counts[4:]), counts
assert "test result: FAILED" not in tests and "error:" not in tests
assert "warning:" not in tests
assert "Finished" in (cache / "clippy.log").read_text()
assert "warning:" not in (cache / "clippy.log").read_text()
metadata = {
    "source": source,
    "base": base,
    "main_baseline": "7df3f7530865c31b7faefd1f7b12a25aa7655860",
    "source_committed_after_checks_without_intervening_product_changes": True,
    "rust_suite_counts_in_log_order": counts,
    "rust_total": sum(counts),
    "baseline_rust_total": 461,
    "new_rust_tests": sum(counts) - 461,
    "config_fixture_cases": len(
        json.loads((root / "tests/fixtures/deployment/tools/config.json").read_text())
    ),
    "service_fixture_cases": len(
        json.loads((root / "tests/fixtures/deployment/tools/services.json").read_text())
    ),
    "input_count": len(paths),
    "input_scope": "Source/fixture superset; dependency crate unit suites were not all run",
    "frozen_source": "80593b29443ea9b81eb60ed4e5c3c3ac7a236204",
    "frozen_input_count": len(frozen_paths),
    "harness_lock_origin": str(old_lock.relative_to(root)),
    "harness_lock_sha256": digest(old_lock),
    "protected_paths_unchanged_from_base": protected,
    "bounds": {
        "config_bytes": 16384,
        "service_property_bytes": 512,
        "path_bytes": 512,
        "report_bytes": 8192,
        "inclusive_original_sample_age_seconds": 90,
    },
    "commands": [
        "uv run --offline --no-project tests/fixtures/stream-b/check-leaves.py",
        "cp docs/rewrite-evidence/p04/2026-10-16-network-egress/harness/Cargo.lock .cache/stream-b-leaf/Cargo.lock",
        "cargo test --offline --locked --manifest-path .cache/stream-b-leaf/Cargo.toml",
        "cargo clippy --offline --locked --manifest-path .cache/stream-b-leaf/Cargo.toml --all-targets -- -D warnings",
        "rustfmt --edition 2024 --check --config skip_children=true <eight changed Rust files>",
        "git diff --check",
        "uv run --offline --no-project .cache/tools-planning/verify-harness.py",
    ],
    "toolchain": {
        "rustc": command("rustc", "-Vv"),
        "cargo": command("cargo", "-Vv"),
        "uv": command("uv", "--version"),
    },
    "environment": {
        "CARGO_BUILD_JOBS": "1",
        "CARGO_INCREMENTAL": "0",
        "RUST_TEST_THREADS": "2",
        "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "CCACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/ccache",
    },
    "limits": "Local pure planners, supplied-byte decoders and proposed cached API checks only. Production Core/cache/worker/Store/route/contracts/UI/package registration, trusted installation, effects/recovery, actual systemd captures, installed/ARM64/performance/soak/Pi and defect/P04/cutover acceptance remain open. No frontend changes or frontend test credit in this slice.",
}
(packet / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
for path in sorted(cache.iterdir()):
    if path.suffix in {".log", ".py", ".json", ".rs"}:
        (packet / (path.name + ".gz")).write_bytes(
            gzip.compress(path.read_bytes(), mtime=0)
        )
artifacts = sorted(
    path
    for path in packet.rglob("*")
    if path.is_file() and path.name != "artifacts.sha256"
)
(packet / "artifacts.sha256").write_text(
    "".join(f"{digest(path)}  {path.relative_to(packet)}\n" for path in artifacts)
)
print(
    json.dumps(
        {
            "source": source,
            "inputs": len(paths),
            "artifacts": len(artifacts),
            "tests": sum(counts),
        }
    )
)
