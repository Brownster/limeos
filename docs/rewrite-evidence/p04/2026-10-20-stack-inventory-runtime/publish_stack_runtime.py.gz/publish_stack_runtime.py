#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Preserve terminal stack-runtime checks without expanding qualification scope."""

import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/main-consolidation'
PACKET = ROOT / 'docs/rewrite-evidence/p04/2026-10-20-stack-inventory-runtime'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert head.startswith('e5e45ca')
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    PACKET.mkdir(exist_ok=False)
    logs = PACKET / 'checks'
    logs.mkdir()
    attempts = []
    for directory in sorted((STATE / 'attempts').glob('stack-runtime-*')):
        record = json.loads((directory / 'record.json').read_text())
        assert 'ended' in record and 'exit_code' in record, directory.name
        for name in ('record.json', 'output.log'):
            source = directory / name
            (logs / f'{directory.name}-{name}.gz').write_bytes(gzip.compress(source.read_bytes(), mtime=0))
        attempts.append({
            'name': directory.name,
            **{key: record[key] for key in ('command', 'exit_code', 'guard_triggered', 'minimum_available_bytes', 'inputs_unchanged', 'started', 'ended')},
        })
    for number in (3, 4, 5):
        source = STATE / f'stack-runtime-browser-{number}'
        target = PACKET / f'browser-{number}'
        target.mkdir()
        for path in source.iterdir():
            if path.suffix == '.png':
                shutil.copyfile(path, target / path.name)
            else:
                (target / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    prefixes = ('crates/', 'bins/', 'contracts/generated/', 'frontend/src/', 'frontend/tests/', 'tests/', 'packaging/', '.github/workflows/')
    selected = sorted(name for name in names if name and (name.startswith(prefixes) or name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'frontend/package.json', 'frontend/package-lock.json')))
    (PACKET / 'inputs.sha256').write_text(''.join(f'{digest(ROOT / name)}  {name}\n' for name in selected))
    ui = {str(path.relative_to(ROOT)): digest(path) for path in sorted((ROOT / 'frontend/dist').rglob('*')) if path.is_file()}
    manifest = {
        'source': head,
        'base': '319028677c92d7ec1db2bb5f3959d574983717bd',
        'input_files': len(selected),
        'attempts': attempts,
        'production_ui': ui,
        'focused_rust_counts': {'domain': 547, 'container': 349, 'protocol': 6, 'observations': 39, 'api': 19, 'executor': 48, 'core_stack_tests': 4},
        'focused_rust_total': 1012,
        'frontend_cases': 222,
        'reference_cases': 61,
        'supplemental_leaf_cases_overlapping_root': 68,
        'installed_acceptance': False,
        'arm64_execution': False,
        'whole_service_measurement': False,
        'cutover_acceptance': False,
        'guard_source_sha256': digest(STATE / 'guard.py'),
    }
    (PACKET / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (PACKET / 'guard.py.gz').write_bytes(gzip.compress((STATE / 'guard.py').read_bytes(), mtime=0))
    print(json.dumps({'source': head, 'terminal_attempts': len(attempts), 'inputs': len(selected)}))


if __name__ == '__main__':
    main()
