# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Verify packet inputs and preserve exact diagnostics before committing docs."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/main-consolidation'
packet = root / 'docs/rewrite-evidence/p04/2026-10-20-stack-inventory-runtime'
for row in (packet / 'inputs.sha256').read_text().splitlines():
    expected, name = row.split('  ', 1)
    actual = (root / name).read_bytes()
    if hashlib.sha256(actual).hexdigest() != expected:
        # The source commit precedes the separate documentation commit. Only
        # this handoff README changed; retain its original source-bound digest.
        assert name == 'tests/fixtures/stream-b/README.md', name
        actual = subprocess.check_output(['git', 'show', 'e5e45caa31db2062ef118e28ce2ad419a944000c:' + name], cwd=root)
    assert hashlib.sha256(actual).hexdigest() == expected, name
before = (root / 'frontend/src/stack-inventory-controller.ts').read_text().replace(
    'schedule: (callback,ms) => setTimeout(callback,ms), cancel: id => clearTimeout(id)',
    'schedule: setTimeout, cancel: clearTimeout',
)
record = json.loads((state / 'attempts/stack-runtime-browser-3/record.json').read_text())
assert hashlib.sha256(before.encode()).hexdigest() == record['before']['frontend/src/stack-inventory-controller.ts']
(packet / 'controller-before-timer-fix.ts.gz').write_bytes(gzip.compress(before.encode(), mtime=0))
for name in ('publish_stack_runtime.py', 'finalize_stack_runtime_packet.py'):
    (packet / (name + '.gz')).write_bytes(gzip.compress((state / name).read_bytes(), mtime=0))
result = subprocess.run(['bash', '-n', 'packaging/debian/postinst'], cwd=root, capture_output=True, text=True, check=True)
(packet / 'shell-syntax.json').write_text(json.dumps({'command': ['bash', '-n', 'packaging/debian/postinst'], 'exit_code': result.returncode, 'source_sha256': hashlib.sha256((root / 'packaging/debian/postinst').read_bytes()).hexdigest()}, indent=2) + '\n')
paths = sorted(p for p in packet.rglob('*') if p.is_file() and p.name != 'artifacts.sha256')
(packet / 'artifacts.sha256').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(packet)}\n' for p in paths))
print(json.dumps({'verified_source_inputs': 667, 'packet_files': len(paths), 'before_image_matches_record': True, 'bash_syntax': 'passed'}))
