# /// script
# dependencies = []
# ///
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-reader-fix-qualification'
out = root / 'docs/rewrite-evidence/p04/2026-11-05-b1-core-reader-profile'
assert not (out / 'SHA256SUMS').exists()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
native = json.loads((root / '.cache/main-consolidation/attempts/b1-core-reader-fix-reference-1/record.json').read_text())
current = {name:sha(root/name) for name in native['before']}
assert current == native['before'] == native['after']
result = json.loads((out/'installed-result.json').read_text())
packages = json.loads((root/'.cache/stack-installed-qualification/candidate-13/inputs.json').read_text())
manifest = json.loads((state/'inputs-1.json').read_text())
correction = json.loads((out/'provenance-correction.json').read_text())
assert correction['current_package_input_count'] == correction['current_fixture_input_count'] == len(current) == 747
assert correction['package_source'] == correction['fixture_source'] == packages['source']
assert correction['binary_and_ui_source'] == packages['binary_source'] == packages['ui_source']
assert result['summary'] == 'pass' and result['stage'] == 'complete'
assert result['package_version'] == '0.4.13+coreopen.1' and result['authority_schema'] == 14
assert result['before_restart'] == result['after_restart']
assert {key:len(value) for key,value in result['before_restart'].items()} == {'schedules':1,'occurrences':1,'jobs':1,'results':1,'alerts':1,'notifications':1}
history=result['final_history']
assert {key:len(value) for key,value in history.items()} == {'schedules':1,'occurrences':2,'jobs':2,'results':2,'alerts':1,'notifications':2}
occurrences=history['occurrences']
schedule=result['created_schedule']['schedule']
assert [row[:3] for row in occurrences] == [[schedule['id'],1,schedule['definition']['anchor']],[schedule['id'],1,schedule['definition']['anchor']+30]]
jobs={row[0]:row for row in history['jobs']}
assert len(jobs)==2 and all(row[1]=='succeeded' for row in jobs.values())
assert {row[3] for row in occurrences} == set(jobs) == {row[0] for row in history['results']}
assert all(row[1:3]==['succeeded','observed'] and row[4]==0 for row in history['results'])
opening,recovery=result['opening'],result['recovery']
assert opening['id']!=recovery['id']
assert opening['event']['event']=='incident' and recovery['event']['event']=='recovery'
assert opening['event']['generation']==recovery['event']['generation']==1
assert opening['event']['key']==recovery['event']['key']=='container:'+result['container_id']
assert all(row['delivery']['state']=='delivered' and row['attempts']==1 and row['channel']=='in_app' for row in (opening,recovery))
assert result['acknowledged']['id']==opening['id'] and result['acknowledged']['acknowledged_at'] is not None
assert result['paused']['schedule']['revision']==2 and result['paused']['status']=='paused'
assert result['recovered_alerts']['partial'] is True and result['recovered_alerts']['items'][0]['incident']['phase']=='clear'
pids=[result['restarts'][0]['before_pid'],int(result['restarts'][0]['after']['MainPID']),int(result['restarts'][1]['after']['MainPID'])]
assert pids==[984,6268,6463] and result['restarts'][1]['before_pid']==6268
for name,facts in packages['core_unit_payloads'].items():
    text=facts['text']
    assert hashlib.sha256(text.encode()).hexdigest()==facts['sha256']
    assert 'RestrictSUIDSGID=no\n' in text and 'SystemCallFilter=@system-service openat2\n' in text
    assert 'CapabilityBoundingSet=\n' in text and 'NoNewPrivileges=yes\n' in text
log=(root/'.cache/main-consolidation/attempts/b1-core-reader-fix-vm-1/output.log').read_text()
assert 'B1_FAILURE ' not in log and 'B1_OBSERVATION ' not in log and 'CORE_PROFILE ' not in log
checks=[]
for command in ([sys.executable,'scripts/check_repository.py'],['git','diff','--check']):
    value=subprocess.run(command,cwd=root,text=True,capture_output=True)
    checks.append({'command':command,'exit_code':value.returncode,'stdout':value.stdout,'stderr':value.stderr})
    assert value.returncode==0
links=[]
for document in (out/'README.md',root/'docs/p04-b1-observation-supervisor-handoff.md',root/'docs/rewrite-evidence/p04/2026-10-05-execution-tracker.md'):
    for target in re.findall(r'\]\(([^)]+)\)',document.read_text()):
        if '://' in target or target.startswith('#'): continue
        assert (document.parent/target.partition('#')[0]).exists(),(document,target)
        links.append({'document':str(document.relative_to(root)),'target':target})
for path in out.rglob('*.gz'): gzip.decompress(path.read_bytes())
with tarfile.open(out/'reproduction-sources.tar.gz','r:gz') as archive:
    names=archive.getnames()
    assert len([name for name in names if name.startswith('guest/')])==33
    assert all(not name.startswith('/') and '..' not in Path(name).parts for name in names)
    for name,expected in manifest['guest'].items(): assert hashlib.sha256(archive.extractfile('guest/'+name).read()).hexdigest()==expected
verification={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_package_fixture_inputs_match':len(current),
    'commands':checks,'relative_links_checked':len(links),'links':links,'gzip_files_readable':True,
    'reproduction_members':len(names),'ordinary_runtime_restart_and_provenance_joins_verified':True,'sealer_sha256':sha(Path(__file__))}
(out/'final-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(out/'seal-source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
files=sorted(path for path in out.rglob('*') if path.is_file())
(out/'SHA256SUMS').write_text(''.join(sha(path)+'  '+str(path.relative_to(out))+'\n' for path in files))
for line in (out/'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    assert sha(out/name)==expected
print(json.dumps({'verified_files':len(files),'inputs':len(current),'relative_links':len(links),'ordinary_b1_flow_verified':True}))
