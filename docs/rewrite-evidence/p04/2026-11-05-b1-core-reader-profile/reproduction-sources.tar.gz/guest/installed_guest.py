import p04_automation_guest as guest
guest.main(package_version='0.4.13+coreopen.1')
