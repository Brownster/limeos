# /// script
# dependencies = []
# ///
from pathlib import Path
import subprocess
import sys
root = Path('/home/marc/Documents/github/lime-os')
old = root / '.cache/b1-core-profile-qualification'
state = root / '.cache/b1-core-reader-fix-qualification'
value = (old / 'freeze_vm.py').read_text().replace('b1-core-profile', 'b1-core-reader-fix').replace('candidate-12', 'candidate-13')
value = value.replace("build['source'] == packages['source']", "build['source'] == packages['binary_source']")
needle = "'tests/fixtures/automation/core-profile-baseline.service'}"
assert value.count(needle) == 1
value = value.replace(needle, "'tests/fixtures/automation/core-profile-baseline.service', 'tests/reference/test_core_reader_profile.py'}")
needle = "for name, expected in build['before'].items():\n    assert sha(root / name) == expected == native['before'][name], name"
assert value.count(needle) == 1
value = value.replace(needle, "for name, expected in build['before'].items():\n    change = packages['production_changes_since_binary_build'].get(name)\n    if change: assert change['before'] == expected\n    assert sha(root / name) == native['before'][name] == (change['after'] if change else expected), name")
needle = "manifest = {'fixture_source': head, 'product_source': packages['source'],"
assert value.count(needle) == 1
value = value.replace(needle, "manifest = {'fixture_source': head, 'product_source': packages['source'], 'binary_source': packages['binary_source'], 'production_changes_since_binary_build': packages['production_changes_since_binary_build'],")
value = value.replace("'production_inputs_unchanged': True", "'application_inputs_unchanged': True")
needle = "shutil.copyfile(root / 'tests/privileged_vm/run.py', state / 'run_1024.py')"
assert value.count(needle) == 1
value = value.replace(needle, "(guest / 'installed_guest.py').write_text('import p04_automation_guest as guest\\nguest.main(package_version=' + repr(packages['version']) + ')\\n')\n" + needle)
value = value.replace('Disposable AMD64 fixed Core lookup profile matrix; no ordinary timer, UI, ARM64/Pi or upgrade/return/soak acceptance', 'Ordinary installed AMD64 B1 container observation API/runtime with fixed packaged Core profile; no browser, ARM64/Pi, upgrade/return/soak acceptance')
with (state / 'freeze_vm.py').open('x') as stream: stream.write(value)
value = (old / 'launch_vm.py').read_text().replace('b1-core-profile', 'b1-core-reader-fix').replace('candidate-12', 'candidate-13').replace('guest-1/p04_core_profile_guest.py', 'guest-1/installed_guest.py')
needle = "for name, expected in build['before'].items(): assert sha(root / name) == expected"
assert value.count(needle) == 1
value = value.replace(needle, "for name, expected in build['before'].items():\n    change = packages['production_changes_since_binary_build'].get(name)\n    if change: assert change['before'] == expected\n    assert sha(root / name) == (change['after'] if change else expected)")
with (state / 'launch_vm.py').open('x') as stream: stream.write(value)
value = (old / 'observe_vm.py').read_text().replace('b1-core-profile','b1-core-reader-fix')
with (state / 'observe_vm.py').open('x') as stream: stream.write(value)
subprocess.run([sys.executable, str(state / 'freeze_vm.py')], check=True, cwd=root)
