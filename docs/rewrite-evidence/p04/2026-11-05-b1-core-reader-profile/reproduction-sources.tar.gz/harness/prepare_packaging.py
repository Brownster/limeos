# /// script
# dependencies = []
# ///
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/stack-installed-qualification'
value = (state / 'prepare_packages_12.py').read_text()
value = value.replace("OUT = STATE / 'candidate-12'", "OUT = STATE / 'candidate-13'").replace("KEYS = STATE / 'signing-12'", "KEYS = STATE / 'signing-13'")
value = value.replace("VERSION = '0.4.12+gateabort.1'", "VERSION = '0.4.13+coreopen.1'")
value = value.replace('LimeOS disposable gated refusal fixture 2026-11-04', 'LimeOS disposable Core lookup fixture 2026-11-05')
needle = "assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == record['source']"
assert value.count(needle) == 1
value = value.replace(needle, "package_source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()")
needle = "for name, expected in record['before'].items():\n    assert digest(ROOT / name) == expected, name"
assert value.count(needle) == 1
replacement = '''native_path = ROOT / '.cache/main-consolidation/attempts/b1-core-reader-fix-reference-1/record.json'
native = json.loads(native_path.read_text())
assert native['exit_code'] == 0 and native['inputs_unchanged'] and not native['guard_triggered']
current_inputs = {name: digest(ROOT / name) for name in native['before']}
assert current_inputs == native['before'] == native['after']
production_changes = {name: {'before': expected, 'after': digest(ROOT / name)} for name, expected in record['before'].items() if digest(ROOT / name) != expected}
assert set(production_changes) == {'packaging/systemd/limeos-core.service'}
extras = set(current_inputs) - set(record['before'])
assert len(extras) == 7 and all(name.startswith('tests/') for name in extras)
for name, expected in current_inputs.items():
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{package_source}:{name}'], cwd=ROOT)).hexdigest() == expected
'''
value = value.replace(needle, replacement)
needle = "for name, expected in ui_record['before'].items():\n    assert digest(ROOT / name) == expected, name"
assert value.count(needle) == 1
value = value.replace(needle, "for name, expected in ui_record['before'].items():\n    if name not in production_changes: assert digest(ROOT / name) == expected, name")
needle = "inputs = {'source': record['source'], 'version': VERSION"
assert value.count(needle) == 1
value = value.replace(needle, "inputs = {'source': package_source, 'binary_source': record['source'], 'ui_source': record['source'], 'production_changes_since_binary_build': production_changes, 'package_inputs': current_inputs, 'native_record_sha256': digest(native_path), 'version': VERSION")
needle = "(OUT / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\\n')"
assert value.count(needle) == 1
payload = '''import tarfile
unit_facts = {}
for file in files:
    profile = 'limeos-shadow' if file.name.startswith('limeos-shadow_') else 'limeos'
    expected_unit = ROOT / 'packaging/systemd/limeos-core.service'
    tar_bytes = subprocess.check_output(['dpkg-deb', '--fsys-tarfile', str(file)])
    import io
    with tarfile.open(fileobj=io.BytesIO(tar_bytes)) as archive:
        members = archive.getmembers()
        assert all(member.uid == member.gid == 0 for member in members)
        member = next(member for member in members if member.name.removeprefix('./') == 'lib/systemd/system/' + profile + '-core.service')
        text = archive.extractfile(member).read().decode()
        assert 'RestrictSUIDSGID=no\\n' in text and 'SystemCallFilter=@system-service openat2\\n' in text
        for line in ('NoNewPrivileges=yes','CapabilityBoundingSet=','AmbientCapabilities=','MemoryMax=128M','TasksMax=32','LimitNOFILE=1024'):
            assert line + '\\n' in text
        if profile == 'limeos': assert text == expected_unit.read_text()
        assert 'User=' + profile + '-core\\n' in text and 'ReadWritePaths=/var/lib/' + profile + '/core\\n' in text
        unit_facts[profile] = {'sha256': hashlib.sha256(text.encode()).hexdigest(), 'text': text, 'root_archive_ownership_verified': True}
        for name, facts in binaries.items():
            member = next(member for member in members if member.name.removeprefix('./') == 'usr/lib/' + profile + '/' + name)
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == facts['sha256']
inputs['core_unit_payloads'] = unit_facts
assert current_inputs == {name: digest(ROOT / name) for name in current_inputs}
'''
value = value.replace(needle, payload + needle)
with (state / 'prepare_packages_13.py').open('x') as stream: stream.write(value)
old = root / '.cache/b1-core-reader-fix-qualification/launch_reference.py'
launcher = old.read_text().replace('reference-1','package-1').replace('reference-admission.json','package-admission.json').replace('reference-console.log','package-console.log').replace('reference-launch.json','package-launch.json').replace("str(state / 'check_reference.py')", "str(root / '.cache/stack-installed-qualification/prepare_packages_13.py')")
with (old.parent / 'launch_package.py').open('x') as stream: stream.write(launcher)
