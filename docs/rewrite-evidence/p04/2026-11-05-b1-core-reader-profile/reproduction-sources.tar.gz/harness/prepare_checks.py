# /// script
# dependencies = []
# ///
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
old = root / '.cache/b1-core-profile-qualification'
state = root / '.cache/b1-core-reader-fix-qualification'
value = (old / 'check_reference.py').read_text().replace('b1-core-profile', 'b1-core-reader-fix')
needle = 'commands = [\n'
value = value.replace(needle, needle + "    [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_core_reader_profile.py', '-v'],\n    [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_stack_reader_profile.py', '-v'],\n")
needle = "'tests/reference/test_core_socket_profile.py']"
assert value.count(needle) == 2
value = value.replace(needle, "'tests/reference/test_core_socket_profile.py', 'tests/reference/test_core_reader_profile.py']")
with (state / 'check_reference.py').open('x') as stream: stream.write(value)
value = (old / 'launch_reference.py').read_text().replace('b1-core-profile', 'b1-core-reader-fix')
with (state / 'launch_reference.py').open('x') as stream: stream.write(value)
