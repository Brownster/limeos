# /// script
# dependencies = []
# ///
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-reader-fix-qualification'
builders = root / '.cache/stack-installed-qualification'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
build = json.loads((builders / 'build-12/record.json').read_text())
packages = json.loads((builders / 'candidate-13/inputs.json').read_text())
native = json.loads((root / '.cache/main-consolidation/attempts/b1-core-reader-fix-reference-1/record.json').read_text())
assert native['exit_code'] == 0 and native['inputs_unchanged'] and not native['guard_triggered']
assert build['source'] == packages['binary_source'] and build['exit_code'] == 0 and build['inputs_unchanged'] and build['container_removed']
assert native['before'] == native['after']
assert set(native['before']) - set(build['before']) == {'tests/privileged_vm/p04_automation_guest.py', 'tests/reference/test_p04_automation_guest.py', 'tests/privileged_vm/p04_core_lookup_probe.py', 'tests/privileged_vm/p04_core_profile_guest.py', 'tests/reference/test_core_socket_profile.py', 'tests/fixtures/automation/core-profile-baseline.service', 'tests/reference/test_core_reader_profile.py'}
for name, expected in build['before'].items():
    change = packages['production_changes_since_binary_build'].get(name)
    if change: assert change['before'] == expected
    assert sha(root / name) == native['before'][name] == (change['after'] if change else expected), name
for name, expected in native['before'].items():
    assert sha(root / name) == expected
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=root)).hexdigest() == expected
guest = state / 'guest-1'
guest.mkdir(exist_ok=False)
for path in sorted((root / 'tests/privileged_vm').glob('*.py')):
    shutil.copyfile(path, guest / path.name)
(guest / 'installed_guest.py').write_text('import p04_automation_guest as guest\nguest.main(package_version=' + repr(packages['version']) + ')\n')
shutil.copyfile(root / 'tests/privileged_vm/run.py', state / 'run_1024.py')
shutil.copyfile(root / 'tests/privileged_vm/current_authority_schema.py', state / 'current_authority_schema.py')
manifest = {'fixture_source': head, 'product_source': packages['source'], 'binary_source': packages['binary_source'], 'production_changes_since_binary_build': packages['production_changes_since_binary_build'], 'product_input_count': len(build['before']),
    'fixture_input_count': len(native['before']), 'application_inputs_unchanged': True,
    'test_only_changes_since_package_build': {name: {'before': None, 'after': native['before'][name]} for name in sorted(set(native['before']) - set(build['before']))},
    'package_inputs_sha256': sha(builders / 'candidate-13/inputs.json'), 'build_record_sha256': sha(builders / 'build-12/record.json'),
    'native_record_sha256': sha(root / '.cache/main-consolidation/attempts/b1-core-reader-fix-reference-1/record.json'),
    'schema_source_sha256': sha(root / 'crates/persistence/src/lib.rs'), 'binaries': packages['binaries'], 'packages': packages['packages'], 'ui': packages['ui'],
    'guest_memory_mib': 1024, 'runner_sha256': sha(state / 'run_1024.py'),
    'runner_support': {'current_authority_schema.py': sha(state / 'current_authority_schema.py')},
    'guest': {p.name: sha(p) for p in sorted(guest.glob('*.py'))},
    'scope': 'Ordinary installed AMD64 B1 container observation API/runtime with fixed packaged Core profile; no browser, ARM64/Pi, upgrade/return/soak acceptance'}
(state / 'inputs-1.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'fixture_source': head, 'product_source': packages['source'], 'product_inputs': len(build['before']), 'fixture_inputs': len(native['before']), 'guest_modules': len(manifest['guest'])}))
