# /// script
# dependencies = []
# ///
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-reader-fix-qualification'
builders = root / '.cache/stack-installed-qualification'
attempts = root / '.cache/main-consolidation/attempts'
out = root / 'docs/rewrite-evidence/p04/2026-11-05-b1-core-reader-profile'
def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
manifest = read(state / 'inputs-1.json')
packages = read(builders / 'candidate-13/inputs.json')
build = read(builders / 'build-12/record.json')
result = read(state / 'result-1.json')
cleanup = read(state / 'cleanup.json')
assert head == packages['source'] == manifest['fixture_source'] == manifest['product_source']
assert packages['binary_source'] == packages['ui_source'] == manifest['binary_source'] == build['source']
assert sha(builders / 'candidate-13/inputs.json') == manifest['package_inputs_sha256']
assert sha(builders / 'build-12/record.json') == manifest['build_record_sha256']
records = {}
for phase in ('reference','package','vm'):
    record = read(attempts / ('b1-core-reader-fix-' + phase + '-1/record.json'))
    assert record['exit_code'] == 0 and record['ended'] and record['inputs_unchanged'] and not record['guard_triggered']
    assert record['before'] == record['after'] == packages['package_inputs']
    records[phase] = record
for name, expected in packages['package_inputs'].items():
    assert sha(root / name) == expected
    assert hashlib.sha256(subprocess.check_output(['git','show',f'{head}:{name}'],cwd=root)).hexdigest() == expected
changes = packages['production_changes_since_binary_build']
assert set(changes) == {'packaging/systemd/limeos-core.service'}
for name, expected in build['before'].items():
    change = changes.get(name)
    assert packages['package_inputs'][name] == (change['after'] if change else expected)
    if change: assert change['before'] == expected
for name, expected in manifest['guest'].items(): assert sha(state / 'guest-1' / name) == expected
assert sha(state / 'run_1024.py') == manifest['runner_sha256'] == sha(root / 'tests/privileged_vm/run.py')
assert result['summary'] == 'pass' and result['stage'] == 'complete' and len(result['passed']) == 4
assert result['package_version'] == packages['version'] and result['authority_schema'] == 14
assert result['fixture_sha256'] == manifest['guest']['p04_automation_guest.py']
assert result['package_sha256'] == packages['packages']
for name, expected in result['binary_sha256'].items(): assert expected == packages['binaries'][name]['sha256']
assert result['before_restart'] == result['after_restart']
assert len(result['restarts']) == 2
assert result['opening']['event']['generation'] == result['recovery']['event']['generation'] == 1
assert result['opening']['delivery']['state'] == result['recovery']['delivery']['state'] == 'delivered'
assert {key:len(value) for key,value in result['final_history'].items()} == {'schedules':1,'occurrences':2,'jobs':2,'results':2,'alerts':1,'notifications':2}
assert result['paused']['status'] == 'paused' and result['acknowledged']['acknowledged_at'] is not None
assert cleanup['all_recorded_original_processes_absent'] and cleanup['unique_pids'] == 7 and all(value['absent'] for value in cleanup['vm_scratch'])
for name, expected in packages['repository'].items(): assert sha(builders / 'candidate-13/repository' / name) == expected
out.mkdir(exist_ok=False)
def archive(name,path):
    target = out / (name+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for phase in records:
    label = 'b1-core-reader-fix-'+phase+'-1'
    for name in ('record.json','output.log'): archive('checks/'+label+'-'+name,attempts / label / name)
for path in sorted(state.iterdir()):
    if path.is_file() and path.suffix in ('.json','.log','.txt'): archive('observations/'+path.name,path)
archive('package-inputs.json',builders / 'candidate-13/inputs.json')
archive('original-build-record.json',builders / 'build-12/record.json')
for name in ('dists/stable/InRelease','dists/stable/Release','dists/stable/Release.gpg','dists/stable/main/binary-amd64/Packages','limeos-archive-keyring.gpg'):
    archive('repository/'+name,builders / 'candidate-13/repository' / name)
sources = {'guest/'+p.name:p for p in sorted((state / 'guest-1').glob('*.py'))}
sources.update({'harness/'+p.name:p for p in sorted(state.glob('*.py'))})
sources['harness/prepare_packages_13.py'] = builders / 'prepare_packages_13.py'
sources['harness/guard.py'] = root / '.cache/main-consolidation/guard.py'
sources['harness/detached_guard.py'] = builders / 'detached_guard.py'
for name in ('build.py','repository.sh','systemd/limeos-core.service'): sources['packaging/'+name] = root / 'packaging' / name
sources['reference/test_core_reader_profile.py'] = root / 'tests/reference/test_core_reader_profile.py'
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
    for name,path in sorted(sources.items()):
        data=path.read_bytes(); item=tarfile.TarInfo(name)
        item.size,item.mode,item.mtime=len(data),0o644,0
        tar.addfile(item,io.BytesIO(data))
(out / 'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
(out / 'installed-result.json').write_text(json.dumps(result,indent=2)+'\n')
(out / 'provenance-correction.json').write_bytes((state / 'provenance-correction.json').read_bytes())
summary = {'package_source':head,'fixture_source':head,'binary_source':build['source'],'ui_source':packages['ui_source'],
    'package_and_fixture_input_count':len(packages['package_inputs']),'original_binary_input_count':len(build['before']),
    'application_inputs_unchanged':True,'production_changes_since_binary_build':changes,
    'test_only_additions_since_binary_build':manifest['test_only_changes_since_package_build'],
    'test_only_changes_between_current_package_and_fixture':{},'frozen_manifest_label_erratum_explicit':True,
    'native_reference_cases':34,'guest_modules':len(manifest['guest']),'canonical_runner_unchanged':True,
    'checks':{phase:{key:record[key] for key in ('started','ended','exit_code','minimum_available_bytes','guard_triggered','inputs_unchanged')} for phase,record in records.items()},
    'covered_ordinary_api_runtime_scenario_passed':True,'installed_browser_ui_qualified':False,'b1_complete':False,
    'arm64_pi_upgrade_return_soak_qualified':False,'recorded_original_native_pids_absent':7,'owned_vm_scratch_removed':True}
(out / 'source-match.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'source':head,'package_inputs':len(packages['package_inputs']),'ordinary_scenario_passed':True,'native_cases':34}))
