# /// script
# dependencies = []
# ///
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-reader-fix-qualification'
value = (root / '.cache/b1-observation-boundary-qualification/observe_cleanup.py').read_text().replace('b1-observation-boundary','b1-core-reader-fix')
value = value.replace("'reference-launch.json', 'guard-launch-1.json'", "'reference-launch.json', 'package-launch.json', 'guard-launch-1.json'")
value = value.replace("'b1-core-reader-fix-reference-1', 'b1-core-reader-fix-vm-1'", "'b1-core-reader-fix-reference-1', 'b1-core-reader-fix-package-1', 'b1-core-reader-fix-vm-1'")
with (state / 'observe_cleanup.py').open('x') as stream: stream.write(value)
