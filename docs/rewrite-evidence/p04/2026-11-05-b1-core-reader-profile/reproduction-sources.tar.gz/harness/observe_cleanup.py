# /// script
# dependencies = []
# ///
import datetime
import json
from pathlib import Path

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-core-reader-fix-qualification'
attempts = root / '.cache/main-consolidation/attempts'
record = json.loads((attempts / 'b1-core-reader-fix-vm-1/record.json').read_text())
assert record.get('ended') and record.get('exit_code') is not None
assert not (state / 'cleanup.json').exists()
originals = []
for name in ('reference-launch.json', 'package-launch.json', 'guard-launch-1.json'):
    value = json.loads((state / name).read_text())
    originals.append({'from': name, 'pid': value['pid'], 'start_ticks': value['start_ticks']})
for label in ('b1-core-reader-fix-reference-1', 'b1-core-reader-fix-package-1', 'b1-core-reader-fix-vm-1'):
    value = json.loads((attempts / label / 'record.json').read_text())
    assert value.get('ended')
    originals.append({'from': label, 'pid': value['pid']})
observation = json.loads((state / 'vm-process-observation-1.json').read_text())
for value in [observation['runner'], *observation['qemu']]:
    originals.append({'from': 'VM native observation', 'pid': value['pid'], 'start_ticks': value['start_ticks']})
for value in originals:
    proc = Path('/proc') / str(value['pid'])
    try:
        raw = (proc / 'stat').read_text()
        value['observed_start_ticks'] = int(raw[raw.rindex(')') + 1:].split()[19])
        value['original_absent'] = 'start_ticks' in value and value['start_ticks'] != value['observed_start_ticks']
    except FileNotFoundError:
        value.update(proc_absent=True, original_absent=True)
assert all(value['original_absent'] for value in originals), originals
scratch = set()
for value in observation['qemu']:
    for arg in value['command']:
        if arg.startswith('file=' + str(root / '.cache/main-consolidation/tmp/limeos-p01-vm-')):
            scratch.add(str(Path(arg.removeprefix('file=').split(',')[0]).parent))
assert len(scratch) == 1 and all(not Path(name).exists() for name in scratch)
value = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'processes': originals,
         'all_recorded_original_processes_absent': True, 'unique_pids': len({v['pid'] for v in originals}),
         'vm_scratch': [{'path': name, 'absent': True} for name in sorted(scratch)], 'observation_only': True}
with (state / 'cleanup.json').open('x') as stream:
    json.dump(value, stream, indent=2)
    stream.write('\n')
print(json.dumps({'unique_original_pids_absent': value['unique_pids'], 'vm_scratch_removed': True}))
