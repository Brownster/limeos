# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Keep sequential native qualification guarded across a lost tool connection."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/main-consolidation'
driver = STATE / 'qualify_fd_context_diagnostics.py'
wrapper = ROOT / '.cache/stack-installed-qualification/detached_guard.py'
record_path = STATE / 'a1-fd-context-qualification-launch.json'
assert not record_path.exists()
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
assert changed == ['crates/executor-storage/src/mount_admission/host_consumers.rs']
with (STATE / 'a1-fd-context-qualification-console.log').open('xb') as log:
    child = subprocess.Popen([sys.executable, str(driver)], cwd=ROOT, stdin=subprocess.DEVNULL,
                             stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
text = (Path('/proc') / str(child.pid) / 'stat').read_text()
record = {'started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'pid': child.pid, 'start_ticks': int(text[text.rindex(')')+1:].split()[19]),
          'session': os.getsid(child.pid), 'process_group': os.getpgid(child.pid),
          'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest(),
          'guard_wrapper_sha256': hashlib.sha256(wrapper.read_bytes()).hexdigest(),
          'guard_sha256': hashlib.sha256((STATE / 'guard.py').read_bytes()).hexdigest(),
          'launcher_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'terminal_result': 'Require all original per-phase guard records to end successfully'}
assert record['pid'] == record['session'] == record['process_group']
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
