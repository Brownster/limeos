# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
"""Bind the FD-owner diagnostic qualification to committed source."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/main-consolidation'
OUT = ROOT / 'docs/rewrite-evidence/p04/2026-10-30-a1-fd-early-context'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
OUT.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def archive(name, path):
    target = OUT / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))

checks, frozen = {}, None
for suffix in ('format-1', 'focused-1', 'compile-1', 'runtime-1', 'doctests-1', 'clippy-1', 'repository-1'):
    label = 'a1-fd-context-' + suffix
    path = STATE / 'attempts' / label
    record = json.loads((path / 'record.json').read_text())
    assert record['exit_code'] == 0 and not record['guard_triggered'] and record['inputs_unchanged']
    assert record['before'] == record['after']
    if frozen is None:
        frozen = record['before']
    assert record['before'] == frozen
    checks[label] = {k:record[k] for k in ('head', 'command', 'started', 'ended', 'exit_code',
                                         'minimum_available_bytes', 'guard_triggered', 'inputs_unchanged')}
    for name in ('record.json', 'output.log'):
        archive('checks/' + label + '-' + name, path / name)
for name, expected in frozen.items():
    assert sha(ROOT / name) == expected, name
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=ROOT)).hexdigest() == expected, name
runtime = json.loads((STATE / 'a1-fd-context-kernel-runtime.json').read_text())
assert runtime['exit_code'] == 0 and runtime['scratch_removed'] and not runtime['cargo_or_compilation_on_tmpfs']
assert not Path(runtime['runtime_tmpdir']).exists()
assert sha(Path(runtime['executable'])) == runtime['sha256']
assert sha(STATE / 'a1_fd_context_runtime.py') == runtime['runner_sha256']
assert '235 passed; 0 failed; 1 ignored' in (STATE / 'a1-fd-context-kernel-runtime.log').read_text()
archive('kernel-runtime.json', STATE / 'a1-fd-context-kernel-runtime.json')
archive('kernel-runtime.log', STATE / 'a1-fd-context-kernel-runtime.log')
procedure = STATE / 'attempts/a1-fd-context-format-apply-1'
record = json.loads((procedure / 'record.json').read_text())
assert record['exit_code'] == 0 and not record['guard_triggered']
assert not record['inputs_unchanged'] and record['after'] == frozen
for name in ('record.json', 'output.log'):
    archive('procedure/format-apply-' + name, procedure / name)
files = {('harness/' + name): STATE / name for name in
         ('guard.py', 'a1_fd_context_runtime.py', 'qualify_fd_context_diagnostics.py', 'archive_fd_context_checks.py')}
files['source/host_consumers.rs'] = ROOT / 'crates/executor-storage/src/mount_admission/host_consumers.rs'
launch_path = STATE / 'a1-fd-context-qualification-launch.json'
launch = json.loads(launch_path.read_text())
for key, path in {
    'driver_sha256': STATE / 'qualify_fd_context_diagnostics.py',
    'guard_wrapper_sha256': ROOT / '.cache/stack-installed-qualification/detached_guard.py',
    'guard_sha256': STATE / 'guard.py',
    'launcher_sha256': STATE / 'launch_fd_context_qualification.py',
}.items():
    assert sha(path) == launch[key], key
archive('qualification-launch.json', launch_path)
archive('qualification-console.log', STATE / 'a1-fd-context-qualification-console.log')
files['harness/launch_qualification.py'] = STATE / 'launch_fd_context_qualification.py'
files['harness/guard_wrapper.py'] = ROOT / '.cache/stack-installed-qualification/detached_guard.py'
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        tar.addfile(info, io.BytesIO(data))
(OUT / 'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
summary = {'source': head, 'recorded_inputs_match_commit': len(frozen), 'checks': checks,
           'runtime': runtime, 'predicate_and_read_order_unchanged': True,
           'owner_identity_scope': 'already-read owner_before, preceding later task revalidation',
           'fd_fact_scope': 'Enumerated FD number when known, original failure forwarded, errno explicitly unknown in context', 'sample_limit_per_side': 4,
           'maximum_tested_event_bytes_less_than': 2048,
           'installed_a1_accepted': False, 'next': 'Distinct diagnostic candidate; identify the actual owner and FD comparison before choosing any runtime correction'}
(OUT / 'source-match.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k:summary[k] for k in ('source','recorded_inputs_match_commit','installed_a1_accepted')}))
