# /// script
# dependencies = []
# ///
import gzip
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/egress"
packet = root / "docs/rewrite-evidence/p04/2026-10-16-network-egress"
frozen = Path("/home/marc/Documents/github/pi-health")

def command(*args):
    return subprocess.check_output(args, cwd=root, text=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(path):
    return sha(path.read_bytes())

source = command("git", "rev-parse", "HEAD").strip()
base = "7df3f7530865c31b7faefd1f7b12a25aa7655860"
subprocess.run(["git", "diff", "--exit-code", "HEAD", "--", "crates", "bins", "tests/fixtures", "Cargo.toml", "Cargo.lock"], cwd=root, check=True)
for path in ("Cargo.toml", "Cargo.lock", "tests/fixtures/stream-b/check-leaves.py"):
    assert command("git", "show", f"{base}:{path}").encode() == (root / path).read_bytes(), path
old_lock = root / "docs/rewrite-evidence/p04/2026-10-16-stream-b-integration/harness/Cargo.lock"
assert old_lock.read_bytes() == (root / ".cache/stream-b-leaf/Cargo.lock").read_bytes()
frozen_source = command("git", "-C", str(frozen), "rev-parse", "HEAD").strip()
assert frozen_source == "80593b29443ea9b81eb60ed4e5c3c3ac7a236204"
frozen_paths = ["network_group_service.py", "network_diagnostics_service.py", "tests/test_network_group_service.py"]
for path in frozen_paths:
    committed = subprocess.check_output(["git", "-C", str(frozen), "show", f"{frozen_source}:{path}"])
    assert committed == (frozen / path).read_bytes(), path
(packet / "frozen-inputs.sha256").write_text("".join(f"{digest(frozen / path)}  {path}\n" for path in frozen_paths))
paths = command("git", "ls-files", "-z", "crates", "bins/core/src/automation", "bins/executor/src/updates", "tests/fixtures", "contracts/generated", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml", ".cargo").split("\0")
paths = sorted(path for path in paths if path and (root / path).is_file())
(packet / "inputs.sha256").write_text("".join(f"{digest(root / path)}  {path}\n" for path in paths))
for path in sorted((root / ".cache/stream-b-leaf").rglob("*")):
    if path.is_file():
        dest = packet / "harness" / path.relative_to(root / ".cache/stream-b-leaf")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
(cache / "source-status.log").write_text(command("git", "status", "--short", "--branch"))
(cache / "source-history.log").write_text(command("git", "log", "-3", "--format=%H %s"))
(cache / "cargo-metadata.json").write_text(command("cargo", "metadata", "--offline", "--locked", "--format-version", "1", "--manifest-path", ".cache/stream-b-leaf/Cargo.toml"))
tests = (cache / "test.log").read_text()
assert sum(map(int, re.findall(r"test result: ok\. (\d+) passed; 0 failed", tests))) == 453
assert "warning:" not in tests and "error:" not in tests
assert "Finished" in (cache / "clippy.log").read_text()
metadata = {
    "source": source, "base": base,
    "source_committed_after_checks_without_intervening_product_changes": True,
    "cases": {"domain": 301, "adapter_host_policy": 127, "api": 19, "runner": 6, "total": 453, "new_domain": 20, "new_adapter": 9},
    "fixtures": {"comparisons": 10, "responses": 16},
    "input_count": len(paths), "input_scope": "Source/fixture superset; not every included crate unit suite ran",
    "frozen_root": str(frozen), "frozen_source": frozen_source, "frozen_input_count": len(frozen_paths),
    "harness_lock_origin": str(old_lock.relative_to(root)), "harness_lock_sha256": digest(old_lock),
    "bounds": {"raw_response_bytes": 64, "report_bytes": 4096, "inclusive_original_sample_age_seconds": 90, "inclusive_sample_pair_skew_seconds": 5, "engine_id_bytes": 128},
    "commands": [
        "uv run --offline --no-project tests/fixtures/stream-b/check-leaves.py",
        "cp docs/rewrite-evidence/p04/2026-10-16-stream-b-integration/harness/Cargo.lock .cache/stream-b-leaf/Cargo.lock",
        "cargo test --offline --locked --manifest-path .cache/stream-b-leaf/Cargo.toml",
        "cargo clippy --offline --locked --manifest-path .cache/stream-b-leaf/Cargo.toml --all-targets -- -D warnings",
        "rustfmt --edition 2024 --check --config skip_children=true crates/domain/src/deployment/egress.rs crates/domain/src/deployment/egress/tests.rs crates/domain/src/deployment/mod.rs crates/executor-container/src/deployment/egress.rs crates/executor-container/src/deployment/egress/tests.rs crates/executor-container/src/deployment/mod.rs",
        "uv run --offline --no-project .cache/egress/verify-harness.py",
    ],
    "toolchain": {"rustc": command("rustc", "-Vv"), "cargo": command("cargo", "-Vv"), "uv": command("uv", "--version")},
    "environment": {"CARGO_BUILD_JOBS": "1", "CARGO_INCREMENTAL": "0", "RUST_TEST_THREADS": "2", "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target", "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp", "CCACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/ccache", "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv"},
    "limits": "Local pure policy and supplied-byte decoder; no new frontend, live probe, runtime registration, installed/ARM64/performance/soak/Pi acceptance or defect/P04/cutover closure",
}
(packet / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
shutil.copyfile(cache / "harness-regeneration.json", packet / "harness-regeneration.json")
for path in sorted(cache.iterdir()):
    if path.suffix in {".log", ".py"} or path.name == "cargo-metadata.json":
        (packet / (path.name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
artifacts = sorted(path for path in packet.rglob("*") if path.is_file() and path.name != "artifacts.sha256")
(packet / "artifacts.sha256").write_text("".join(f"{digest(path)}  {path.relative_to(packet)}\n" for path in artifacts))
print(json.dumps({"source": source, "inputs": len(paths), "frozen_inputs": len(frozen_paths), "artifacts": len(artifacts)}))
