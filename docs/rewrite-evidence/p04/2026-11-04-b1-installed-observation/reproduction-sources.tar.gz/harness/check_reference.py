# /// script
# dependencies = []
# ///
import datetime
import json
from pathlib import Path
import subprocess
import sys

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-installed-observation-qualification'
commands = [
    [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_p04_automation_guest.py', '-v'],
    [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests/reference', '-p', 'test_p04_mounts_guest.py', '-v'],
    ['uv', 'run', '--offline', '--no-project', '--cache-dir', '.cache/uv', '--with', 'ruff', 'ruff', 'check', 'tests/privileged_vm/p04_automation_guest.py', 'tests/reference/test_p04_automation_guest.py'],
    ['uv', 'run', '--offline', '--no-project', '--cache-dir', '.cache/uv', '--with', 'ruff', 'ruff', 'format', '--check', 'tests/privileged_vm/p04_automation_guest.py', 'tests/reference/test_p04_automation_guest.py'],
    [sys.executable, 'scripts/check_repository.py'],
    ['git', 'diff', '--check'],
]
results = []
for index, command in enumerate(commands, 1):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (state / f'reference-step-{index}.log').open('xb') as log:
        value = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    results.append({'command': command, 'started': started, 'ended': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': value.returncode})
    (state / 'reference-checks.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results[-1]), flush=True)
    if value.returncode:
        print((state / f'reference-step-{index}.log').read_text()[-8000:], flush=True)
        raise SystemExit(value.returncode)
