# /// script
# dependencies = []
# ///
from pathlib import Path
root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-installed-observation-qualification'
source = (root / '.cache/a1-installed-recovery-qualification/observe_vm.py').read_text()
with (state / 'observe_vm.py').open('x') as stream:
    stream.write(source.replace('a1-installed-recovery', 'b1-installed-observation'))
