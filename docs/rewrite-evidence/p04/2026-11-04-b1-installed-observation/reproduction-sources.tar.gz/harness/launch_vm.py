# /// script
# dependencies = []
# ///
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-installed-observation-qualification'
builders = root / '.cache/stack-installed-qualification'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((state / 'inputs-1.json').read_text())
packages = json.loads((builders / 'candidate-12/inputs.json').read_text())
label = 'b1-installed-observation-vm-1'
assert not (root / '.cache/main-consolidation/attempts' / label).exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == manifest['fixture_source']
assert sha(builders / 'candidate-12/inputs.json') == manifest['package_inputs_sha256']
assert sha(builders / 'build-12/record.json') == manifest['build_record_sha256']
build = json.loads((builders / 'build-12/record.json').read_text())
for name, expected in build['before'].items(): assert sha(root / name) == expected
for name, facts in manifest['test_only_changes_since_package_build'].items(): assert sha(root / name) == facts['after']
for name, expected in manifest['guest'].items(): assert sha(state / 'guest-1' / name) == expected
for name, expected in manifest['runner_support'].items(): assert sha(state / name) == expected
assert sha(state / 'run_1024.py') == manifest['runner_sha256'] == sha(root / 'tests/privileged_vm/run.py')
assert sha(root / 'crates/persistence/src/lib.rs') == manifest['schema_source_sha256']
for name, expected in packages['repository'].items(): assert sha(builders / 'candidate-12/repository' / name) == expected
busy = [x for x in subprocess.check_output(['ps', '-eo', 'comm'], text=True).splitlines() if x.strip() in ('cargo', 'rustc', 'rustdoc')]
assert not busy
# Only Docker Desktop may already own a QEMU; never stop it or another VM.
others = subprocess.run(['ps', '-C', 'qemu-system-x86_64', '-o', 'args='], text=True, capture_output=True)
assert others.returncode in (0, 1)
assert all('/opt/docker-desktop/' in line for line in others.stdout.splitlines()), others.stdout
now = datetime.datetime.now(datetime.timezone.utc)
assert packages['signing_key_expires'] > int(now.timestamp()) + 3600
available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
minimum = 3 * 1024**3 + 1536 * 1024**2
admission = {'at': now.isoformat(), 'available_bytes': available, 'start_threshold_bytes': minimum, 'runtime_stop_floor_bytes': 3 * 1024**3, 'guest_memory_mib': 1024, 'disk_free_bytes': shutil.disk_usage(root).free, 'admitted': available >= minimum and shutil.disk_usage(root).free >= 8 * 1024**3}
(state / 'admission-1.json').write_text(json.dumps(admission, indent=2) + '\n')
if not admission['admitted']: raise SystemExit(75)
wrapper = builders / 'detached_guard.py'
command = [sys.executable, str(wrapper), label, sys.executable, str(state / 'run_1024.py'),
    '--image', str(root / '.cache/a1-namespace-review/debian-12-genericcloud-amd64.qcow2'),
    '--checksums', str(root / '.cache/a1-namespace-review/SHA512SUMS'),
    '--repository', str(builders / 'candidate-12/repository'),
    '--guest-script', str(state / 'guest-1/p04_automation_guest.py'), '--output', str(state / 'result-1.json')]
with (state / 'guard-console-1.log').open('xb') as log:
    child = subprocess.Popen(command, cwd=root, start_new_session=True, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
raw = (Path('/proc') / str(child.pid) / 'stat').read_text()
value = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': child.pid, 'start_ticks': int(raw[raw.rindex(')') + 1:].split()[19]), 'session': os.getsid(child.pid), 'process_group': os.getpgid(child.pid), 'command': command, 'label': label, 'launcher_sha256': sha(Path(__file__)), 'guard_sha256': sha(root / '.cache/main-consolidation/guard.py')}
(state / 'guard-launch-1.json').write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({'pid': child.pid, 'label': label, 'admission': admission}))
