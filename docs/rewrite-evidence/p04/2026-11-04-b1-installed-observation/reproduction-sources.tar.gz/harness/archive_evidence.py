# /// script
# dependencies = []
# ///
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/home/marc/Documents/github/lime-os')
state = root / '.cache/b1-installed-observation-qualification'
builders = root / '.cache/stack-installed-qualification'
attempts = root / '.cache/main-consolidation/attempts'
out = root / 'docs/rewrite-evidence/p04/2026-11-04-b1-installed-observation'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text())
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
manifest = read(state / 'inputs-1.json')
packages = read(builders / 'candidate-12/inputs.json')
build = read(builders / 'build-12/record.json')
assert manifest['fixture_source'] == head
assert manifest['product_source'] == packages['source'] == build['source']
assert sha(builders / 'candidate-12/inputs.json') == manifest['package_inputs_sha256']
assert sha(builders / 'build-12/record.json') == manifest['build_record_sha256']
native = read(attempts / 'b1-installed-observation-reference-2/record.json')
vm = read(attempts / 'b1-installed-observation-vm-1/record.json')
assert vm['head'] == head
assert native['before'] == native['after'] == vm['before'] == vm['after']
for name, expected in vm['before'].items():
    assert sha(root / name) == expected
    assert hashlib.sha256(subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=root)).hexdigest() == expected
for name, expected in build['before'].items(): assert vm['before'][name] == expected
assert set(vm['before']) - set(build['before']) == set(manifest['test_only_changes_since_package_build'])
for name, expected in manifest['guest'].items(): assert sha(state / 'guest-1' / name) == expected
assert sha(state / 'run_1024.py') == manifest['runner_sha256'] == sha(root / 'tests/privileged_vm/run.py')
assert sha(root / 'crates/persistence/src/lib.rs') == manifest['schema_source_sha256']
for value in (native, vm):
    assert value['ended'] and value['inputs_unchanged'] and not value['guard_triggered']
assert native['exit_code'] == 0
cleanup = read(state / 'cleanup.json')
assert cleanup['all_recorded_original_processes_absent']
assert all(value['absent'] for value in cleanup['vm_scratch'])
log = (attempts / 'b1-installed-observation-vm-1/output.log').read_text()
if vm['exit_code'] == 0:
    result = read(state / 'result-1.json')
    assert result['summary'] == 'pass' and result['stage'] == 'complete'
    assert len(result['passed']) == 4 and len(result['restarts']) == 2
    accepted = True
else:
    failures = [json.loads(line.partition(' ')[2]) for line in log.splitlines() if line.startswith('B1_FAILURE ')]
    assert len(failures) == 1
    result = failures[0]
    assert result['summary'] == 'fail'
    accepted = False
assert result['fixture_sha256'] == manifest['guest']['p04_automation_guest.py']
assert result['package_version'] == packages['version']
assert result['authority_schema'] == 14
for name, expected in result['binary_sha256'].items(): assert packages['binaries'][name]['sha256'] == expected
assert result['package_sha256'] == packages['packages']
out.mkdir(exist_ok=False)
def archive(name, path):
    target = out / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for label in ('b1-installed-observation-reference-1', 'b1-installed-observation-reference-2', 'b1-installed-observation-vm-1'):
    for name in ('record.json', 'output.log'):
        archive('checks/' + label + '-' + name, attempts / label / name)
for path in sorted(state.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.log', '.txt'):
        archive('observations/' + path.name, path)
archive('package-inputs.json', builders / 'candidate-12/inputs.json')
archive('build-record.json', builders / 'build-12/record.json')
sources = {'guest/' + p.name: p for p in sorted((state / 'guest-1').glob('*.py'))}
sources.update({'harness/' + p.name: p for p in sorted(state.glob('*.py'))})
sources['harness/guard.py'] = root / '.cache/main-consolidation/guard.py'
sources['harness/detached_guard.py'] = builders / 'detached_guard.py'
sources['reference/test_p04_automation_guest.py'] = root / 'tests/reference/test_p04_automation_guest.py'
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as tar:
    for name, path in sorted(sources.items()):
        data = path.read_bytes()
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(data), 0o644, 0
        tar.addfile(item, io.BytesIO(data))
(out / 'reproduction-sources.tar.gz').write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
(out / 'installed-result.json').write_text(json.dumps(result, indent=2) + '\n')
summary = {'fixture_source': head, 'product_source': packages['source'], 'product_inputs_unchanged': len(build['before']),
    'fixture_inputs_match_committed_source': len(vm['before']), 'test_only_changes_since_package_build': manifest['test_only_changes_since_package_build'],
    'guest_modules': len(manifest['guest']), 'guest_memory_mib': 1024, 'canonical_runner_unchanged': True,
    'native_reference_cases': 18, 'native_precommit_head': native['head'],
    'native': {k: native[k] for k in ('started', 'ended', 'exit_code', 'minimum_available_bytes', 'guard_triggered', 'inputs_unchanged')},
    'vm': {k: vm[k] for k in ('started', 'ended', 'exit_code', 'minimum_available_bytes', 'guard_triggered', 'inputs_unchanged')},
    'stage': result['stage'], 'installed_scenario_passed': accepted, 'all_recorded_original_processes_absent': True,
    'recorded_unique_pids': cleanup['unique_pids'], 'vm_scratch_removed': True,
    'b1_milestone_complete': False, 'installed_ui_qualified': False, 'arm64_pi_qualified': False,
    'upgrade_return_soak_qualified': False, 'private_keys_packages_binaries_or_disks_archived': False}
(out / 'source-match.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'source': head, 'stage': result['stage'], 'vm_exit_code': vm['exit_code'], 'scenario_passed': accepted}))
