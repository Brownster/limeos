# /// script
# dependencies = []
# ///
from pathlib import Path
state = Path('/home/marc/Documents/github/lime-os/.cache/b1-installed-observation-qualification')
checks = (state / 'check_reference.py').read_text().replace('reference-step-', 'reference-2-step-').replace('reference-checks.json', 'reference-2-checks.json')
with (state / 'check_reference_2.py').open('x') as stream: stream.write(checks)
launcher = (state / 'launch_reference.py').read_text().replace('reference-1', 'reference-2').replace('reference-admission.json', 'reference-2-admission.json').replace('reference-console.log', 'reference-2-console.log').replace('reference-launch.json', 'reference-2-launch.json').replace('check_reference.py', 'check_reference_2.py')
with (state / 'launch_reference_2.py').open('x') as stream: stream.write(launcher)
