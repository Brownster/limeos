# /// script
# dependencies = []
# ///
import json
from pathlib import Path
state = Path('/home/marc/Documents/github/lime-os/.cache/b1-installed-observation-qualification')
attempt = state.parent / 'main-consolidation/attempts/b1-installed-observation-vm-1'
values = [json.loads(line.partition(' ')[2]) for line in (attempt / 'output.log').read_text().splitlines() if line.startswith('B1_FAILURE ')]
assert len(values) == 1
value = values[0]
with (state / 'failure-1.json').open('x') as stream: json.dump(value, stream, indent=2)
print(json.dumps({key: value.get(key) for key in ('stage','error','passed','reader_ready','reader_unit','created_schedule','history_after_failure','unit_diagnostics')}, indent=2))
