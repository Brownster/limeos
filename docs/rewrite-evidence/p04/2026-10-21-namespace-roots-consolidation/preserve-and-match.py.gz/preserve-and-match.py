# /// script
# dependencies = []
# ///
"""Preserve unfinished root work and verify the inputs of the committed fix."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STATE = ROOT / '.cache/main-consolidation'
OUT = STATE / 'request-2026-10-21'
OUT.mkdir()

def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd)

head = git('rev-parse', 'HEAD').decode().strip()
assert head == 'b28bdb19789abeaf2255dee2c31bd7d8ace8c5c1'
draft = 'tests/fixtures/storage-namespace-roots'
expected = {f'{draft}/{name}' for name in ('Cargo.toml', 'Cargo.lock', 'README.md', 'src/main.rs')}
assert not git('diff', 'HEAD', '--name-only').strip()
assert set(git('ls-files', '--others', '--exclude-standard').decode().splitlines()) == expected
entries = []
for name in sorted(expected):
    data = (ROOT / name).read_bytes()
    entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
recovery = OUT / 'unfinished-namespace-probe'
recovery.mkdir()
destination = recovery / 'storage-namespace-roots'
(ROOT / draft).rename(destination)
for entry in entries:
    restored = destination / Path(entry['path']).relative_to(draft)
    assert hashlib.sha256(restored.read_bytes()).hexdigest() == entry['sha256']
(recovery / 'manifest.json').write_text(json.dumps({
    'base': head, 'original_directory': draft,
    'reason': 'Unfinished disposable VM read-adapter probe; strict Clippy passed, guest controller and runtime qualification remain unfinished. Preserved to return the checkout to local main without publishing draft acceptance.',
    'clippy_record': 'attempts/storage-namespace-probe-clippy-1/record.json',
    'files': entries,
}, indent=2) + '\n')
tracked = set(filter(None, git('ls-files', '-z').decode().split('\0')))
results = []
for label in ('storage-namespace-compile-1', 'storage-namespace-runtime-1', 'storage-namespace-clippy-1', 'storage-namespace-docs-1'):
    record = json.loads((STATE / 'attempts' / label / 'record.json').read_text())
    assert record['exit_code'] == 0 and record['inputs_unchanged'] and not record['guard_triggered']
    verified = 0
    for name, digest in record['before'].items():
        if name in tracked:
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, (label, name)
            assert hashlib.sha256(git('show', f'{head}:{name}')).hexdigest() == digest, (label, name, 'commit')
            verified += 1
    results.append({'attempt': label, 'tracked_inputs_matching_committed_source': verified,
                    'exit_code': 0, 'guard_triggered': False, 'inputs_unchanged': True})
(OUT / 'source-match.json').write_text(json.dumps({'source': head, 'checks': results}, indent=2) + '\n')
print(json.dumps({'head': head, 'draft_recovery': str(recovery.relative_to(ROOT)), 'preserved_files': len(entries), 'checks': results}))
