# /// script
# dependencies = []
# ///
"""Audit merged references while preserving each unfinished worktree."""
import datetime
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
OUT = ROOT / '.cache/main-consolidation/request-2026-10-21'

def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd)

assert git('branch', '--show-current').strip() == b'main'
assert not git('status', '--porcelain=v1', '--untracked-files=all').strip()
assert not git('for-each-ref', '--no-merged=main', '--format=%(refname)', 'refs/heads', 'refs/remotes').strip()
trees = []
for block in git('worktree', 'list', '--porcelain').decode().strip().split('\n\n'):
    fields = dict(row.split(' ', 1) for row in block.splitlines() if ' ' in row)
    path = Path(fields['worktree'])
    subprocess.run(['git', 'merge-base', '--is-ancestor', fields['HEAD'], 'main'], cwd=ROOT, check=True)
    status = git('status', '--porcelain=v1', '-z', '--untracked-files=all', cwd=path)
    item = {**fields, 'committed_head_merged': True, 'dirty': bool(status)}
    if path != ROOT and status:
        dest = OUT / 'recovery' / path.name
        if not dest.exists():
            dest.mkdir(parents=True)
            (dest / 'status.z').write_bytes(status)
            (dest / 'diff-head.patch').write_bytes(git('diff', 'HEAD', '--binary', cwd=path))
            (dest / 'diff-index.patch').write_bytes(git('diff', '--cached', '--binary', cwd=path))
            untracked = list(filter(None, git('ls-files', '--others', '--exclude-standard', '-z', cwd=path).split(b'\0')))
            entries = []
            with tarfile.open(dest / 'untracked.tar.gz', 'w:gz', dereference=False) as archive:
                for raw in untracked:
                    name = raw.decode()
                    source = path / name
                    archive.add(source, arcname=name, recursive=False)
                    entry = {'path': name}
                    if source.is_file() and not source.is_symlink():
                        entry['sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
                    elif source.is_symlink():
                        entry['symlink'] = str(source.readlink())
                    entries.append(entry)
            (dest / 'untracked.json').write_text(json.dumps(entries, indent=2) + '\n')
        assert (dest / 'status.z').read_bytes() == status
        assert (dest / 'diff-head.patch').read_bytes() == git('diff', 'HEAD', '--binary', cwd=path)
        assert (dest / 'diff-index.patch').read_bytes() == git('diff', '--cached', '--binary', cwd=path)
        for entry in json.loads((dest / 'untracked.json').read_text()):
            source = path / entry['path']
            if 'sha256' in entry:
                assert hashlib.sha256(source.read_bytes()).hexdigest() == entry['sha256']
            elif 'symlink' in entry:
                assert str(source.readlink()) == entry['symlink']
        item['recovery'] = str(dest.relative_to(ROOT))
        item['recovery_matches_worktree'] = True
    trees.append(item)
refs = git('for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads', 'refs/remotes').decode().splitlines()
engineer = {}
for name, revision in [('schedule_contracts', 'ca13ffb'), ('abi_fix', '4baf338'), ('handoff', '71df2a6')]:
    subprocess.run(['git', 'merge-base', '--is-ancestor', revision, 'main'], cwd=ROOT, check=True)
    engineer[name] = git('rev-parse', revision).decode().strip()
result = {'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'main': git('rev-parse', 'main').decode().strip(), 'main_clean': True,
          'all_local_and_fetched_remote_tips_merged': True, 'refs': refs, 'trees': trees,
          'other_engineer': engineer, 'push_performed': False}
(OUT / f'{sys.argv[1]}.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'main': result['main'], 'main_clean': True, 'all_tips_merged': True,
                  'dirty_worktrees_preserved': sum(t['dirty'] for t in trees),
                  'clean_non_root_worktrees': sum(not t['dirty'] for t in trees[1:]),
                  'local_branches': sum(r.startswith('refs/heads/') for r in refs)}))
