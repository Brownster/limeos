# /// script
# dependencies = []
# ///
"""Seal the exact configured-policy source, final checks and original drafts."""
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/home/marc/Documents/github/lime-os')
STATE = ROOT / '.cache/b1-policy-qualification'
DEST = ROOT / 'docs/rewrite-evidence/p04/2026-10-30-b1-configured-policy'
COMMIT = (STATE / 'feature-commit.txt').read_text().strip()
assert len(COMMIT) == 40 and all(char in '0123456789abcdef' for char in COMMIT)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def committed(name):
    return subprocess.check_output(['git', 'show', f'{COMMIT}:{name}'], cwd=ROOT)


def put(name, data):
    path = DEST / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def compressed(name, path):
    put(name, gzip.compress(path.read_bytes(), mtime=0))


assert not DEST.exists()
records = {}
for path in sorted((ROOT / '.cache/main-consolidation/attempts').glob('b1-policy-*')):
    record = json.loads((path / 'record.json').read_text())
    assert record.get('ended') and record['inputs_unchanged'] and record['before'] == record['after']
    assert not record['guard_triggered'] and not record['observed_external_compilers']
    assert record['minimum_available_bytes'] >= record['memory_floor_bytes'] == 3 * 1024**3
    records[path.name] = record

final = ['b1-policy-rust-4', 'b1-policy-clippy-4', 'b1-policy-contracts-1', 'b1-policy-frontend-3', 'b1-policy-browser-2']
expected = records[final[0]]['before']
assert len(expected) == 718
for label in final:
    assert records[label]['exit_code'] == 0 and records[label]['before'] == expected, label
for name, sha in expected.items():
    assert digest(committed(name)) == sha, name
    assert digest((ROOT / name).read_bytes()) == sha, name

build = json.loads((STATE / 'frontend-build.json').read_text())
assert build['exit_code'] == 0 and build['inputs_unchanged']
for name, sha in build['inputs'].items():
    assert digest(committed(name)) == sha, name
browser = json.loads((STATE / 'browser-2/result.json').read_text())
assert build['ui'] == browser['ui'] == browser['served_ui']
for name, sha in build['ui'].items():
    assert digest((ROOT / name).read_bytes()) == sha, name
assert len([call for call in browser['calls'] if call['method'] == 'POST']) == 3

for label in records:
    directory = ROOT / '.cache/main-consolidation/attempts' / label
    for name in ['record.json', 'output.log']:
        compressed(f'checks/{label}/{name}.gz', directory / name)

for path in sorted(STATE.iterdir()):
    if path.is_file() and path.suffix in ['.json', '.log']:
        compressed(f'launch-and-local/{path.name}.gz', path)
for dirname in ['frontend-initial', 'frontend-utf8', 'browser-1', 'browser-2']:
    for path in sorted((STATE / dirname).rglob('*')):
        if not path.is_file():
            continue
        relative = str(path.relative_to(STATE))
        if path.suffix == '.png':
            put(relative, path.read_bytes())
        else:
            compressed(relative + '.gz', path)

changed = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', COMMIT], cwd=ROOT, text=True).splitlines()
sources = {name: committed(name) for name in changed}
for path in [*STATE.glob('*.py'), ROOT / '.cache/main-consolidation/guard.py', ROOT / '.cache/stack-installed-qualification/detached_guard.py']:
    sources[str(path.relative_to(ROOT))] = path.read_bytes()
buffer = io.BytesIO()
executables = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, data in sorted(sources.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o755 if (ROOT / name).stat().st_mode & 0o111 else 0o644
        if info.mode == 0o755:
            executables.append(name)
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
put('reproduction-sources.tar.gz', gzip.compress(buffer.getvalue(), mtime=0))
patch = subprocess.check_output(['git', 'show', '--format=fuller', '--binary', COMMIT], cwd=ROOT)
put('source.patch.gz', gzip.compress(patch, mtime=0))
match = {
    'qualified_commit': COMMIT,
    'parent_commit': subprocess.check_output(['git', 'rev-parse', f'{COMMIT}^'], cwd=ROOT, text=True).strip(),
    'guard_recorded_precommit_head': records[final[0]]['head'],
    'final_identical_guard_input_maps': final,
    'committed_input_count': len(expected),
    'committed_inputs_match': True,
    'worktree_inputs_match': True,
    'frontend_build_committed_input_count': len(build['inputs']),
    'frontend_build_inputs_match_commit': True,
    'frontend_ui_matches_browser_served_ui': True,
    'ui': build['ui'],
    'runtime_tests': 791,
    'compile_fail_doctests': 9,
    'new_native_tests': 18,
    'frontend_tests': 242,
    'browser_explicit_posts': 3,
    'checks': {label: {key: record[key] for key in ['started', 'ended', 'exit_code', 'inputs_unchanged', 'guard_triggered', 'minimum_available_bytes', 'memory_floor_bytes', 'observed_external_compilers']} for label, record in records.items()},
    'draft_input_differences_from_final': {label: sorted(name for name in set(expected) | set(record['before']) if expected.get(name) != record['before'].get(name)) for label, record in records.items() if label not in final},
    'reproduction_source_hashes': {name: digest(data) for name, data in sorted(sources.items())},
    'reproduction_executable_paths': executables,
    'scope': 'Local configured-policy Core/Store/API tests and closed-browser UI only; no actual deployed settings, protected collector, scheduler, package, ARM64, external send or cutover acceptance',
}
put('source-match.json', (json.dumps(match, indent=2) + '\n').encode())
print(json.dumps({'commit': COMMIT, 'inputs': len(expected), 'frontend_inputs': len(build['inputs']), 'guards': len(records), 'files': len([path for path in DEST.rglob('*') if path.is_file()])}))
