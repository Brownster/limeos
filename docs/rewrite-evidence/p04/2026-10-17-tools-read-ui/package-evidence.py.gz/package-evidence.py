# /// script
# dependencies = []
# ///
"""Archive the local frontend checks at their exact committed source."""

import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path.cwd()
cache = root / ".cache/tools-ui"
packet = root / "docs/rewrite-evidence/p04/2026-10-17-tools-read-ui"


def command(*args):
    return subprocess.check_output(args, cwd=root, text=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source = command("git", "rev-parse", "HEAD").strip()
base = command("git", "rev-parse", "f8aec4a").strip()
subprocess.run(
    [
        "git",
        "diff",
        "--exit-code",
        "HEAD",
        "--",
        "frontend",
        "tests/fixtures",
        "crates",
    ],
    cwd=root,
    check=True,
)
unchanged_groups = [
    "crates",
    "bins",
    "tests/fixtures",
    "contracts",
    "Cargo.toml",
    "Cargo.lock",
]
subprocess.run(
    ["git", "diff", "--exit-code", base, "HEAD", "--", *unchanged_groups],
    cwd=root,
    check=True,
)
protected = [
    "frontend/src/Dashboard.tsx",
    "frontend/src/api.ts",
    "frontend/src/style.css",
    "frontend/package.json",
    "frontend/package-lock.json",
    "frontend/tsconfig.json",
]
for path in protected:
    assert (
        command("git", "show", f"{base}:{path}").encode() == (root / path).read_bytes()
    ), path
paths = command(
    "git",
    "ls-files",
    "-z",
    "frontend/src",
    "frontend/tests",
    "frontend/package.json",
    "frontend/package-lock.json",
    "frontend/tsconfig.json",
    "contracts/generated",
    "tests/fixtures",
    "crates/domain/src/deployment/tools.rs",
    "crates/api/src/deployment.rs",
).split("\0")
paths = sorted(path for path in paths if path and (root / path).is_file())
packet.mkdir(parents=True, exist_ok=True)
(packet / "inputs.sha256").write_text(
    "".join(f"{digest(root / path)}  {path}\n" for path in paths)
)
results = json.loads((cache / "frontend-results.json").read_text())
assert results["tests"] == 161 and len(results["files"]) == 9
assert (
    next(
        row["tests"]
        for row in results["files"]
        if row["file"].endswith("tools-status.test.mjs")
    )
    == 38
)
assert "built in" in (cache / "preview-build.log").read_text()
assert "error TS" not in (cache / "type-check.log").read_text()
assert "All checks passed" in (cache / "scripts-lint.log").read_text()
assert not (root / "frontend/node_modules").exists()
installed = {}
expected = json.loads((root / "frontend/package.json").read_text())
for name, version in {
    **expected["dependencies"],
    **expected["devDependencies"],
}.items():
    path = root.parents[1] / "frontend/node_modules" / name / "package.json"
    actual = json.loads(path.read_text())["version"]
    assert actual == version, (name, actual, version)
    installed[name] = {"version": actual, "package_json_sha256": digest(path)}
for path in sorted((cache / "preview").rglob("*")):
    if path.is_file():
        dest = packet / "preview" / path.relative_to(cache / "preview")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
shutil.copyfile(cache / "vite.config.mjs", packet / "preview/vite.config.mjs")
(cache / "source-status.log").write_text(
    command("git", "status", "--short", "--branch")
)
(cache / "source-history.log").write_text(command("git", "log", "-3", "--format=%H %s"))
metadata = {
    "source": source,
    "base": base,
    "source_committed_after_checks_without_intervening_product_changes": True,
    "frontend": results,
    "new_tools_cases": 38,
    "input_count": len(paths),
    "input_scope": "Frontend source/contracts/fixture superset, including unchanged Rust wire references; no Rust test rerun",
    "unchanged_groups_from_base": unchanged_groups,
    "protected_frontend_paths_unchanged": protected,
    "installed_frontend_dependencies": installed,
    "bounds": {
        "streamed_response_bytes": 8192,
        "read_deadline_ms": 12000,
        "inclusive_original_component_age_seconds": 90,
        "path_bytes": 512,
        "port_min": 1,
        "port_max": 65535,
    },
    "commands": [
        "npm run check (cwd frontend, temporary pinned node_modules symlink removed afterward)",
        "uv run --offline --no-project .cache/tools-ui/check-frontend.py",
        "node /home/marc/Documents/github/lime-os/frontend/node_modules/vite/bin/vite.js build --config .cache/tools-ui/vite.config.mjs",
        "uv run --offline --no-project --with ruff==0.17.0 ruff check .cache/tools-ui/check-frontend.py .cache/tools-ui/package-evidence.py",
        "git diff --check",
    ],
    "toolchain": {
        "node": command("node", "--version"),
        "npm": command("npm", "--version"),
        "uv": command("uv", "--version"),
    },
    "environment": {
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
        "npm_config_cache": "/home/marc/Documents/github/lime-os/.cache/npm",
        "frontend_suites": "sequential, one file at a time",
    },
    "visual_qa": json.loads((cache / "browser-availability.json").read_text()),
    "preview_scope": "Standalone synthetic current/partially-expired/unavailable views; no mounted authenticated panel or browser render; bundle size is not performance qualification",
    "limits": "Local DTO/transport/controller/static-markup/owner-key checks only. Protected cache/current authority/host lifetime, production contracts/shell/route registration, browser React lifecycle/visual/installed acceptance and effects/recovery/ARM64/Pi/performance/soak/defect/P04/cutover gates remain open.",
}
(packet / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
for name in ["frontend-results.json", "browser-availability.json"]:
    shutil.copyfile(cache / name, packet / name)
for path in sorted(cache.iterdir()):
    if path.suffix in {".log", ".py"}:
        (packet / (path.name + ".gz")).write_bytes(
            gzip.compress(path.read_bytes(), mtime=0)
        )
artifacts = sorted(
    path
    for path in packet.rglob("*")
    if path.is_file() and path.name != "artifacts.sha256"
)
(packet / "artifacts.sha256").write_text(
    "".join(f"{digest(path)}  {path.relative_to(packet)}\n" for path in artifacts)
)
print(
    json.dumps(
        {
            "source": source,
            "inputs": len(paths),
            "artifacts": len(artifacts),
            "frontend_tests": results["tests"],
        }
    )
)
