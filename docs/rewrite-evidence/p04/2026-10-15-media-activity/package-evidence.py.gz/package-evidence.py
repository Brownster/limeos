#!/usr/bin/env -S uv run --offline
# /// script
# dependencies = []
# ///
"""Bind already completed activity checks to committed inputs and frozen sources."""

import gzip
import hashlib
import json
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / ".cache/media-activity-leaf"
PACKET = ROOT / "docs/rewrite-evidence/p04/2026-10-15-media-activity"
CODE = "873938a17b153415196874b8fa2d99a6c8d732cc"
FROZEN = "80593b29443ea9b81eb60ed4e5c3c3ac7a236204"
REFERENCE = Path("/home/marc/Documents/github/pi-health")


def run(*args: str, cwd: Path = ROOT) -> bytes:
    return subprocess.check_output(args, cwd=cwd)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


assert run("git", "rev-parse", "HEAD").decode().strip() == CODE
files = (
    run(
        "git",
        "ls-files",
        "Cargo.toml",
        "Cargo.lock",
        "crates/domain",
        "crates/api",
        "crates/contracts",
        "crates/executor-container/Cargo.toml",
        "crates/executor-container/src/deployment/mod.rs",
        "crates/executor-container/src/deployment/activity.rs",
        "crates/executor-container/src/deployment/activity",
        "crates/executor-container/src/deployment/media.rs",
        "crates/executor-container/src/deployment/media",
        "tests/fixtures/deployment",
        "tests/fixtures/storage-contracts.json",
        "frontend/src",
        "frontend/package.json",
        "frontend/package-lock.json",
        "frontend/tsconfig.json",
        "frontend/tests/media-activity.test.mjs",
        "frontend/tests/helpers/media-activity.mjs",
        "contracts/generated/types.ts",
    )
    .decode()
    .splitlines()
)
sources = {}
for name in files:
    data = (ROOT / name).read_bytes()
    assert data == run("git", "show", f"{CODE}:{name}"), name
    sources[name] = sha(data)
reference = {}
for name in [
    "activity_service.py",
    "activity_credentials.py",
    "tests/test_activity_service.py",
]:
    data = run("git", "show", f"{FROZEN}:{name}", cwd=REFERENCE)
    assert data == (REFERENCE / name).read_bytes(), name
    reference[name] = sha(data)
test = (CACHE / "test-final.log").read_text()
for count in [26, 13, 68]:
    assert f"{count} passed; 0 failed" in test
assert "FAILED" not in test
assert (
    "# pass 10" in (CACHE / "ui-final.log").read_text()
    and "# fail 0" in (CACHE / "ui-final.log").read_text()
)
assert (
    "# pass 9" in (CACHE / "ui-partial-regression-red.log").read_text()
    and "# fail 1" in (CACHE / "ui-partial-regression-red.log").read_text()
)
assert (
    "Finished `dev`" in (CACHE / "clippy-final.log").read_text()
    and "error:" not in (CACHE / "clippy-final.log").read_text()
)
for name in ["typescript.log", "rustfmt.log"]:
    assert (CACHE / name).read_bytes() == b""
assert "All checks passed!" in (CACHE / "ruff.log").read_text()
assert "already formatted" in (CACHE / "ruff-format.log").read_text()
for name in [
    "Cargo.toml",
    "Cargo.lock",
    "domain/Cargo.toml",
    "domain/lib.rs",
    "adapter/Cargo.toml",
    "adapter/lib.rs",
    "api/Cargo.toml",
    "api/lib.rs",
]:
    target = PACKET / "harness" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(CACHE / name, target)
for path in sorted(CACHE.glob("*.log")):
    (PACKET / f"{path.name}.gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for name in ["ui-partial-red-source.tsx.gz", "wire-generation-source.rs.gz"]:
    shutil.copyfile(CACHE / name, PACKET / name)
for name in ["cargo-metadata.json", "npm-tree.json", "package-evidence.py"]:
    (PACKET / f"{name}.gz").write_bytes(
        gzip.compress((CACHE / name).read_bytes(), mtime=0)
    )
checks = [
    (
        "cargo test --offline --locked --manifest-path .cache/media-activity-leaf/Cargo.toml",
        "test-final.log.gz",
    ),
    (
        "cargo clippy --offline --locked --manifest-path .cache/media-activity-leaf/Cargo.toml --all-targets -- -D warnings",
        "clippy-final.log.gz",
    ),
    ("node frontend/tests/media-activity.test.mjs", "ui-final.log.gz"),
    (
        "frontend/node_modules/.bin/tsc --noEmit --project frontend/tsconfig.json",
        "typescript.log.gz",
    ),
    (
        "rustfmt --check --edition 2024 crates/domain/src/deployment/mod.rs crates/executor-container/src/deployment/mod.rs crates/api/src/deployment.rs",
        "rustfmt.log.gz",
    ),
    (
        "uv run --offline --no-project --with ruff==0.17.0 ruff check tests/fixtures/deployment/activity/check-leaves.py",
        "ruff.log.gz",
    ),
    (
        "uv run --offline --no-project --with ruff==0.17.0 ruff format --check tests/fixtures/deployment/activity/check-leaves.py",
        "ruff-format.log.gz",
    ),
]
metadata = {
    "recorded_at_utc": datetime.now(UTC).isoformat(),
    "source_commit": CODE,
    "rust_api_commit": run("git", "rev-parse", "80cf363").decode().strip(),
    "base_commit": run("git", "rev-parse", "1f64979").decode().strip(),
    "branch": "engineer/p04-media-activity",
    "source_files_sha256": sources,
    "frozen_reference": {
        "commit": FROZEN,
        "files_sha256": reference,
        "execution": "Read/hash only; no Python imported or executed",
    },
    "rust_tests": {
        "activity_domain": 15,
        "activity_decoder": 16,
        "activity_api": 2,
        "existing_library_domain": 21,
        "existing_library_decoder": 10,
        "existing_catalog": 20,
        "existing_b2_domain": 12,
        "existing_b2_api": 2,
        "existing_api_helpers": 9,
        "total": 107,
        "filtered": 0,
    },
    "frontend_tests": {"static_react_and_expiry": 10, "browser": 0},
    "fixtures": {
        "synthetic_provider_responses": 4,
        "rust_generated_serialization_fixture": 1,
        "live_captures": 0,
    },
    "tool_versions": {
        "rustc": (CACHE / "rustc.txt").read_text().strip(),
        "cargo": (CACHE / "cargo.txt").read_text().strip(),
        "node": (CACHE / "node.txt").read_text().strip(),
        "typescript": "5.7.3",
        "react": "18.3.1",
        "react_dom": "18.3.1",
        "clippy": run("cargo", "clippy", "--version").decode().strip(),
        "rustfmt": run("rustfmt", "--version").decode().strip(),
        "uv": run("uv", "--version").decode().strip(),
        "ruff": "0.17.0 (explicit cached uv pin)",
    },
    "cargo_environment": {
        "CARGO_BUILD_JOBS": "1",
        "CARGO_INCREMENTAL": "0",
        "RUST_TEST_THREADS": "2 for tests",
        "CARGO_TARGET_DIR": "/home/marc/Documents/github/lime-os/.cache/rewrite-pool-dependencies/target",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
    },
    "uv_environment": {
        "UV_CACHE_DIR": "/home/marc/Documents/github/lime-os/.cache/uv",
        "TMPDIR": "/home/marc/Documents/github/lime-os/.cache/tmp",
    },
    "checks": [{"command": cmd, "exit_code": 0, "log": log} for cmd, log in checks],
    "diagnostics": [
        "All local Cargo/Node/TypeScript suites were sequential; one Cargo build job",
        "UI direct regression: partial snapshots showed supplied totals; final view requires complete",
        "Initial Node --test output was file-level only; direct node:test logs supply 9/1 red and 10/0 green case detail; wrapper green not counted again",
        "Initial wire generation omitted Tokio test-util; final standalone harness adds the existing API test feature",
        "Initial strict Clippy found missing non-test proposed route wrapper in the harness; final wrapper added, no production lint suppressed",
        "Wire-generation write branch was removed before final Rust run; final test compares committed JSON without writes",
        "Python helper concatenation was parenthesized for Ruff; harness-stable log verifies unchanged final manifests/wrappers/lock",
        "Frontend used a temporary worktree symlink to existing main frontend dependencies, removed after checks; no dependency install or production lock change",
    ],
    "registration": {
        "runtime": False,
        "actual_collector": False,
        "api_leaf_only": True,
        "ui_presentational_only": True,
        "shared_roots_modified": False,
        "production_manifests_lock_modified": False,
        "stream_a_files_modified": False,
        "host_effects": False,
    },
    "primary_references": [
        "https://github.com/transmission/transmission/blob/4.0.6/docs/rpc-spec.md",
        "https://sabnzbd.org/wiki/configuration/5.1/api",
    ],
    "limits": [
        "Plain supplied data, never source/endpoint/credential/namespace authority",
        "No live HTTP/Engine/credential or physical collection",
        "No frontend cache/decoder/controller/session/deadline registration or browser/layout acceptance",
        "No whole-worker, installed/package/ARM64/Pi/performance/soak/cutover qualification",
        "No phase or registered milestone closure; A and central ownership remain separate",
    ],
}
(PACKET / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
artifacts = [
    p for p in sorted(PACKET.rglob("*")) if p.is_file() and p.name != "SHA256SUMS"
]
(PACKET / "SHA256SUMS").write_text(
    "".join(f"{sha(p.read_bytes())}  {p.relative_to(PACKET)}\n" for p in artifacts)
)
print(
    f"Bound {len(sources)} committed source inputs and {len(artifacts)} packet artifacts"
)
